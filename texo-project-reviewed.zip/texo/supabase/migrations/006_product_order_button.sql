-- TEXO: per-product "Order Button" control (admin can turn it off or rename it). Safe to re-run.
alter table products add column if not exists order_button_enabled boolean not null default true;
alter table products add column if not exists order_button_text text;
alter table products drop constraint if exists products_order_button_text_chk;
alter table products add constraint products_order_button_text_chk
  check (order_button_text is null or char_length(order_button_text) between 1 and 30);
