-- TEXO Phase 4: hero + welcome settings (safe to re-run; never overwrites your edits).
insert into site_settings (key, value) values
  ('welcome_enabled', 'true'),
  ('welcome_line1', '"স্বাগতম TEXO-তে"'),
  ('welcome_line2', '"আপনার Tech Experience শুরু হোক।"'),
  ('hero_rotation_seconds', '6'),
  ('hero_animation_speed', '1')
on conflict (key) do nothing;
