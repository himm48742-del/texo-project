-- TEXO Phase 2: atomic order placement + status change (with restock on cancel).
-- Run AFTER 001_schema.sql. Callable only by the server (service_role).

create or replace function place_order(p_order jsonb, p_items jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  it jsonb; v_id uuid; v_no bigint;
begin
  -- Lock/decrement stock in a stable order (prevents deadlocks). Fails if stock changed since the server read it.
  for it in select value from jsonb_array_elements(p_items) order by value->>'product_id' loop
    update products set
      stock = stock - (it->>'quantity')::int,
      stock_status = case
        when stock - (it->>'quantity')::int <= 0 then 'out_of_stock'
        when stock - (it->>'quantity')::int <= 5 then 'low_stock'
        else stock_status end
    where id = (it->>'product_id')::uuid and is_active and stock >= (it->>'quantity')::int;
    if not found then
      raise exception 'OUT_OF_STOCK: %', it->>'product_name';
    end if;
  end loop;

  insert into orders (customer_name, phone, address, district, area, delivery_zone, notes, subtotal, delivery_charge, total)
  values (p_order->>'customer_name', p_order->>'phone', p_order->>'address', p_order->>'district',
          p_order->>'area', p_order->>'delivery_zone', p_order->>'notes',
          (p_order->>'subtotal')::numeric, (p_order->>'delivery_charge')::numeric, (p_order->>'total')::numeric)
  returning orders.id, orders.order_no into v_id, v_no;

  insert into order_items (order_id, product_id, product_name, unit_regular, unit_price, quantity)
  select v_id, (x->>'product_id')::uuid, x->>'product_name', (x->>'unit_regular')::numeric,
         (x->>'unit_price')::numeric, (x->>'quantity')::int
  from jsonb_array_elements(p_items) x;

  return jsonb_build_object('id', v_id, 'order_no', v_no);
end $$;

create or replace function set_order_status(p_id uuid, p_status text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_old text;
begin
  select status into v_old from orders where id = p_id for update;
  if not found then raise exception 'NOT_FOUND'; end if;
  if v_old = 'cancelled' and p_status <> 'cancelled' then raise exception 'ORDER_CANCELLED'; end if;
  if p_status = 'cancelled' and v_old <> 'cancelled' then
    update products p set
      stock = p.stock + oi.quantity,
      stock_status = case when p.stock_status = 'out_of_stock' then 'in_stock' else p.stock_status end
    from order_items oi where oi.order_id = p_id and oi.product_id = p.id;
  end if;
  update orders set status = p_status where id = p_id;
  return (select to_jsonb(o) from orders o where o.id = p_id);
end $$;

revoke execute on function place_order(jsonb, jsonb) from public, anon, authenticated;
revoke execute on function set_order_status(uuid, text) from public, anon, authenticated;
grant execute on function place_order(jsonb, jsonb) to service_role;
grant execute on function set_order_status(uuid, text) to service_role;
