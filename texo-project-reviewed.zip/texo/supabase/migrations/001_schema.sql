-- TEXO Phase 1: schema, indexes, RLS, storage. Run in Supabase SQL editor.
create extension if not exists pg_trgm;

-- "users" = Supabase auth.users. admin_users marks who is an admin.
create table admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  created_at timestamptz default now()
);

create or replace function is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from admin_users where user_id = auth.uid());
$$;

create table categories (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text unique not null,
  icon_url text,
  display_order int default 0,
  is_active boolean default true,
  created_at timestamptz default now()
);

create table products (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  sku text unique not null,
  name text not null,
  short_desc text,
  full_desc text,
  category_id uuid references categories(id) on delete set null,
  regular_price numeric(12,2) not null check (regular_price >= 0),
  sale_price numeric(12,2) check (sale_price is null or sale_price <= regular_price),
  discount_amount numeric(12,2) default 0,       -- auto-calculated
  discount_percent int default 0,                -- auto-calculated; override allowed
  discount_manual boolean default false,         -- true = keep admin's manual percent
  offer_text text,
  currency text default 'BDT',
  stock int default 0 check (stock >= 0),
  stock_status text default 'in_stock' check (stock_status in ('in_stock','low_stock','out_of_stock','preorder')),
  main_image_url text,
  thumb_url text,
  video_url text,
  features jsonb default '[]',
  specifications jsonb default '{}',
  is_featured boolean default false,
  featured_in_hero boolean default false,
  hero_order int default 0,
  display_order int default 0,
  is_active boolean default true,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);
create index on products (category_id, is_active, display_order);
create index on products (hero_order) where featured_in_hero and is_active;
create index on products using gin (name gin_trgm_ops);
create index on products using gin (sku gin_trgm_ops);

create table product_images (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references products(id) on delete cascade,
  url text not null, thumb_url text, alt_text text,
  sort_order int default 0
);
create index on product_images (product_id, sort_order);

create table product_models (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null unique references products(id) on delete cascade,
  model_url text not null,
  format text check (format in ('glb','gltf')),
  created_at timestamptz default now()
);

create table orders (
  id uuid primary key default gen_random_uuid(),
  order_no bigint generated always as identity unique,
  customer_name text not null,
  phone text not null check (phone ~ '^01[3-9][0-9]{8}$'),
  address text not null,
  district text not null,
  area text,
  delivery_zone text check (delivery_zone in ('inside_dhaka','outside_dhaka')),
  notes text,
  subtotal numeric(12,2) not null,
  delivery_charge numeric(12,2) not null default 0,
  total numeric(12,2) not null,
  status text not null default 'pending'
    check (status in ('pending','confirmed','processing','shipped','delivered','cancelled')),
  source text default 'web',
  created_at timestamptz default now()
);
create index on orders (status, created_at desc);
create index on orders (phone);

create table order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references orders(id) on delete cascade,
  product_id uuid references products(id) on delete set null,
  product_name text not null,   -- snapshot at order time
  unit_regular numeric(12,2) not null,
  unit_price numeric(12,2) not null,
  quantity int not null check (quantity > 0)
);
create index on order_items (order_id);

create table offers (
  id uuid primary key default gen_random_uuid(),
  title text not null, offer_text text,
  discount_percent int,
  starts_at timestamptz, ends_at timestamptz,
  product_id uuid references products(id) on delete cascade,
  category_id uuid references categories(id) on delete cascade,
  banner_url text,
  auto_expire boolean default true,
  is_active boolean default true
);

create table news (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  title text not null, description text, body text,
  thumbnail_url text,
  published_at timestamptz default now(),
  is_published boolean default false
);

create table site_settings (
  key text primary key,
  value jsonb not null,
  updated_at timestamptz default now()
);

-- Auto discount calculation
create or replace function calc_discount() returns trigger language plpgsql as $$
begin
  new.updated_at := now();
  if new.sale_price is null or new.sale_price >= new.regular_price then
    new.discount_amount := 0;
    if not new.discount_manual then new.discount_percent := 0; end if;
  else
    new.discount_amount := new.regular_price - new.sale_price;
    if not new.discount_manual then
      new.discount_percent := round(new.discount_amount / new.regular_price * 100);
    end if;
  end if;
  return new;
end $$;
create trigger trg_calc_discount before insert or update on products
  for each row execute function calc_discount();

-- Row Level Security
alter table admin_users enable row level security;
alter table categories enable row level security;
alter table products enable row level security;
alter table product_images enable row level security;
alter table product_models enable row level security;
alter table orders enable row level security;
alter table order_items enable row level security;
alter table offers enable row level security;
alter table news enable row level security;
alter table site_settings enable row level security;

-- Public can read only live content
create policy pub_cat on categories for select using (is_active);
create policy pub_prod on products for select using (is_active);
create policy pub_img on product_images for select using (true);
create policy pub_model on product_models for select using (true);
create policy pub_offer on offers for select using (is_active and (not auto_expire or ends_at is null or ends_at > now()));
create policy pub_news on news for select using (is_published);
create policy pub_set on site_settings for select using (key not like 'private.%');

-- Admin full access
do $$ declare t text; begin
  foreach t in array array['categories','products','product_images','product_models','orders','order_items','offers','news','site_settings','admin_users']
  loop execute format('create policy admin_all on %I for all using (is_admin()) with check (is_admin())', t); end loop;
end $$;
-- Orders: NO public policy. Customers order through the Node API (service role) which validates input and recomputes prices server-side.

-- Storage buckets (public read, admin write)
insert into storage.buckets (id, name, public) values
  ('product-images','product-images',true),
  ('product-models','product-models',true),
  ('site-media','site-media',true)
on conflict do nothing;
create policy "public read media" on storage.objects for select
  using (bucket_id in ('product-images','product-models','site-media'));
create policy "admin write media" on storage.objects for all
  using (is_admin()) with check (is_admin());
