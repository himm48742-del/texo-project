-- TEXO Phase 5: dashboard overview numbers in one query. Callable only by the server.
create or replace function admin_stats() returns jsonb
language sql stable security definer set search_path = public as $$
  select jsonb_build_object(
    'products',   (select count(*) from products),
    'active_products', (select count(*) from products where is_active),
    'categories', (select count(*) from categories),
    'offers',     (select count(*) from offers where is_active),
    'news',       (select count(*) from news),
    'orders',     (select count(*) from orders),
    'by_status',  coalesce((select jsonb_object_agg(status, n) from (select status, count(*) n from orders group by status) s), '{}'::jsonb),
    'total_sales',     coalesce((select sum(total) from orders where status <> 'cancelled'), 0),
    'delivered_sales', coalesce((select sum(total) from orders where status = 'delivered'), 0),
    'last_14_days', coalesce((
      select jsonb_agg(jsonb_build_object('day', d::date, 'orders', coalesce(o.n, 0), 'sales', coalesce(o.t, 0)) order by d)
      from generate_series(current_date - 13, current_date, interval '1 day') d
      left join (select (created_at::date) as dd, count(*) as n, sum(total) as t from orders where status <> 'cancelled' group by 1) o on o.dd = d::date), '[]'::jsonb),
    'low_stock', coalesce((
      select jsonb_agg(to_jsonb(p)) from (select id, name, sku, stock, stock_status from products where is_active and stock <= 5 order by stock, name limit 8) p), '[]'::jsonb),
    'recent_orders', coalesce((
      select jsonb_agg(to_jsonb(o)) from (select id, order_no, customer_name, total, status, created_at from orders order by created_at desc limit 6) o), '[]'::jsonb)
  );
$$;
revoke execute on function admin_stats() from public, anon, authenticated;
grant execute on function admin_stats() to service_role;
