-- TEXO: offers now drive real checkout prices. Run after 002.

-- Fixed offer price for a single product (category offers use discount_percent).
alter table offers add column if not exists offer_price numeric(12,2);

-- Reject negative / zero / nonsensical prices at the database level (last line of defence).
alter table products drop constraint if exists products_price_positive_chk;
alter table products add constraint products_price_positive_chk
  check (regular_price > 0 and (sale_price is null or sale_price > 0));
alter table offers drop constraint if exists offers_value_chk;
alter table offers add constraint offers_value_chk check (
  (offer_price is null or offer_price > 0)
  and (discount_percent is null or discount_percent between 1 and 99)
  and (offer_price is not null or discount_percent is not null)
  and (product_id is not null or category_id is not null)
  and (offer_price is null or product_id is not null)
  and (starts_at is null or ends_at is null or ends_at > starts_at)
) not valid;   -- "not valid": applies to new/edited rows; run `validate constraint` once old rows are clean.

-- place_order now records the channel (web / whatsapp).
create or replace function place_order(p_order jsonb, p_items jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare it jsonb; v_id uuid; v_no bigint;
begin
  for it in select value from jsonb_array_elements(p_items) order by value->>'product_id' loop
    update products set
      stock = stock - (it->>'quantity')::int,
      stock_status = case
        when stock - (it->>'quantity')::int <= 0 then 'out_of_stock'
        when stock - (it->>'quantity')::int <= 5 then 'low_stock'
        else stock_status end
    where id = (it->>'product_id')::uuid and is_active and stock >= (it->>'quantity')::int;
    if not found then raise exception 'OUT_OF_STOCK: %', it->>'product_name'; end if;
  end loop;

  insert into orders (customer_name, phone, address, district, area, delivery_zone, notes, subtotal, delivery_charge, total, source)
  values (p_order->>'customer_name', p_order->>'phone', p_order->>'address', p_order->>'district',
          p_order->>'area', p_order->>'delivery_zone', p_order->>'notes',
          (p_order->>'subtotal')::numeric, (p_order->>'delivery_charge')::numeric, (p_order->>'total')::numeric,
          case when p_order->>'source' = 'whatsapp' then 'whatsapp' else 'web' end)
  returning orders.id, orders.order_no into v_id, v_no;

  insert into order_items (order_id, product_id, product_name, unit_regular, unit_price, quantity)
  select v_id, (x->>'product_id')::uuid, x->>'product_name', (x->>'unit_regular')::numeric,
         (x->>'unit_price')::numeric, (x->>'quantity')::int
  from jsonb_array_elements(p_items) x;

  return jsonb_build_object('id', v_id, 'order_no', v_no);
end $$;
revoke execute on function place_order(jsonb, jsonb) from public, anon, authenticated;
grant execute on function place_order(jsonb, jsonb) to service_role;
