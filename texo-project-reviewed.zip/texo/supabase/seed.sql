-- TEXO demo data (20 products). Safe to re-run after clearing tables.
insert into categories (name, slug, display_order) values
 ('Audio','audio',1),('Smart Watch','smart-watch',2),('Mobile Accessories','mobile-accessories',3),
 ('Power & Charging','power-charging',4),('Computer Accessories','computer-accessories',5),
 ('Gaming','gaming',6),('Smart Gadgets','smart-gadgets',7)
on conflict (slug) do nothing;

insert into products (slug,sku,name,short_desc,category_id,regular_price,sale_price,stock,is_featured,featured_in_hero,hero_order,display_order)
select v.slug,v.sku,v.name,v.d,c.id,v.rp,v.sp,v.st,v.f,v.h,v.o,v.o
from (values
 ('texo-airbuds-x1','TX-AU-001','TEXO AirBuds X1','Premium Wireless ANC Earbuds','audio',2490,1790,50,true,true,1),
 ('texo-airbuds-lite','TX-AU-002','TEXO AirBuds Lite','Lightweight everyday earbuds','audio',1490,1190,80,false,true,2),
 ('texo-neckband-n2','TX-AU-003','TEXO Neckband N2','40-hour battery neckband','audio',1290,990,60,false,false,3),
 ('texo-soundbox-mini','TX-AU-004','TEXO SoundBox Mini','Portable Bluetooth speaker','audio',1990,1590,40,false,true,4),
 ('texo-watch-s1','TX-SW-001','TEXO Watch S1','AMOLED smart watch','smart-watch',3990,2990,35,true,true,5),
 ('texo-watch-fit','TX-SW-002','TEXO Watch Fit','Slim fitness tracker band','smart-watch',1890,null,70,false,false,6),
 ('texo-watch-pro','TX-SW-003','TEXO Watch Pro','Calling smart watch, GPS','smart-watch',5490,4490,20,true,true,7),
 ('texo-case-armor','TX-MA-001','TEXO Armor Case','Shockproof phone case','mobile-accessories',590,450,150,false,false,8),
 ('texo-glass-guard','TX-MA-002','TEXO Glass Guard','9H tempered glass','mobile-accessories',390,290,200,false,false,9),
 ('texo-mag-stand','TX-MA-003','TEXO MagStand','Magnetic phone stand','mobile-accessories',890,690,90,false,false,10),
 ('texo-powerbank-20k','TX-PC-001','TEXO PowerBank 20K','20000mAh fast-charge power bank','power-charging',2890,2290,45,true,true,11),
 ('texo-charger-65w','TX-PC-002','TEXO Charger 65W','GaN fast charger','power-charging',1790,1390,75,false,false,12),
 ('texo-cable-c100','TX-PC-003','TEXO Cable C100','100W braided USB-C cable','power-charging',690,490,300,false,false,13),
 ('texo-keyboard-k1','TX-CA-001','TEXO Keyboard K1','Compact wireless keyboard','computer-accessories',2290,1890,30,false,true,14),
 ('texo-mouse-m1','TX-CA-002','TEXO Mouse M1','Silent ergonomic mouse','computer-accessories',990,790,100,false,false,15),
 ('texo-hub-6in1','TX-CA-003','TEXO Hub 6-in-1','USB-C multiport hub','computer-accessories',2490,1990,40,false,false,16),
 ('texo-gamepad-g1','TX-GM-001','TEXO Gamepad G1','Wireless controller','gaming',2190,1790,35,false,true,17),
 ('texo-headset-gx','TX-GM-002','TEXO Headset GX','Gaming headset with mic','gaming',2890,2390,25,false,false,18),
 ('texo-lamp-smart','TX-SG-001','TEXO Smart Lamp','RGB app-controlled lamp','smart-gadgets',1590,1190,55,false,false,19),
 ('texo-tracker-t1','TX-SG-002','TEXO Tracker T1','Bluetooth item tracker','smart-gadgets',990,790,0,false,false,20)
) as v(slug,sku,name,d,cat,rp,sp,st,f,h,o)
join categories c on c.slug = v.cat
on conflict (slug) do nothing;

update products set stock_status='out_of_stock' where stock=0;

insert into site_settings (key,value) values
 ('brand_name','"TEXO"'),('tagline','"YOUR TECH."'),
 ('welcome_line1','"স্বাগতম TEXO-তে"'),('welcome_line2','"আপনার Tech Experience শুরু হোক।"'),
 ('hero_headline','"YOUR TECH.\nYOUR\nEXPERIENCE."'),
 ('hero_description','"Modern gadgets, smart devices and everyday technology — selected to make your digital life simpler, smarter and better."'),
 ('business_phone','"01601603092"'),('whatsapp_number','"8801601603092"'),
 ('social_links','{"facebook":"","instagram":"","email":""}'),
 ('footer_text','"© TEXO. Your Tech."'),
 ('currency','"BDT"'),('currency_symbol','"৳"'),
 ('delivery_inside_dhaka','60'),('delivery_outside_dhaka','120'),('free_delivery_threshold','5000'),
 ('hero_rotation_seconds','6'),('hero_animation_speed','1')
on conflict (key) do nothing;
