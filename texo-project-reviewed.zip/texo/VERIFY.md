# TEXO — Verify Phase 5 (beginner guide)

Rule: **never paste passwords, API keys, service-role keys or tokens into chat.** Everything below is safe to copy.
Work top to bottom. Do one step, check the result, then continue.

## A. Check your tools
In VS Code: **Terminal > New Terminal**.
```
node -v
npm -v
```
Node must be **v22.18 or higher**. If not, install the LTS version from nodejs.org and restart VS Code.
PowerShell error "running scripts is disabled"? Use the **Command Prompt** terminal instead (terminal dropdown "v" > Command Prompt).

## B. Supabase database (once)
1. supabase.com > your project > **SQL Editor** > **New query**.
2. In VS Code open `supabase/migrations/001_schema.sql`, Ctrl+A, Ctrl+C. Paste in the query box. Click **Run**. Expect "Success".
3. Repeat in this order: `supabase/seed.sql`, `002_order_functions.sql`, `003_offers_pricing.sql`, `004_phase4_settings.sql`, **`005_admin_stats.sql`**, **`006_product_order_button.sql`**.
   - Already ran one before? 002–005 are safe to run again. 001 will say "already exists": skip it.
4. Authentication > Users > **Add user** (your email + a strong password you choose, tick "auto confirm"). Click the user, copy the **User UID**.
5. SQL Editor, new query (replace the id): `insert into admin_users (user_id, full_name) values ('PASTE-USER-UID', 'Owner');` > Run.

## C. Settings file (server only)
```
cd server
copy .env.example .env
```
Open `server/.env` in VS Code. Replace the 3 placeholders with values from Supabase > Project Settings > **API** (Project URL, `anon public`, `service_role`). Save. Do not share the file.

## D. Install, test, build (each in `server`, then in `web`)
```
npm install
npm test
npm run typecheck
npm run build
```
Expected: tests say `# fail 0`; typecheck and build print no red errors. **If anything is red, copy the red text (not .env) and send it to me.**

## E. Start both apps (two terminals)
Terminal 1: `cd server` then `npm run dev` (wait for "TEXO API running").
Terminal 2: `cd web` then `npm run dev` (wait for "Local: http://localhost:5173").

## F. Doctor (checks Supabase + API + web connection)
Terminal 3: `cd server` then `npm run doctor`.
Copy its whole output to me. It contains no secrets.

## G. Browser checklist (http://localhost:5173)
Mark each: PASS / FAIL / NOT RUN. Admin: `/admin/login`.

| # | Test | Do this | Expect |
|---|---|---|---|
| 1 | Admin login | Wrong password, then right one. Refresh. Open `/admin/products` in a private window | Wrong: red error. Right: dashboard with numbers. Refresh: still in. Private window: sent to login |
| 2 | Product add | Products > Add product: name, SKU, regular 2000, sale 1500, stock 10, Create | Preview shows 25% OFF. Product appears in list and on the store |
| 3 | Product bad price | Edit: sale 2500 | Red error, not saved |
| 4 | Product edit/duplicate/disable/delete | Change name; Duplicate; toggle Enabled; Delete (confirm) | Each works; duplicate is a disabled copy; deleted one disappears |
| 5 | Image upload | Edit product > Main image > pick a JPG under 5 MB | Progress bar, preview, shows on store. Then try a .gif or 6 MB file: clear error |
| 6 | Gallery | Add 2–3 images; use arrows; delete one | Order and delete persist after reload |
| 7 | 3D model | Upload a small `.glb` (e.g. Khronos "Box.glb"). Try a .txt renamed .glb | Valid: file name + "Active". Fake: error. Remove: back to normal |
| 8 | Hero order | Hero showcase: add 3 products, drag to reorder (on phone use arrows), reload, view store home | Same order after reload; store rotates in that order; disabled one is skipped |
| 9 | Hero settings | Seconds 3, autoplay off, Save | Store hero rotates faster / waits for Play |
| 10 | Offer price | Offers > New: product A, fixed price below regular, no end date | Preview shows real price; Save works; product page shows crossed-out regular + offer price |
| 11 | Checkout price | Order product A | Summary and total use the offer price. Admin > Orders shows the same price and discount |
| 12 | Offer expiry | Set the offer end date in the past (or turn Active off) | Store and checkout go back to normal price |
| 13 | Invalid offer | Offer price equal/above regular | Preview error, Save disabled |
| 14 | Cancel + stock | Note stock (e.g. 10). Order qty 2 (stock 8). Admin > Orders > Cancelled > confirm | Stock back to 10. Order cannot be reopened |
| 15 | Order search | Filter by status, phone, date, product | List narrows correctly |
| 16 | Categories | Add, rename, upload icon, reorder, disable | Store sidebar matches |
| 17 | News | Create with thumbnail, publish, unpublish | Shows on /news only when published |
| 18 | Settings | Change tagline, delivery charges, WhatsApp number; welcome lines; Save each tab | Store updates within about a minute. Private window: intro shows new text. Checkout shows new delivery charge |
| 20 | Product card | Home page, look at a card with a discount | Floating photo that tilts when you move the mouse/finger; "Regular Price", "Discount Price", "Save ৳… — …% OFF"; ORDER NOW button |
| 21 | Card 3D | Give a product a .glb (test 7) and put it on the first page. Hover the card (or tap its 3D chip on a phone) | Real 3D viewer starts in the card; moving to another card stops it |
| 22 | ORDER NOW | Tap ORDER NOW on a card | Goes to `/order/<product>`: product image, name, regular + discount price, offer, quantity, your details, delivery option, summary, Confirm Order |
| 23 | Discount % | Admin > edit product: type 25 in "Discount %" | Discount price fills in automatically (and the other way round); store shows 25% OFF |
| 24 | Order button off | Admin > product: turn "Order button" off, save | Card shows "Unavailable"; `/order/<product>` is blocked |
| 25 | Product page 3D | Open a product that has a .glb | "Photos / 3D view" switch; 3D view rotates and can be dragged |
| 19 | Mobile | Chrome: F12 then Ctrl+Shift+M, pick iPhone size (or open the PC address on your phone on the same Wi-Fi after `npm run dev -- --host` in web) | Menu drawer opens, tables become cards, no sideways scrolling, buttons easy to tap |

## H. What to send me
- Output of D (only if something is red), F (doctor), and the PASS/FAIL/NOT RUN for G.
- Screenshots are fine if they do not show keys or the .env file.
