import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import type { ReactNode } from 'react';
import type { CartItem } from '../types/api';

// The cart stores ONLY product ids and quantities. Prices are never stored in the browser;
// they are always fetched from the server (POST /orders/quote).
interface CartApi {
  items: CartItem[]; count: number;
  add: (productId: string, qty?: number) => void;
  setOnly: (productId: string, qty: number) => void;
  setQty: (productId: string, qty: number) => void;
  remove: (productId: string) => void;
  clear: () => void;
}
const Ctx = createContext<CartApi | null>(null);
const KEY = 'texo.cart.v1';
const clamp = (n: number) => Math.min(20, Math.max(1, Math.floor(n) || 1));

function load(): CartItem[] {
  try {
    const raw = JSON.parse(localStorage.getItem(KEY) ?? '[]');
    return Array.isArray(raw) ? raw.filter((i) => typeof i?.productId === 'string').map((i) => ({ productId: i.productId, quantity: clamp(i.quantity) })) : [];
  } catch { return []; }
}

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>(load);
  useEffect(() => { try { localStorage.setItem(KEY, JSON.stringify(items)); } catch { /* storage unavailable */ } }, [items]);
  const add = useCallback((id: string, qty = 1) => setItems((cur) => {
    const f = cur.find((i) => i.productId === id);
    return f ? cur.map((i) => (i.productId === id ? { ...i, quantity: clamp(i.quantity + qty) } : i)) : [...cur, { productId: id, quantity: clamp(qty) }];
  }), []);
  const value = useMemo<CartApi>(() => ({
    items, count: items.reduce((s, i) => s + i.quantity, 0), add,
    setOnly: (id, qty) => setItems([{ productId: id, quantity: clamp(qty) }]),
    setQty: (id, qty) => setItems((c) => c.map((i) => (i.productId === id ? { ...i, quantity: clamp(qty) } : i))),
    remove: (id) => setItems((c) => c.filter((i) => i.productId !== id)),
    clear: () => setItems([]),
  }), [items, add]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
export function useCart() {
  const c = useContext(Ctx);
  if (!c) throw new Error('useCart must be used inside CartProvider');
  return c;
}
