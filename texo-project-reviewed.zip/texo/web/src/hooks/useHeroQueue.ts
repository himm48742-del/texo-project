import { useCallback, useEffect, useRef, useState } from 'react';
import { api } from '../lib/api';
import { mergeBatch, nextIndex, preloadTargets, prevIndex, shouldFetchMore } from '../lib/heroQueue';
import { canWebGL, preloadImage } from '../lib/preload';
import type { HeroProduct } from '../types/api';

const BATCH = 6;

/**
 * Hero product queue. Loads the admin-ordered list in small batches, rotates automatically,
 * and warms the cache for only the next 2 images. Capable of 500+ products: product DATA is
 * fetched 6 at a time and images are never bulk-loaded.
 */
export function useHeroQueue({ rotateMs, paused }: { rotateMs: number; paused: boolean }) {
  const [items, setItems] = useState<HeroProduct[]>([]);
  const [index, setIndex] = useState(0);
  const [total, setTotal] = useState(0);
  const [status, setStatus] = useState<'loading' | 'ready' | 'empty' | 'error'>('loading');
  const [tick, setTick] = useState(0); // restarts the timer after manual navigation
  const offset = useRef(0);
  const busy = useRef(false);
  const itemsRef = useRef<HeroProduct[]>([]);
  itemsRef.current = items;
  const hasMore = items.length < total;

  const loadMore = useCallback(async () => {
    if (busy.current) return;
    busy.current = true;
    try {
      const r = await api.heroPage(offset.current, BATCH);
      offset.current = r.meta?.nextOffset ?? 0;
      const merged = mergeBatch(itemsRef.current, r.data);
      itemsRef.current = merged;
      setItems(merged);
      // nextOffset === 0 means the server wrapped around: everything has been seen, so stop expecting more.
      setTotal(r.meta?.nextOffset === 0 ? merged.length : r.meta?.total ?? merged.length);
      setStatus(r.data.length || (r.meta?.total ?? 0) ? 'ready' : 'empty');
    } catch {
      setStatus((s) => (s === 'ready' ? s : 'error'));
    } finally { busy.current = false; }
  }, []);

  useEffect(() => { if (shouldFetchMore(index, items.length, total)) loadMore(); }, [index, items.length, total, loadMore]);

  // Warm the cache for the next two products only.
  useEffect(() => {
    preloadTargets(items.map((i) => ({ id: i.id, main_image_url: i.main_image_url, thumb_url: i.thumb_url })), index, 2).forEach(preloadImage);
    if (canWebGL()) {
      for (let k = 1; k <= 2 && items.length > 1; k++) {
        const m = items[(index + k) % items.length]?.model;
        if (m) import('../components/hero/ModelStage').then((x) => x.preloadModel(m.model_url)).catch(() => {});
      }
    }
  }, [index, items]);

  const next = useCallback(() => { setIndex((i) => nextIndex(i, items.length, hasMore)); setTick((t) => t + 1); }, [items.length, hasMore]);
  const prev = useCallback(() => { setIndex((i) => prevIndex(i, items.length)); setTick((t) => t + 1); }, [items.length]);

  useEffect(() => {
    if (paused || items.length < 2) return;
    const t = setTimeout(() => setIndex((i) => nextIndex(i, items.length, hasMore)), rotateMs);
    return () => clearTimeout(t);
  }, [index, tick, paused, rotateMs, items.length, hasMore]);

  return { items, index, total: total || items.length, current: items[index] as HeroProduct | undefined, status, next, prev, retry: loadMore };
}
