import { keepPreviousData, useInfiniteQuery, useQuery } from '@tanstack/react-query';
import { useEffect, useState } from 'react';
import { api } from '../lib/api';
import type { CartItem } from '../types/api';

export const useSettings = () => useQuery({ queryKey: ['settings'], queryFn: api.settings, staleTime: 5 * 60_000 });
export const useCategories = () => useQuery({ queryKey: ['categories'], queryFn: api.categories, staleTime: 5 * 60_000 });
export const useProduct = (slug: string) => useQuery({ queryKey: ['product', slug], queryFn: () => api.product(slug), retry: false });
export const useOffers = () => useQuery({ queryKey: ['offers'], queryFn: api.offers });
export const useNews = (limit = 6) => useQuery({ queryKey: ['news', limit], queryFn: () => api.news(limit) });

export function useProducts(p: { category?: string; view?: string }) {
  return useInfiniteQuery({
    queryKey: ['products', p], initialPageParam: 1,
    queryFn: ({ pageParam }) => api.products({ ...p, page: pageParam, limit: 12 }),
    getNextPageParam: (last) => (last.meta && last.meta.page * last.meta.limit < last.meta.total ? last.meta.page + 1 : undefined),
  });
}
export function useSearch(q: string, limit = 12) {
  return useQuery({ queryKey: ['search', q, limit], queryFn: () => api.search(q, limit), enabled: q.trim().length >= 2, staleTime: 30_000 });
}
export function useQuote(items: CartItem[], district: string) {
  return useQuery({
    queryKey: ['quote', items, district], queryFn: () => api.quote(items, district || null),
    enabled: items.length > 0, placeholderData: keepPreviousData, retry: false,
  });
}
export function useDebounced<T>(value: T, ms = 250): T {
  const [v, setV] = useState(value);
  useEffect(() => { const t = setTimeout(() => setV(value), ms); return () => clearTimeout(t); }, [value, ms]);
  return v;
}
export function useDocumentTitle(title?: string, description?: string) {
  useEffect(() => {
    document.title = title ? `${title} | TEXO` : 'TEXO | Your Tech.';
    if (description) document.querySelector('meta[name="description"]')?.setAttribute('content', description);
  }, [title, description]);
}
