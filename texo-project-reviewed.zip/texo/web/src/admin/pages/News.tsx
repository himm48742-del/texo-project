import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Pencil, Plus, Trash2 } from 'lucide-react';
import { useState } from 'react';
import type { FormEvent } from 'react';
import { ProductImage } from '../../components/ProductImage';
import { formatDate } from '../../lib/format';
import { Badge, Empty, ErrorBlock, Field, IconBtn, Modal, PageHeader, ResponsiveTable, Skeleton, ToggleRow, useConfirm, useToast } from '../components/ui';
import { ImageUploader } from '../components/Uploaders';
import { adminApi } from '../lib/adminApi';
import { fieldErrors, fromLocalInput, toLocalInput } from '../lib/helpers';

const BLANK = { id: '', title: '', slug: '', description: '', body: '', thumbnail_url: '', published_at: toLocalInput(new Date().toISOString()), is_published: false };
export function AdminNews() {
  const qc = useQueryClient(); const toast = useToast(); const confirm = useConfirm();
  const { data, isLoading, error, refetch } = useQuery({ queryKey: ['admin', 'news'], queryFn: () => adminApi.list('news') });
  const [edit, setEdit] = useState<typeof BLANK | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({}); const [busy, setBusy] = useState(false);
  const refresh = () => qc.invalidateQueries({ queryKey: ['admin', 'news'] });
  async function save(e: FormEvent) {
    e.preventDefault(); if (!edit) return; setBusy(true); setErrors({});
    const b: Record<string, unknown> = { title: edit.title, description: edit.description || null, body: edit.body || null, thumbnail_url: edit.thumbnail_url || null, is_published: edit.is_published };
    if (edit.slug.trim()) b.slug = edit.slug.trim();
    const when = fromLocalInput(edit.published_at); if (when) b.published_at = when;
    try { edit.id ? await adminApi.update('news', edit.id, b) : await adminApi.create('news', b); await refresh(); setEdit(null); toast(edit.is_published ? 'Article saved and published.' : 'Article saved as draft.'); }
    catch (err) { setErrors(fieldErrors((err as any).details)); toast((err as Error).message, 'error'); } finally { setBusy(false); }
  }
  async function del(n: any) {
    if (!(await confirm({ title: `Delete “${n.title}”?`, message: 'The article is permanently removed from the site.', confirmLabel: 'Delete article', danger: true }))) return;
    try { await adminApi.remove('news', n.id); await refresh(); toast('Article deleted.'); } catch (e) { toast((e as Error).message, 'error'); }
  }
  async function publish(n: any) { try { await adminApi.update('news', n.id, { is_published: !n.is_published }); await refresh(); toast(n.is_published ? 'Unpublished.' : 'Published.'); } catch (e) { toast((e as Error).message, 'error'); } }
  return (
    <>
      <PageHeader title="Tech News" action={<button className="btn btn-primary" onClick={() => { setErrors({}); setEdit({ ...BLANK, published_at: toLocalInput(new Date().toISOString()) }); }}><Plus className="h-4 w-4" /> New article</button>} />
      {isLoading ? <Skeleton /> : error ? <ErrorBlock error={error} retry={() => refetch()} /> : !data?.length ? <Empty title="No articles yet." /> : (
        <ResponsiveTable rows={data} rowKey={(r) => r.id}
          cols={[
            { key: 't', label: 'Article', render: (r) => <div className="flex items-center gap-3 text-left"><ProductImage src={r.thumbnail_url} alt="" className="h-12 w-16 shrink-0 rounded-lg border border-white/10" /><p className="font-medium">{r.title}</p></div> },
            { key: 'd', label: 'Date', render: (r) => formatDate(r.published_at) },
            { key: 's', label: 'Status', render: (r) => <Badge status={r.is_published ? 'delivered' : 'pending'} /> },
          ]}
          actions={(r) => <div className="inline-flex gap-1.5"><IconBtn label={r.is_published ? 'Unpublish' : 'Publish'} onClick={() => publish(r)}>{r.is_published ? 'Unpublish' : 'Publish'}</IconBtn>
            <IconBtn label="Edit" onClick={() => { setErrors({}); setEdit({ id: r.id, title: r.title, slug: r.slug, description: r.description ?? '', body: r.body ?? '', thumbnail_url: r.thumbnail_url ?? '', published_at: toLocalInput(r.published_at), is_published: r.is_published }); }}><Pencil className="h-4 w-4" /></IconBtn>
            <IconBtn label="Delete" danger onClick={() => del(r)}><Trash2 className="h-4 w-4" /></IconBtn></div>} />
      )}
      <Modal wide open={!!edit} onClose={() => setEdit(null)} title={edit?.id ? 'Edit article' : 'New article'}>
        {edit && <form onSubmit={save} className="space-y-4" noValidate>
          <Field label="Title" error={errors.title} htmlFor="n-title"><input id="n-title" className="input" value={edit.title} onChange={(e) => setEdit({ ...edit, title: e.target.value })} autoFocus /></Field>
          <Field label="Short description" error={errors.description} htmlFor="n-desc"><textarea id="n-desc" rows={2} className="input py-3" value={edit.description} onChange={(e) => setEdit({ ...edit, description: e.target.value })} /></Field>
          <Field label="Article text" error={errors.body} htmlFor="n-body"><textarea id="n-body" rows={7} className="input py-3" value={edit.body} onChange={(e) => setEdit({ ...edit, body: e.target.value })} /></Field>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Publish date" error={errors.published_at} htmlFor="n-date"><input id="n-date" type="datetime-local" className="input" value={edit.published_at} onChange={(e) => setEdit({ ...edit, published_at: e.target.value })} /></Field>
            <Field label="URL slug" error={errors.slug} hint="Blank = from title" htmlFor="n-slug"><input id="n-slug" className="input" value={edit.slug} onChange={(e) => setEdit({ ...edit, slug: e.target.value })} /></Field>
          </div>
          <ImageUploader label="Thumbnail" folder="news" value={edit.thumbnail_url} onUploaded={(url) => setEdit((c) => c && { ...c, thumbnail_url: url })} onRemove={() => setEdit((c) => c && { ...c, thumbnail_url: '' })} />
          <ToggleRow label="Published" hint="Unpublished articles are drafts and are not shown on the site." checked={edit.is_published} onChange={(v) => setEdit({ ...edit, is_published: v })} />
          <div className="flex justify-end gap-3 pt-2"><button type="button" className="btn btn-ghost" onClick={() => setEdit(null)}>Cancel</button><button className="btn btn-primary" disabled={busy}>{busy ? 'Saving…' : 'Save'}</button></div>
        </form>}
      </Modal>
    </>
  );
}
