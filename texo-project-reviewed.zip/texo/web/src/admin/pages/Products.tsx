import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { ArrowDown, ArrowUp, Copy, Pencil, Plus, Trash2 } from 'lucide-react';
import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ProductImage } from '../../components/ProductImage';
import { useDebounced } from '../../hooks/queries';
import { formatTaka } from '../../lib/format';
import { Badge, Empty, ErrorBlock, IconBtn, Pager, PageHeader, ResponsiveTable, Skeleton, Toggle, useConfirm, useToast } from '../components/ui';
import { adminApi } from '../lib/adminApi';
import { moveItem } from '../lib/helpers';

const LIMIT = 25;
export function AdminProducts() {
  const qc = useQueryClient(); const toast = useToast(); const confirm = useConfirm(); const nav = useNavigate();
  const [q, setQ] = useState(''); const [category, setCategory] = useState(''); const [active, setActive] = useState(''); const [page, setPage] = useState(1);
  const dq = useDebounced(q, 300);
  const params = { q: dq, category, active, page, limit: LIMIT };
  const list = useQuery({ queryKey: ['admin', 'products', params], queryFn: () => adminApi.products(params) });
  const cats = useQuery({ queryKey: ['admin', 'categories'], queryFn: () => adminApi.list('categories') });
  const refresh = () => qc.invalidateQueries({ queryKey: ['admin', 'products'] });
  const run = (fn: () => Promise<unknown>, ok: string) => async () => { try { await fn(); await refresh(); toast(ok); } catch (e) { toast((e as Error).message, 'error'); } };
  const patch = useMutation({ mutationFn: ({ id, b }: { id: string; b: Record<string, unknown> }) => adminApi.updateProduct(id, b), onSuccess: refresh, onError: (e) => toast((e as Error).message, 'error') });
  const rows = list.data?.rows ?? [];

  async function move(i: number, d: number) {  // swaps with the neighbour; positions of other pages are preserved by the server
    const cur = rows.map((r) => r.id as string);
    const ids = moveItem<string>(cur, i, i + d);
    if (ids === cur) return;
    try { await adminApi.reorder('products', ids, 'display_order'); await refresh(); } catch (e) { toast((e as Error).message, 'error'); }
  }
  async function del(p: any) {
    if (await confirm({ title: `Delete “${p.name}”?`, message: 'This permanently deletes the product and its gallery. Past orders keep their own record of the product. This cannot be undone.', confirmLabel: 'Delete product', danger: true }))
      run(() => adminApi.deleteProduct(p.id), 'Product deleted.')();
  }
  return (
    <>
      <PageHeader title="Products" subtitle={`${list.data?.total ?? '…'} products`} action={<Link to="/admin/products/new" className="btn btn-primary"><Plus className="h-4 w-4" /> Add product</Link>} />
      <div className="mb-5 grid gap-3 sm:grid-cols-[1fr_200px_160px]">
        <input className="input" placeholder="Search name or SKU" aria-label="Search products" value={q} onChange={(e) => { setQ(e.target.value); setPage(1); }} />
        <select className="input" aria-label="Filter by category" value={category} onChange={(e) => { setCategory(e.target.value); setPage(1); }}><option value="">All categories</option>{cats.data?.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select>
        <select className="input" aria-label="Filter by status" value={active} onChange={(e) => { setActive(e.target.value); setPage(1); }}><option value="">Any status</option><option value="true">Enabled</option><option value="false">Disabled</option></select>
      </div>
      {list.isLoading ? <Skeleton /> : list.error ? <ErrorBlock error={list.error} retry={() => list.refetch()} /> : !rows.length ? <Empty title="No products found." action={<Link to="/admin/products/new" className="btn btn-primary">Add your first product</Link>} /> : (
        <>
          <ResponsiveTable rows={rows} rowKey={(r) => r.id} onRowClick={(r) => nav(`/admin/products/${r.id}`)}
            cols={[
              { key: 'p', label: 'Product', render: (r) => <div className="flex items-center gap-3 text-left"><ProductImage src={r.thumb_url ?? r.main_image_url} alt="" className="h-12 w-12 shrink-0 rounded-lg border border-white/10 p-1" /><div className="min-w-0"><p className="truncate font-medium">{r.name}</p><p className="text-xs text-white/40">{r.sku}{r.categories?.name ? ` · ${r.categories.name}` : ''}</p></div></div> },
              { key: 'price', label: 'Price', render: (r) => <div>{r.sale_price ? <><span className="font-semibold">{formatTaka(r.sale_price)}</span> <s className="text-xs text-white/40">{formatTaka(r.regular_price)}</s></> : formatTaka(r.regular_price)}</div> },
              { key: 'stock', label: 'Stock', render: (r) => <div><span>{r.stock}</span> <Badge status={r.stock_status === 'in_stock' ? 'delivered' : r.stock_status === 'low_stock' ? 'pending' : 'cancelled'} />{''}</div> },
              { key: 'active', label: 'Enabled', render: (r) => <Toggle label={`Enable ${r.name}`} checked={r.is_active} onChange={(v) => patch.mutate({ id: r.id, b: { is_active: v } })} /> },
              { key: 'feat', label: 'Featured', hideOnMobile: true, render: (r) => <Toggle label={`Feature ${r.name}`} checked={r.is_featured} onChange={(v) => patch.mutate({ id: r.id, b: { is_featured: v } })} /> },
              { key: 'hero', label: 'In hero', hideOnMobile: true, render: (r) => <Toggle label={`Show ${r.name} in hero`} checked={r.featured_in_hero} onChange={(v) => run(() => adminApi.setHero(r.id, v), v ? 'Added to hero.' : 'Removed from hero.')()} /> },
            ]}
            actions={(r) => { const i = rows.indexOf(r); return (<div className="inline-flex gap-1.5">
              <IconBtn label="Move up" disabled={i === 0 && page === 1} onClick={() => move(i, -1)}><ArrowUp className="h-4 w-4" /></IconBtn>
              <IconBtn label="Move down" disabled={i === rows.length - 1} onClick={() => move(i, 1)}><ArrowDown className="h-4 w-4" /></IconBtn>
              <IconBtn label="Edit" onClick={() => nav(`/admin/products/${r.id}`)}><Pencil className="h-4 w-4" /></IconBtn>
              <IconBtn label="Duplicate" onClick={run(() => adminApi.duplicateProduct(r.id), 'Duplicated as a disabled draft.')}><Copy className="h-4 w-4" /></IconBtn>
              <IconBtn label="Delete" danger onClick={() => del(r)}><Trash2 className="h-4 w-4" /></IconBtn></div>); }} />
          <Pager page={page} total={list.data!.total} limit={LIMIT} onPage={setPage} />
        </>
      )}
    </>
  );
}
