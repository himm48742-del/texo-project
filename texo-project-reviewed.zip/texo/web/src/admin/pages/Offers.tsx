import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Pencil, Plus, Trash2 } from 'lucide-react';
import { useEffect, useState } from 'react';
import type { FormEvent } from 'react';
import { useDebounced } from '../../hooks/queries';
import { formatDate, formatTaka } from '../../lib/format';
import { Badge, Empty, ErrorBlock, Field, IconBtn, Modal, PageHeader, ResponsiveTable, Skeleton, ToggleRow, useConfirm, useToast } from '../components/ui';
import { ImageUploader } from '../components/Uploaders';
import { adminApi } from '../lib/adminApi';
import { fieldErrors, fromLocalInput, toLocalInput, toNumberOrNull } from '../lib/helpers';

const BLANK = { id: '', title: '', offer_text: '', target: 'product' as 'product' | 'category', product_id: '', product_name: '', category_id: '', mode: 'price' as 'price' | 'percent', value: '', starts_at: '', ends_at: '', banner_url: '', is_active: true };
type F = typeof BLANK;

/** Builds the API payload; the SAME object feeds the live server preview and the save request. */
function toBody(f: F, forPreview = false): Record<string, unknown> {
  const b: Record<string, unknown> = {
    title: f.title, offer_text: f.offer_text || null, is_active: f.is_active, starts_at: fromLocalInput(f.starts_at), ends_at: fromLocalInput(f.ends_at), banner_url: f.banner_url || null,
    product_id: f.target === 'product' ? f.product_id || null : null, category_id: f.target === 'category' ? f.category_id || null : null,
    offer_price: f.mode === 'price' && f.target === 'product' ? toNumberOrNull(f.value) : null, discount_percent: f.mode === 'percent' || f.target === 'category' ? toNumberOrNull(f.value) : null,
  };
  if (f.target === 'category') b.offer_price = null;
  if (forPreview && f.id) b.id = f.id;
  return b;
}

function Preview({ f }: { f: F }) {
  const body = useDebounced(toBody(f, true), 400);
  const key = JSON.stringify(body);
  const ready = (body.product_id || body.category_id) && (body.offer_price || body.discount_percent);
  const { data, isFetching, error } = useQuery({ queryKey: ['admin', 'offer-preview', key], queryFn: () => adminApi.previewOffer(body), enabled: !!ready, retry: false });
  if (!ready) return <p className="rounded-xl bg-white/[0.04] p-4 text-sm text-white/50">Choose a product or category and a price or percentage to see the final price customers will pay.</p>;
  if (error) return <p role="alert" className="rounded-xl bg-red-500/10 p-4 text-sm text-red-300">{(error as Error).message}</p>;
  if (!data) return <p className="rounded-xl bg-white/[0.04] p-4 text-sm text-white/50">Calculating…</p>;
  return (
    <div className="space-y-2 rounded-xl border border-white/10 p-4" aria-live="polite" aria-busy={isFetching}>
      <div className="flex items-center justify-between"><p className="text-xs uppercase tracking-wider text-white/45">Preview — actual final price</p>
        <Badge status={{ live: 'delivered', scheduled: 'confirmed', expired: 'cancelled', inactive: 'pending' }[data.status as string] ? data.status === 'live' ? 'delivered' : data.status === 'scheduled' ? 'confirmed' : data.status === 'expired' ? 'cancelled' : 'pending' : 'pending'} /></div>
      {!data.valid && <ul className="space-y-1 text-sm text-red-300">{data.errors.map((e: any, i: number) => <li key={i}>⚠ {e.message}</li>)}</ul>}
      {data.valid && data.items.map((it: any) => (
        <div key={it.productId} className="flex items-center justify-between gap-3 text-sm"><span className="min-w-0 truncate">{it.name}</span>
          <span className="shrink-0">{it.changesPrice ? <><s className="text-white/40">{formatTaka(it.currentFinal)}</s> <b className="text-cyan">{formatTaka(it.newFinal)}</b> <span className="text-xs text-gold">{it.percent}% off</span></> : <span className="text-xs text-white/50">No effect — current price {formatTaka(it.currentFinal)} is already lower</span>}</span></div>))}
      {data.valid && <p className="text-xs text-white/40">{data.status === 'live' ? 'Customers get this price right now.' : data.status === 'scheduled' ? 'Starts later: no effect until then.' : data.status === 'expired' ? 'Already ended: no effect on prices.' : 'Inactive: no effect on prices.'}</p>}
    </div>
  );
}

function ProductPicker({ value, name, onPick, error }: { value: string; name: string; onPick: (id: string, name: string) => void; error?: string }) {
  const [q, setQ] = useState(''); const dq = useDebounced(q, 300);
  const res = useQuery({ queryKey: ['admin', 'picker', dq], queryFn: () => adminApi.products({ q: dq, limit: 6 }), enabled: dq.trim().length >= 2 });
  return (
    <Field label="Product" error={error} htmlFor="o-prod">
      {value && <p className="mb-2 rounded-lg bg-cyan/10 px-3 py-2 text-sm text-cyan">Selected: {name || value}</p>}
      <input id="o-prod" className="input" placeholder="Type to search products…" value={q} onChange={(e) => setQ(e.target.value)} />
      {res.data && <ul className="mt-2 max-h-44 divide-y divide-white/5 overflow-y-auto rounded-xl border border-white/10">{res.data.rows.map((p) => (
        <li key={p.id}><button type="button" className="flex w-full justify-between gap-3 px-3 py-2.5 text-left text-sm hover:bg-white/5" onClick={() => { onPick(p.id, p.name); setQ(''); }}><span className="truncate">{p.name}</span><span className="shrink-0 text-white/45">{formatTaka(p.regular_price)}</span></button></li>))}
        {!res.data.rows.length && <li className="px-3 py-2.5 text-sm text-white/45">No products found.</li>}</ul>}
    </Field>
  );
}

export function AdminOffers() {
  const qc = useQueryClient(); const toast = useToast(); const confirm = useConfirm();
  const { data, isLoading, error, refetch } = useQuery({ queryKey: ['admin', 'offers'], queryFn: () => adminApi.list('offers') });
  const cats = useQuery({ queryKey: ['admin', 'categories'], queryFn: () => adminApi.list('categories') });
  const [edit, setEdit] = useState<F | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({}); const [busy, setBusy] = useState(false);
  const [valid, setValid] = useState(false);
  useEffect(() => { setValid(false); if (!edit) return; const t = setTimeout(async () => { try { setValid((await adminApi.previewOffer(toBody(edit, true))).valid); } catch { setValid(false); } }, 450); return () => clearTimeout(t); }, [edit]);
  const refresh = () => qc.invalidateQueries({ queryKey: ['admin', 'offers'] });
  const patch = (p: Partial<F>) => { setEdit((c) => c && { ...c, ...p }); setErrors({}); };
  async function save(e: FormEvent) {
    e.preventDefault(); if (!edit) return; setBusy(true); setErrors({});
    try { edit.id ? await adminApi.update('offers', edit.id, toBody(edit)) : await adminApi.create('offers', toBody(edit)); await refresh(); setEdit(null); toast('Offer saved.'); }
    catch (err) { setErrors(fieldErrors((err as any).details)); toast((err as Error).message, 'error'); } finally { setBusy(false); }
  }
  async function del(o: any) {
    if (!(await confirm({ title: `Delete offer “${o.title}”?`, message: 'Prices go back to normal immediately for customers.', confirmLabel: 'Delete offer', danger: true }))) return;
    try { await adminApi.remove('offers', o.id); await refresh(); toast('Offer deleted.'); } catch (e) { toast((e as Error).message, 'error'); }
  }
  const status = (o: any) => !o.is_active ? 'inactive' : o.starts_at && Date.parse(o.starts_at) > Date.now() ? 'scheduled' : o.ends_at && Date.parse(o.ends_at) <= Date.now() ? 'expired' : 'live';
  const tone = (s: string) => ({ live: 'delivered', scheduled: 'confirmed', expired: 'cancelled', inactive: 'pending' } as Record<string, string>)[s];
  return (
    <>
      <PageHeader title="Offers" subtitle="Offers change the real checkout price while they are live." action={<button className="btn btn-primary" onClick={() => { setErrors({}); setEdit({ ...BLANK }); }}><Plus className="h-4 w-4" /> New offer</button>} />
      {isLoading ? <Skeleton /> : error ? <ErrorBlock error={error} retry={() => refetch()} /> : !data?.length ? <Empty title="No offers yet." /> : (
        <ResponsiveTable rows={data} rowKey={(r) => r.id}
          cols={[
            { key: 't', label: 'Offer', render: (r) => <div className="text-left"><p className="font-medium">{r.title}</p><p className="text-xs text-white/40">{r.product_id ? 'Product offer' : 'Category offer'}</p></div> },
            { key: 'v', label: 'Discount', render: (r) => (r.offer_price ? `Fixed ${formatTaka(r.offer_price)}` : `${r.discount_percent}% off`) },
            { key: 'w', label: 'Dates', render: (r) => <span className="text-xs">{r.starts_at ? formatDate(r.starts_at) : 'Now'} → {r.ends_at ? formatDate(r.ends_at) : 'No end'}</span> },
            { key: 's', label: 'Status', render: (r) => <Badge status={tone(status(r))} /> },
          ]}
          actions={(r) => <div className="inline-flex gap-1.5"><IconBtn label="Edit" onClick={() => { setErrors({}); setEdit({ id: r.id, title: r.title, offer_text: r.offer_text ?? '', target: r.product_id ? 'product' : 'category', product_id: r.product_id ?? '', product_name: '', category_id: r.category_id ?? '', mode: r.offer_price ? 'price' : 'percent', value: String(r.offer_price ?? r.discount_percent ?? ''), starts_at: toLocalInput(r.starts_at), ends_at: toLocalInput(r.ends_at), banner_url: r.banner_url ?? '', is_active: r.is_active }); }}><Pencil className="h-4 w-4" /></IconBtn>
            <IconBtn label="Delete" danger onClick={() => del(r)}><Trash2 className="h-4 w-4" /></IconBtn></div>} />
      )}
      <Modal wide open={!!edit} onClose={() => setEdit(null)} title={edit?.id ? 'Edit offer' : 'New offer'}>
        {edit && <form onSubmit={save} className="space-y-4" noValidate>
          <Field label="Offer title" error={errors.title} htmlFor="o-title"><input id="o-title" className="input" value={edit.title} onChange={(e) => patch({ title: e.target.value })} autoFocus /></Field>
          <Field label="Offer text (shown to customers)" htmlFor="o-text"><input id="o-text" className="input" value={edit.offer_text} onChange={(e) => patch({ offer_text: e.target.value })} /></Field>
          <fieldset className="grid grid-cols-2 gap-2"><legend className="label">Applies to</legend>
            {(['product', 'category'] as const).map((t) => <label key={t} className={`flex min-h-[48px] cursor-pointer items-center justify-center rounded-xl border text-sm ${edit.target === t ? 'border-cyan bg-cyan/10 text-cyan' : 'border-white/15'}`}><input type="radio" className="sr-only" checked={edit.target === t} onChange={() => patch({ target: t, mode: t === 'category' ? 'percent' : edit.mode })} />{t === 'product' ? 'One product' : 'A whole category'}</label>)}</fieldset>
          {edit.target === 'product' ? <ProductPicker value={edit.product_id} name={edit.product_name} error={errors.product_id} onPick={(id, name) => patch({ product_id: id, product_name: name })} />
            : <Field label="Category" error={errors.category_id ?? errors.product_id} htmlFor="o-cat"><select id="o-cat" className="input" value={edit.category_id} onChange={(e) => patch({ category_id: e.target.value })}><option value="">Select category</option>{cats.data?.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></Field>}
          <div className="grid gap-4 sm:grid-cols-2">
            <fieldset><legend className="label">Discount type</legend><div className="grid grid-cols-2 gap-2">
              {(['price', 'percent'] as const).map((m) => <label key={m} className={`flex min-h-[48px] items-center justify-center rounded-xl border text-sm ${edit.target === 'category' && m === 'price' ? 'cursor-not-allowed opacity-30' : 'cursor-pointer'} ${edit.mode === m ? 'border-cyan bg-cyan/10 text-cyan' : 'border-white/15'}`}><input type="radio" className="sr-only" disabled={edit.target === 'category' && m === 'price'} checked={edit.mode === m} onChange={() => patch({ mode: m, value: '' })} />{m === 'price' ? 'Fixed price' : 'Percentage'}</label>)}</div></fieldset>
            <Field label={edit.mode === 'price' ? 'Offer price' : 'Percent off (1–99)'} error={errors.offer_price ?? errors.discount_percent} htmlFor="o-val"><input id="o-val" className="input" inputMode="decimal" value={edit.value} onChange={(e) => patch({ value: e.target.value })} /></Field>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Start (optional)" error={errors.starts_at} htmlFor="o-s"><input id="o-s" type="datetime-local" className="input" value={edit.starts_at} onChange={(e) => patch({ starts_at: e.target.value })} /></Field>
            <Field label="End (optional)" error={errors.ends_at} htmlFor="o-e"><input id="o-e" type="datetime-local" className="input" value={edit.ends_at} onChange={(e) => patch({ ends_at: e.target.value })} /></Field>
          </div>
          <ImageUploader label="Banner (optional)" folder="offers" value={edit.banner_url} onUploaded={(url) => patch({ banner_url: url })} onRemove={() => patch({ banner_url: '' })} />
          <ToggleRow label="Active" hint="Inactive offers never affect prices." checked={edit.is_active} onChange={(v) => patch({ is_active: v })} />
          <Preview f={edit} />
          <div className="flex justify-end gap-3 pt-2"><button type="button" className="btn btn-ghost" onClick={() => setEdit(null)}>Cancel</button><button className="btn btn-primary" disabled={busy || !valid} title={valid ? '' : 'Fix the issues in the preview first'}>{busy ? 'Saving…' : 'Save offer'}</button></div>
        </form>}
      </Modal>
    </>
  );
}
