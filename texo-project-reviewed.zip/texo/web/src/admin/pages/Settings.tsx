import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useEffect, useState } from 'react';
import type { ReactNode } from 'react';
import { ErrorBlock, Field, PageHeader, Skeleton, ToggleRow, useToast } from '../components/ui';
import { adminApi } from '../lib/adminApi';
import { fieldErrors, toNumberOrNull } from '../lib/helpers';

type S = Record<string, string>;
const TABS = ['General', 'Contact & social', 'Delivery', 'Welcome animation', 'Hero animation'] as const;
type Tab = (typeof TABS)[number];
const social = (s: any, k: string) => String(s.social_links?.[k] ?? '');

export function AdminSettings() {
  const qc = useQueryClient(); const toast = useToast();
  const { data, isLoading, error, refetch } = useQuery({ queryKey: ['admin', 'settings'], queryFn: adminApi.settings });
  const [tab, setTab] = useState<Tab>('General');
  const [v, setV] = useState<S>({}); const [flags, setFlags] = useState({ welcome_enabled: true, hero_autoplay: true });
  const [errors, setErrors] = useState<Record<string, string>>({}); const [busy, setBusy] = useState(false);
  useEffect(() => {
    if (!data) return;
    const str = (k: string, d = '') => String(data[k] ?? d);
    setV({
      brand_name: str('brand_name', 'TEXO'), tagline: str('tagline', 'YOUR TECH.'), footer_text: str('footer_text'), currency: str('currency', 'BDT'), currency_symbol: str('currency_symbol', '৳'),
      business_phone: str('business_phone'), whatsapp_number: str('whatsapp_number'), email: social(data, 'email'), facebook: social(data, 'facebook'), instagram: social(data, 'instagram'), youtube: social(data, 'youtube'), tiktok: social(data, 'tiktok'),
      delivery_inside_dhaka: str('delivery_inside_dhaka', '60'), delivery_outside_dhaka: str('delivery_outside_dhaka', '120'), free_delivery_threshold: str('free_delivery_threshold', '0'),
      welcome_line1: str('welcome_line1'), welcome_line2: str('welcome_line2'), hero_animation_speed: str('hero_animation_speed', '1'),
      hero_rotation_seconds: str('hero_rotation_seconds', '6'), hero_headline: str('hero_headline'), hero_description: str('hero_description'),
    });
    setFlags({ welcome_enabled: data.welcome_enabled !== false, hero_autoplay: data.hero_autoplay !== false });
  }, [data]);
  const set = (k: string, val: string) => { setV((c) => ({ ...c, [k]: val })); setErrors((e) => ({ ...e, [k]: '' })); };
  const inp = (k: string, label: string, extra: Record<string, unknown> = {}, hint?: string) => (
    <Field label={label} error={errors[k] ?? errors[`social_links.${k}`]} hint={hint} htmlFor={`s-${k}`}><input id={`s-${k}`} className="input" value={v[k] ?? ''} onChange={(e) => set(k, e.target.value)} {...extra} /></Field>
  );
  const body = (): Record<string, unknown> => {
    const num = (k: string) => toNumberOrNull(v[k] ?? '');
    switch (tab) {
      case 'General': return { brand_name: v.brand_name, tagline: v.tagline, footer_text: v.footer_text, currency: v.currency.toUpperCase(), currency_symbol: v.currency_symbol };
      case 'Contact & social': return { business_phone: v.business_phone, whatsapp_number: v.whatsapp_number, social_links: { email: v.email, facebook: v.facebook, instagram: v.instagram, youtube: v.youtube, tiktok: v.tiktok } };
      case 'Delivery': return { delivery_inside_dhaka: num('delivery_inside_dhaka'), delivery_outside_dhaka: num('delivery_outside_dhaka'), free_delivery_threshold: num('free_delivery_threshold') };
      case 'Welcome animation': return { welcome_enabled: flags.welcome_enabled, welcome_line1: v.welcome_line1, welcome_line2: v.welcome_line2, brand_name: v.brand_name, tagline: v.tagline, hero_animation_speed: num('hero_animation_speed') };
      default: return {};
      case 'Hero animation': return { hero_autoplay: flags.hero_autoplay, hero_rotation_seconds: num('hero_rotation_seconds'), hero_animation_speed: num('hero_animation_speed'), hero_headline: v.hero_headline, hero_description: v.hero_description };
    }
  };
  async function save() {
    setBusy(true); setErrors({});
    try { await adminApi.saveSettings(body()); await qc.invalidateQueries({ queryKey: ['admin', 'settings'] }); qc.invalidateQueries({ queryKey: ['settings'] }); toast('Settings saved. The storefront updates within a minute.'); }
    catch (e) { setErrors(fieldErrors((e as any).details)); toast((e as Error).message, 'error'); } finally { setBusy(false); }
  }
  if (isLoading) return <><PageHeader title="Settings" /><Skeleton rows={6} /></>;
  if (error) return <><PageHeader title="Settings" /><ErrorBlock error={error} retry={() => refetch()} /></>;
  const Panel = ({ children }: { children: ReactNode }) => <div className="card max-w-2xl space-y-4 p-5 sm:p-6">{children}</div>;
  return (
    <>
      <PageHeader title="Settings" subtitle="Changes are stored in the database and appear on the storefront." />
      <div role="tablist" aria-label="Settings sections" className="mb-5 flex gap-1 overflow-x-auto border-b border-white/10">
        {TABS.map((t) => <button key={t} role="tab" aria-selected={tab === t} onClick={() => { setTab(t); setErrors({}); }} className={`shrink-0 border-b-2 px-4 py-3 text-sm font-medium ${tab === t ? 'border-cyan text-cyan' : 'border-transparent text-white/55 hover:text-white'}`}>{t}</button>)}
      </div>
      <div role="tabpanel">
        {tab === 'General' && <Panel>{inp('brand_name', 'Brand name')}{inp('tagline', 'Tagline')}{inp('footer_text', 'Footer text')}
          <div className="grid gap-4 sm:grid-cols-2">{inp('currency', 'Currency code', { maxLength: 3 }, 'e.g. BDT')}{inp('currency_symbol', 'Currency symbol', { maxLength: 4 }, 'e.g. ৳')}</div></Panel>}
        {tab === 'Contact & social' && <Panel>{inp('business_phone', 'Business phone', { inputMode: 'tel' })}{inp('whatsapp_number', 'WhatsApp number', { inputMode: 'tel' }, 'Used by the “Order via WhatsApp” button. Example: 01601603092')}
          {inp('email', 'Email', { type: 'email' })}{inp('facebook', 'Facebook page link', { placeholder: 'https://facebook.com/…' })}{inp('instagram', 'Instagram link', { placeholder: 'https://instagram.com/…' })}{inp('youtube', 'YouTube link')}{inp('tiktok', 'TikTok link')}</Panel>}
        {tab === 'Delivery' && <Panel>{inp('delivery_inside_dhaka', 'Inside Dhaka charge', { inputMode: 'decimal' })}{inp('delivery_outside_dhaka', 'Outside Dhaka charge', { inputMode: 'decimal' })}
          {inp('free_delivery_threshold', 'Free delivery threshold', { inputMode: 'decimal' }, 'Orders at or above this subtotal ship free. Use 0 to turn free delivery off.')}</Panel>}
        {tab === 'Welcome animation' && <Panel><ToggleRow label="Show the welcome intro" hint="First visit: full intro. Later visits: short. Visitors can always skip." checked={flags.welcome_enabled} onChange={(x) => setFlags({ ...flags, welcome_enabled: x })} />
          {inp('welcome_line1', 'Welcome line 1')}{inp('welcome_line2', 'Welcome line 2')}{inp('brand_name', 'Brand name')}{inp('tagline', 'Tagline')}
          {inp('hero_animation_speed', 'Animation speed', { inputMode: 'decimal' }, '0.5 = slow, 1 = normal, 2 = fast (also used by the hero).')}</Panel>}
        {tab === 'Hero animation' && <Panel><ToggleRow label="Autoplay" hint="Off = the showcase only changes when visitors press next/play." checked={flags.hero_autoplay} onChange={(x) => setFlags({ ...flags, hero_autoplay: x })} />
          {inp('hero_rotation_seconds', 'Seconds per product', { inputMode: 'decimal' }, 'Between 3 and 30.')}{inp('hero_animation_speed', 'Animation speed', { inputMode: 'decimal' }, 'Between 0.5 and 2.')}
          {inp('hero_headline', 'Homepage headline', {}, 'Use a new line for each row.')}{inp('hero_description', 'Homepage description')}
          <p className="text-sm text-white/45">Choose which products rotate on the “Hero showcase” page.</p></Panel>}
        <button className="btn btn-primary mt-5" onClick={save} disabled={busy}>{busy ? 'Saving…' : `Save ${tab.toLowerCase()}`}</button>
      </div>
    </>
  );
}
