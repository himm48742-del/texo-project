import { useQuery } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { formatTaka } from '../../lib/format';
import { Badge, Empty, ErrorBlock, PageHeader, Skeleton } from '../components/ui';
import { adminApi } from '../lib/adminApi';

const Stat = ({ label, value, to }: { label: string; value: string | number; to?: string }) => {
  const inner = <div className="card p-5 transition hover:border-cyan/40"><p className="text-xs uppercase tracking-wider text-white/45">{label}</p><p className="mt-2 font-display text-2xl font-bold sm:text-3xl">{value}</p></div>;
  return to ? <Link to={to}>{inner}</Link> : inner;
};

export function Dashboard() {
  const { data: s, isLoading, error, refetch } = useQuery({ queryKey: ['admin', 'stats'], queryFn: adminApi.stats });
  if (isLoading) return <><PageHeader title="Dashboard" /><Skeleton rows={6} /></>;
  if (error || !s) return <><PageHeader title="Dashboard" /><ErrorBlock error={error} retry={() => refetch()} /></>;
  const st = s.by_status ?? {};
  const days: { day: string; orders: number; sales: number }[] = s.last_14_days ?? [];
  const max = Math.max(1, ...days.map((d) => Number(d.sales)));
  return (
    <>
      <PageHeader title="Dashboard" subtitle="Live numbers from your database" />
      <div className="grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4">
        <Stat label="Products" value={s.products} to="/admin/products" /><Stat label="Categories" value={s.categories} to="/admin/categories" />
        <Stat label="Total orders" value={s.orders} to="/admin/orders" /><Stat label="Total sales" value={formatTaka(Number(s.total_sales))} />
        <Stat label="Pending" value={st.pending ?? 0} to="/admin/orders" /><Stat label="Confirmed" value={st.confirmed ?? 0} to="/admin/orders" />
        <Stat label="Delivered" value={st.delivered ?? 0} to="/admin/orders" /><Stat label="Delivered sales" value={formatTaka(Number(s.delivered_sales))} />
      </div>
      <section className="card mt-6 p-5" aria-label="Sales, last 14 days">
        <h2 className="font-display text-lg font-semibold">Sales — last 14 days</h2>
        <div className="mt-4 flex h-40 items-end gap-1.5" role="img" aria-label={`Bar chart of daily sales, highest ${formatTaka(max)}`}>
          {days.map((d) => (
            <div key={d.day} className="group relative flex h-full flex-1 items-end" title={`${d.day}: ${formatTaka(Number(d.sales))} (${d.orders} orders)`}>
              <div className="w-full rounded-t bg-gradient-to-t from-electric to-cyan transition group-hover:brightness-125" style={{ height: `${Math.max(2, (Number(d.sales) / max) * 100)}%` }} />
            </div>
          ))}
        </div>
        <div className="mt-2 flex justify-between text-[11px] text-white/35"><span>{days[0]?.day}</span><span>{days[days.length - 1]?.day}</span></div>
      </section>
      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <section aria-label="Recent orders"><h2 className="mb-3 font-display text-lg font-semibold">Recent orders</h2>
          {s.recent_orders?.length ? <ul className="card divide-y divide-white/5">{s.recent_orders.map((o: any) => (
            <li key={o.id} className="flex items-center justify-between gap-3 px-4 py-3 text-sm"><div className="min-w-0"><p className="truncate font-medium">#{o.order_no} · {o.customer_name}</p><p className="text-xs text-white/40">{new Date(o.created_at).toLocaleString()}</p></div><div className="text-right"><p>{formatTaka(Number(o.total))}</p><Badge status={o.status} /></div></li>))}</ul>
            : <Empty title="No orders yet." />}</section>
        <section aria-label="Low stock"><h2 className="mb-3 font-display text-lg font-semibold">Low stock</h2>
          {s.low_stock?.length ? <ul className="card divide-y divide-white/5">{s.low_stock.map((p: any) => (
            <li key={p.id} className="flex items-center justify-between gap-3 px-4 py-3 text-sm"><Link to={`/admin/products/${p.id}`} className="min-w-0 truncate hover:text-cyan">{p.name}<span className="ml-2 text-xs text-white/35">{p.sku}</span></Link><span className={p.stock === 0 ? 'text-red-400' : 'text-gold'}>{p.stock} left</span></li>))}</ul>
            : <Empty title="All products are well stocked." />}</section>
      </div>
    </>
  );
}
