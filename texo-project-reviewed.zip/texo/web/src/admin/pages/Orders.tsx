import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useState } from 'react';
import { useDebounced } from '../../hooks/queries';
import { formatTaka } from '../../lib/format';
import { Badge, Empty, ErrorBlock, Modal, Pager, PageHeader, ResponsiveTable, Skeleton, useConfirm, useToast } from '../components/ui';
import { adminApi } from '../lib/adminApi';
import { orderDiscount, STATUSES } from '../lib/helpers';

const LIMIT = 25;
const when = (iso: string) => new Date(iso).toLocaleString(undefined, { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });

function StatusSelect({ order, onChange, id }: { order: any; onChange: (s: string) => void; id?: string }) {
  const cancelled = order.status === 'cancelled';
  return (
    <select id={id} aria-label={`Status of order ${order.order_no}`} className="input min-h-[40px] py-0 text-sm" value={order.status} disabled={cancelled} onChange={(e) => onChange(e.target.value)} title={cancelled ? 'Cancelled orders cannot be reopened' : ''}>
      {STATUSES.map((s) => <option key={s} value={s}>{s[0].toUpperCase() + s.slice(1)}</option>)}
    </select>
  );
}

export function AdminOrders() {
  const qc = useQueryClient(); const toast = useToast(); const confirm = useConfirm();
  const [f, setF] = useState({ status: '', q: '', phone: '', from: '', to: '', productId: '' });
  const [page, setPage] = useState(1); const [open, setOpen] = useState<any | null>(null);
  const dq = useDebounced(f.q, 300), dp = useDebounced(f.phone, 300);
  const params = { ...f, q: dq, phone: dp, page, limit: LIMIT };
  const list = useQuery({ queryKey: ['admin', 'orders', params], queryFn: () => adminApi.orders(params) });
  const prods = useQuery({ queryKey: ['admin', 'products', 'all-100'], queryFn: () => adminApi.products({ limit: 100 }), staleTime: 60_000 });
  const set = (k: keyof typeof f, v: string) => { setF((c) => ({ ...c, [k]: v })); setPage(1); };

  async function changeStatus(o: any, status: string) {
    if (status === o.status) return;
    if (status === 'cancelled' && !(await confirm({ title: `Cancel order #${o.order_no}?`, message: 'The ordered quantities are returned to stock automatically. A cancelled order cannot be reopened.', confirmLabel: 'Cancel order', danger: true }))) return;
    try { const r = await adminApi.setOrderStatus(o.id, status); await qc.invalidateQueries({ queryKey: ['admin', 'orders'] }); await qc.invalidateQueries({ queryKey: ['admin', 'stats'] }); setOpen((c: any) => (c && c.id === o.id ? { ...c, status: r.status ?? status } : c)); toast(status === 'cancelled' ? 'Order cancelled and stock restored.' : `Order #${o.order_no} is now ${status}.`); }
    catch (e) { toast((e as Error).message, 'error'); }
  }
  const rows = list.data?.rows ?? [];
  const items = (o: any) => (o.order_items ?? []) as any[];
  return (
    <>
      <PageHeader title="Orders" subtitle={`${list.data?.total ?? '…'} orders`} />
      <div className="mb-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-6">
        <input className="input lg:col-span-2" placeholder="Search name, phone or order #" aria-label="Search orders" value={f.q} onChange={(e) => set('q', e.target.value)} />
        <input className="input" placeholder="Phone" aria-label="Filter by phone" inputMode="tel" value={f.phone} onChange={(e) => set('phone', e.target.value)} />
        <select className="input" aria-label="Filter by status" value={f.status} onChange={(e) => set('status', e.target.value)}><option value="">All statuses</option>{STATUSES.map((s) => <option key={s} value={s}>{s[0].toUpperCase() + s.slice(1)}</option>)}</select>
        <select className="input" aria-label="Filter by product" value={f.productId} onChange={(e) => set('productId', e.target.value)}><option value="">All products</option>{prods.data?.rows.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}</select>
        <div className="grid grid-cols-2 gap-2"><input type="date" className="input px-2" aria-label="From date" value={f.from} onChange={(e) => set('from', e.target.value)} /><input type="date" className="input px-2" aria-label="To date" value={f.to} onChange={(e) => set('to', e.target.value)} /></div>
      </div>
      {list.isLoading ? <Skeleton /> : list.error ? <ErrorBlock error={list.error} retry={() => list.refetch()} /> : !rows.length ? <Empty title="No orders match these filters." /> : (
        <>
          <ResponsiveTable rows={rows} rowKey={(r) => r.id} onRowClick={setOpen}
            cols={[
              { key: 'n', label: 'Order', render: (r) => <b>#{r.order_no}</b> },
              { key: 'c', label: 'Customer', render: (r) => <div className="text-left"><p className="font-medium">{r.customer_name}</p><p className="text-xs text-white/40">{r.phone}</p></div> },
              { key: 'p', label: 'Items', render: (r) => <span className="text-left text-xs text-white/70">{items(r).map((i) => `${i.product_name} × ${i.quantity}`).join(', ')}</span> },
              { key: 't', label: 'Total', render: (r) => <b>{formatTaka(Number(r.total))}</b> },
              { key: 'd', label: 'Date', hideOnMobile: true, render: (r) => <span className="text-xs">{when(r.created_at)}</span> },
              { key: 's', label: 'Status', render: (r) => <div onClick={(e) => e.stopPropagation()} className="min-w-[130px]"><StatusSelect order={r} onChange={(s) => changeStatus(r, s)} /></div> },
            ]} />
          <Pager page={page} total={list.data!.total} limit={LIMIT} onPage={setPage} />
        </>
      )}
      <Modal wide open={!!open} onClose={() => setOpen(null)} title={open ? `Order #${open.order_no}` : ''}>
        {open && (
          <div className="space-y-5 text-sm">
            <div className="flex flex-wrap items-center justify-between gap-3"><div><Badge status={open.status} /><span className="ml-3 text-white/45">{when(open.created_at)} · via {open.source}</span></div><div className="w-44"><StatusSelect order={open} onChange={(s) => changeStatus(open, s)} /></div></div>
            <dl className="grid gap-3 sm:grid-cols-2">
              <div><dt className="label">Customer</dt><dd>{open.customer_name}</dd></div><div><dt className="label">Phone</dt><dd><a className="text-cyan" href={`tel:${open.phone}`}>{open.phone}</a></dd></div>
              <div className="sm:col-span-2"><dt className="label">Address</dt><dd>{open.address}{open.area ? `, ${open.area}` : ''}, {open.district} <span className="text-white/40">({open.delivery_zone === 'inside_dhaka' ? 'Inside Dhaka' : 'Outside Dhaka'})</span></dd></div>
              {open.notes && <div className="sm:col-span-2"><dt className="label">Notes</dt><dd>{open.notes}</dd></div>}
            </dl>
            <table className="w-full text-left"><thead className="text-xs uppercase text-white/40"><tr><th className="py-2">Product</th><th>Qty</th><th className="text-right">Price</th><th className="text-right">Line total</th></tr></thead>
              <tbody className="divide-y divide-white/5">{items(open).map((i) => (
                <tr key={i.id}><td className="py-2.5">{i.product_name}</td><td>{i.quantity}</td>
                  <td className="text-right">{Number(i.unit_regular) > Number(i.unit_price) && <s className="mr-2 text-white/40">{formatTaka(Number(i.unit_regular))}</s>}{formatTaka(Number(i.unit_price))}</td><td className="text-right">{formatTaka(Number(i.unit_price) * i.quantity)}</td></tr>))}</tbody></table>
            <dl className="ml-auto max-w-xs space-y-1.5">
              <div className="flex justify-between"><dt className="text-white/55">Subtotal</dt><dd>{formatTaka(Number(open.subtotal))}</dd></div>
              <div className="flex justify-between"><dt className="text-white/55">Discount given</dt><dd className="text-gold">{formatTaka(orderDiscount(items(open)))}</dd></div>
              <div className="flex justify-between"><dt className="text-white/55">Delivery</dt><dd>{formatTaka(Number(open.delivery_charge))}</dd></div>
              <div className="flex justify-between border-t border-white/10 pt-2 text-base font-bold"><dt>Total</dt><dd>{formatTaka(Number(open.total))}</dd></div>
            </dl>
          </div>
        )}
      </Modal>
    </>
  );
}
