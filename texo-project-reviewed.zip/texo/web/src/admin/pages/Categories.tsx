import { useQuery, useQueryClient } from '@tanstack/react-query';
import { ArrowDown, ArrowUp, Pencil, Plus, Trash2 } from 'lucide-react';
import { useState } from 'react';
import type { FormEvent } from 'react';
import { ProductImage } from '../../components/ProductImage';
import { Empty, ErrorBlock, Field, IconBtn, Modal, PageHeader, ResponsiveTable, Skeleton, Toggle, ToggleRow, useConfirm, useToast } from '../components/ui';
import { ImageUploader } from '../components/Uploaders';
import { adminApi } from '../lib/adminApi';
import { fieldErrors, moveItem } from '../lib/helpers';

const BLANK = { id: '', name: '', slug: '', icon_url: '', is_active: true };
export function AdminCategories() {
  const qc = useQueryClient(); const toast = useToast(); const confirm = useConfirm();
  const { data, isLoading, error, refetch } = useQuery({ queryKey: ['admin', 'categories'], queryFn: () => adminApi.list('categories') });
  const [edit, setEdit] = useState<typeof BLANK | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({}); const [busy, setBusy] = useState(false);
  const refresh = () => qc.invalidateQueries({ queryKey: ['admin', 'categories'] });

  async function save(e: FormEvent) {
    e.preventDefault(); if (!edit) return; setBusy(true); setErrors({});
    const b: Record<string, unknown> = { name: edit.name, icon_url: edit.icon_url || null, is_active: edit.is_active };
    if (edit.slug.trim()) b.slug = edit.slug.trim();
    try { edit.id ? await adminApi.update('categories', edit.id, b) : await adminApi.create('categories', b); await refresh(); setEdit(null); toast('Category saved.'); }
    catch (err) { setErrors(fieldErrors((err as any).details)); toast((err as Error).message, 'error'); } finally { setBusy(false); }
  }
  async function move(i: number, d: number) {
    const cur = data!.map((c) => c.id as string); const ids = moveItem<string>(cur, i, i + d);
    if (ids === cur) return;
    try { await adminApi.reorder('categories', ids); await refresh(); } catch (e) { toast((e as Error).message, 'error'); }
  }
  async function del(c: any) {
    if (!(await confirm({ title: `Delete “${c.name}”?`, message: 'Products in this category are kept but become uncategorised. This cannot be undone.', confirmLabel: 'Delete category', danger: true }))) return;
    try { await adminApi.remove('categories', c.id); await refresh(); toast('Category deleted.'); } catch (e) { toast((e as Error).message, 'error'); }
  }
  async function toggle(c: any, v: boolean) { try { await adminApi.update('categories', c.id, { is_active: v }); await refresh(); } catch (e) { toast((e as Error).message, 'error'); } }
  return (
    <>
      <PageHeader title="Categories" subtitle="Shown in the storefront sidebar, in this order." action={<button className="btn btn-primary" onClick={() => { setErrors({}); setEdit({ ...BLANK }); }}><Plus className="h-4 w-4" /> Add category</button>} />
      {isLoading ? <Skeleton /> : error ? <ErrorBlock error={error} retry={() => refetch()} /> : !data?.length ? <Empty title="No categories yet." /> : (
        <ResponsiveTable rows={data} rowKey={(r) => r.id}
          cols={[
            { key: 'n', label: 'Category', render: (r) => <div className="flex items-center gap-3"><ProductImage src={r.icon_url} alt="" className="h-10 w-10 rounded-lg border border-white/10" /><div className="text-left"><p className="font-medium">{r.name}</p><p className="text-xs text-white/40">/{r.slug}</p></div></div> },
            { key: 'a', label: 'Enabled', render: (r) => <Toggle label={`Enable ${r.name}`} checked={r.is_active} onChange={(v) => toggle(r, v)} /> },
          ]}
          actions={(r) => { const i = data.indexOf(r); return <div className="inline-flex gap-1.5">
            <IconBtn label="Move up" disabled={i === 0} onClick={() => move(i, -1)}><ArrowUp className="h-4 w-4" /></IconBtn><IconBtn label="Move down" disabled={i === data.length - 1} onClick={() => move(i, 1)}><ArrowDown className="h-4 w-4" /></IconBtn>
            <IconBtn label="Edit" onClick={() => { setErrors({}); setEdit({ id: r.id, name: r.name, slug: r.slug, icon_url: r.icon_url ?? '', is_active: r.is_active }); }}><Pencil className="h-4 w-4" /></IconBtn>
            <IconBtn label="Delete" danger onClick={() => del(r)}><Trash2 className="h-4 w-4" /></IconBtn></div>; }} />
      )}
      <Modal open={!!edit} onClose={() => setEdit(null)} title={edit?.id ? 'Edit category' : 'Add category'}>
        {edit && <form onSubmit={save} className="space-y-4" noValidate>
          <Field label="Name" error={errors.name} htmlFor="c-name"><input id="c-name" className="input" value={edit.name} onChange={(e) => setEdit({ ...edit, name: e.target.value })} autoFocus /></Field>
          <Field label="URL slug" error={errors.slug} hint="Leave blank to generate from the name." htmlFor="c-slug"><input id="c-slug" className="input" value={edit.slug} onChange={(e) => setEdit({ ...edit, slug: e.target.value })} /></Field>
          <ImageUploader label="Icon / image" folder="categories" value={edit.icon_url} onUploaded={(url) => setEdit((c) => c && { ...c, icon_url: url })} onRemove={() => setEdit((c) => c && { ...c, icon_url: '' })} />
          <ToggleRow label="Enabled" checked={edit.is_active} onChange={(v) => setEdit({ ...edit, is_active: v })} />
          <div className="flex justify-end gap-3 pt-2"><button type="button" className="btn btn-ghost" onClick={() => setEdit(null)}>Cancel</button><button className="btn btn-primary" disabled={busy}>{busy ? 'Saving…' : 'Save'}</button></div>
        </form>}
      </Modal>
    </>
  );
}
