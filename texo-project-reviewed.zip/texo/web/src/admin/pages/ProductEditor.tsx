import { useQuery, useQueryClient } from '@tanstack/react-query';
import { ArrowLeft, Plus, Trash2 } from 'lucide-react';
import { useEffect, useState } from 'react';
import type { FormEvent, ReactNode } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { formatTaka } from '../../lib/format';
import { ErrorBlock, Field, PageHeader, Skeleton, ToggleRow, useToast } from '../components/ui';
import { GalleryManager, ImageUploader, ModelUploader } from '../components/Uploaders';
import { adminApi } from '../lib/adminApi';
import { discountPreview, fieldErrors, percentToSale, saleToPercent, toNumberOrNull } from '../lib/helpers';

const EMPTY = {
  name: '', slug: '', sku: '', category_id: '', short_desc: '', full_desc: '', regular_price: '', sale_price: '', discount_percent: '', order_button_enabled: true, order_button_text: '', stock: '0', stock_status: 'auto', offer_text: '',
  main_image_url: '', thumb_url: '', features: '', specs: [{ k: '', v: '' }] as { k: string; v: string }[],
  is_active: true, is_featured: false, featured_in_hero: false, hero_order: '', display_order: '',
};
type Form = typeof EMPTY;
const Section = ({ title, children }: { title: string; children: ReactNode }) => <section className="card space-y-4 p-5"><h2 className="font-display text-lg font-semibold">{title}</h2>{children}</section>;

export function ProductEditor() {
  const { id } = useParams(); const isNew = !id || id === 'new';
  const nav = useNavigate(); const qc = useQueryClient(); const toast = useToast();
  const [f, setF] = useState<Form>(EMPTY);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  const cats = useQuery({ queryKey: ['admin', 'categories'], queryFn: () => adminApi.list('categories') });
  const prod = useQuery({ queryKey: ['admin', 'product', id], queryFn: () => adminApi.product(id!), enabled: !isNew });
  const p = prod.data;
  useEffect(() => {
    if (!p) return;
    setF({
      name: p.name ?? '', slug: p.slug ?? '', sku: p.sku ?? '', category_id: p.category_id ?? '', short_desc: p.short_desc ?? '', full_desc: p.full_desc ?? '',
      regular_price: String(p.regular_price ?? ''), sale_price: p.sale_price == null ? '' : String(p.sale_price), discount_percent: p.sale_price == null ? '' : String(p.discount_percent || ''), order_button_enabled: p.order_button_enabled !== false, order_button_text: p.order_button_text ?? '', stock: String(p.stock ?? 0), stock_status: 'auto', offer_text: p.offer_text ?? '',
      main_image_url: p.main_image_url ?? '', thumb_url: p.thumb_url ?? '', features: (p.features ?? []).join('\n'),
      specs: Object.entries(p.specifications ?? {}).map(([k, v]) => ({ k, v: String(v) })).concat([{ k: '', v: '' }]),
      is_active: !!p.is_active, is_featured: !!p.is_featured, featured_in_hero: !!p.featured_in_hero, hero_order: String(p.hero_order ?? ''), display_order: String(p.display_order ?? ''),
    });
  }, [p]);
  const set = <K extends keyof Form>(k: K, v: Form[K]) => { setF((c) => ({ ...c, [k]: v })); setErrors((e) => ({ ...e, [k]: '' })); };
  const preview = discountPreview(f.regular_price, f.sale_price);
  const reload = () => qc.invalidateQueries({ queryKey: ['admin', 'product', id] });

  function payload() {
    const b: Record<string, unknown> = {
      name: f.name, sku: f.sku, category_id: f.category_id || null, short_desc: f.short_desc || null, full_desc: f.full_desc || null,
      regular_price: toNumberOrNull(f.regular_price), sale_price: toNumberOrNull(f.sale_price), stock: toNumberOrNull(f.stock) ?? 0, offer_text: f.offer_text || null,
      main_image_url: f.main_image_url || null, thumb_url: f.thumb_url || null,
      features: f.features.split('\n').map((s) => s.trim()).filter(Boolean),
      specifications: Object.fromEntries(f.specs.filter((s) => s.k.trim() && s.v.trim()).map((s) => [s.k.trim(), s.v.trim()])),
      is_active: f.is_active, is_featured: f.is_featured, featured_in_hero: f.featured_in_hero,
      order_button_enabled: f.order_button_enabled, order_button_text: f.order_button_text.trim() || null,
    };
    if (f.slug.trim()) b.slug = f.slug.trim();
    if (f.stock_status !== 'auto') b.stock_status = f.stock_status;
    const ho = toNumberOrNull(f.hero_order), dorder = toNumberOrNull(f.display_order);
    if (ho !== null) b.hero_order = ho; if (dorder !== null) b.display_order = dorder;
    return b;
  }
  async function save(e: FormEvent) {
    e.preventDefault(); setBusy(true); setErrors({});
    try {
      if (isNew) { const created = await adminApi.createProduct(payload()); toast('Product created. You can now add gallery images and a 3D model.'); nav(`/admin/products/${created.id}`, { replace: true }); }
      else { await adminApi.updateProduct(id!, payload()); await reload(); toast('Product saved.'); }
      qc.invalidateQueries({ queryKey: ['admin', 'products'] });
    } catch (err) { setErrors(fieldErrors((err as any).details)); toast((err as Error).message, 'error'); } finally { setBusy(false); }
  }
  async function detachMain() {   // called after the file was removed: persist immediately so the product never points at a deleted file
    set('main_image_url', ''); set('thumb_url', '');
    if (!isNew) { await adminApi.updateProduct(id!, { main_image_url: null, thumb_url: null }); await reload(); }
  }
  if (!isNew && prod.isLoading) return <Skeleton rows={8} />;
  if (!isNew && prod.error) return <ErrorBlock error={prod.error} retry={() => prod.refetch()} />;
  const inp = (k: keyof Form, label: string, extra: Record<string, unknown> = {}, hint?: string) => (
    <Field label={label} error={errors[k as string]} hint={hint} htmlFor={`p-${k}`}><input id={`p-${k}`} className="input" value={f[k] as string} onChange={(e) => set(k, e.target.value as never)} aria-invalid={!!errors[k as string]} {...extra} /></Field>
  );
  return (
    <form onSubmit={save} noValidate>
      <Link to="/admin/products" className="mb-3 inline-flex items-center gap-1 text-sm text-white/55 hover:text-cyan"><ArrowLeft className="h-4 w-4" /> Products</Link>
      <PageHeader title={isNew ? 'Add product' : f.name || 'Edit product'} action={<button className="btn btn-primary" disabled={busy}>{busy ? 'Saving…' : isNew ? 'Create product' : 'Save changes'}</button>} />
      <div className="grid gap-5 lg:grid-cols-[1fr_340px]">
        <div className="space-y-5">
          <Section title="Basics">
            {inp('name', 'Product name')}
            <div className="grid gap-4 sm:grid-cols-2">{inp('sku', 'SKU')}{inp('slug', 'URL slug', { placeholder: 'auto from name' }, 'Used in /product/your-slug')}</div>
            <Field label="Category" error={errors.category_id} htmlFor="p-cat"><select id="p-cat" className="input" value={f.category_id} onChange={(e) => set('category_id', e.target.value)}><option value="">No category</option>{cats.data?.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></Field>
            {inp('short_desc', 'Short description')}
            <Field label="Full description" error={errors.full_desc} htmlFor="p-full"><textarea id="p-full" rows={5} className="input py-3" value={f.full_desc} onChange={(e) => set('full_desc', e.target.value)} /></Field>
          </Section>
          <Section title="Pricing">
            <div className="grid gap-4 sm:grid-cols-3">
              {inp('regular_price', 'Regular price', { inputMode: 'decimal', onChange: (e: { target: { value: string } }) => setF((c) => ({ ...c, regular_price: e.target.value, discount_percent: saleToPercent(e.target.value, c.sale_price) })) })}
              {inp('sale_price', 'Discount (sale) price', { inputMode: 'decimal', placeholder: 'blank = no sale', onChange: (e: { target: { value: string } }) => setF((c) => ({ ...c, sale_price: e.target.value, discount_percent: saleToPercent(c.regular_price, e.target.value) })) })}
              {inp('discount_percent', 'Discount %', { inputMode: 'numeric', placeholder: 'e.g. 28', onChange: (e: { target: { value: string } }) => setF((c) => ({ ...c, discount_percent: e.target.value, sale_price: percentToSale(c.regular_price, e.target.value) })) }, 'Type a price OR a percent: the other updates.')}
            </div>
            <p className={`rounded-xl px-4 py-3 text-sm ${preview.valid ? 'bg-white/[0.04] text-white/75' : 'bg-red-500/10 text-red-300'}`} aria-live="polite">
              {preview.valid ? (preview.percent ? <>Customers see <s className="text-white/45">{formatTaka(Number(f.regular_price))}</s> <b className="text-white">{formatTaka(Number(f.sale_price))}</b> — save {formatTaka(preview.save)} ({preview.percent}% OFF). Calculated automatically.</> : preview.message) : preview.message}
            </p>
            {inp('offer_text', 'Offer label (optional)', {}, 'Shown beside the price, e.g. “Eid special”')}
          </Section>
          <Section title="Inventory">
            <div className="grid gap-4 sm:grid-cols-2">
              {inp('stock', 'Stock quantity', { inputMode: 'numeric' })}
              <Field label="Stock status" htmlFor="p-ss" error={errors.stock_status}><select id="p-ss" className="input" value={f.stock_status} onChange={(e) => set('stock_status', e.target.value)}><option value="auto">Automatic (from quantity)</option><option value="in_stock">In stock</option><option value="low_stock">Low stock</option><option value="out_of_stock">Out of stock</option><option value="preorder">Pre-order</option></select></Field>
            </div>
          </Section>
          <Section title="Details">
            <Field label="Features (one per line)" htmlFor="p-feat"><textarea id="p-feat" rows={4} className="input py-3" value={f.features} onChange={(e) => set('features', e.target.value)} /></Field>
            <div><span className="label">Specifications</span>
              <div className="space-y-2">{f.specs.map((s, i) => (
                <div key={i} className="grid grid-cols-[1fr_1fr_44px] gap-2">
                  <input className="input" aria-label="Specification name" placeholder="e.g. Battery" value={s.k} onChange={(e) => set('specs', f.specs.map((x, j) => (j === i ? { ...x, k: e.target.value } : x)))} />
                  <input className="input" aria-label="Specification value" placeholder="e.g. 30 hours" value={s.v} onChange={(e) => set('specs', f.specs.map((x, j) => (j === i ? { ...x, v: e.target.value } : x)))} />
                  <button type="button" aria-label="Remove specification" className="grid place-items-center rounded-xl border border-white/10 hover:text-red-300" onClick={() => set('specs', f.specs.filter((_, j) => j !== i))}><Trash2 className="h-4 w-4" /></button>
                </div>))}</div>
              <button type="button" className="mt-2 inline-flex items-center gap-1 text-sm text-cyan" onClick={() => set('specs', [...f.specs, { k: '', v: '' }])}><Plus className="h-4 w-4" />Add specification</button>
              {errors.specifications && <p role="alert" className="mt-1 text-sm text-red-400">{errors.specifications}</p>}
            </div>
          </Section>
          <Section title="Images & 3D model">
            <ImageUploader label="Main image" value={f.main_image_url} onUploaded={async (url, thumb) => { set('main_image_url', url); set('thumb_url', thumb ?? ''); if (!isNew) { await adminApi.updateProduct(id!, { main_image_url: url, thumb_url: thumb }); await reload(); } }} onRemove={detachMain} />
            {errors.main_image_url && <p className="text-sm text-red-400">{errors.main_image_url}</p>}
            {isNew ? <p className="rounded-xl bg-white/[0.04] p-4 text-sm text-white/55">Save the product first, then you can add gallery images and a 3D model.</p> : (
              <><GalleryManager productId={id!} images={p?.product_images ?? []} onChange={reload} /><ModelUploader productId={id!} model={Array.isArray(p?.product_models) ? p?.product_models[0] : p?.product_models} onChange={reload} /></>
            )}
          </Section>
        </div>
        <aside className="space-y-5 lg:sticky lg:top-6 lg:self-start">
          <Section title="Visibility">
            <ToggleRow label="Enabled" hint="Disabled products are hidden from the store." checked={f.is_active} onChange={(v) => set('is_active', v)} />
            <ToggleRow label="Featured product" checked={f.is_featured} onChange={(v) => set('is_featured', v)} />
            <ToggleRow label="Order button" hint="Off = customers cannot order this product online (server enforced)." checked={f.order_button_enabled} onChange={(v) => set('order_button_enabled', v)} />
            {inp('order_button_text', 'Order button text', { placeholder: 'ORDER NOW', maxLength: 30 }, 'Optional. Blank = ORDER NOW.')}
            <ToggleRow label="Featured in Hero" hint="Shows in the homepage 3D rotation." checked={f.featured_in_hero} onChange={(v) => set('featured_in_hero', v)} />
            {inp('hero_order', 'Hero display order', { inputMode: 'numeric', placeholder: 'auto' }, 'Or drag to reorder on the Hero page.')}
            {inp('display_order', 'Display order', { inputMode: 'numeric', placeholder: 'auto' }, 'Lower numbers appear first.')}
          </Section>
          {!isNew && <button type="button" className="btn btn-ghost w-full" onClick={() => window.open(`/product/${f.slug}`, '_blank')}>View on storefront ↗</button>}
        </aside>
      </div>
    </form>
  );
}
