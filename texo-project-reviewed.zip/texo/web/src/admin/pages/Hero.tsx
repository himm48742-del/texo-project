import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { ArrowDown, ArrowUp, GripVertical, Plus, X } from 'lucide-react';
import { useEffect, useState } from 'react';
import { ProductImage } from '../../components/ProductImage';
import { useDebounced } from '../../hooks/queries';
import { Empty, ErrorBlock, Field, PageHeader, Skeleton, Toggle, ToggleRow, useConfirm, useToast } from '../components/ui';
import { adminApi } from '../lib/adminApi';
import { moveItem, toNumberOrNull } from '../lib/helpers';

export function AdminHero() {
  const qc = useQueryClient(); const toast = useToast(); const confirm = useConfirm();
  const hero = useQuery({ queryKey: ['admin', 'hero'], queryFn: adminApi.hero });
  const settings = useQuery({ queryKey: ['admin', 'settings'], queryFn: adminApi.settings });
  const [order, setOrder] = useState<any[]>([]);
  const [drag, setDrag] = useState<number | null>(null);
  const [q, setQ] = useState(''); const dq = useDebounced(q, 300);
  const found = useQuery({ queryKey: ['admin', 'hero-search', dq], queryFn: () => adminApi.products({ q: dq, active: 'true', limit: 8 }), enabled: dq.trim().length >= 2 });
  const [cfg, setCfg] = useState({ seconds: '6', speed: '1', autoplay: true });
  useEffect(() => { if (hero.data) setOrder(hero.data); }, [hero.data]);
  useEffect(() => { const s = settings.data; if (s) setCfg({ seconds: String(s.hero_rotation_seconds ?? 6), speed: String(s.hero_animation_speed ?? 1), autoplay: s.hero_autoplay !== false }); }, [settings.data]);
  const refresh = () => { qc.invalidateQueries({ queryKey: ['admin', 'hero'] }); qc.invalidateQueries({ queryKey: ['admin', 'products'] }); };

  async function persist(next: any[]) {  // optimistic: show the new order immediately, roll back if the server refuses
    const prev = order; setOrder(next);
    try { await adminApi.reorder('products', next.map((p) => p.id), 'hero_order'); refresh(); toast('Hero order saved.'); }
    catch (e) { setOrder(prev); toast((e as Error).message, 'error'); }
  }
  const act = useMutation({ mutationFn: (fn: () => Promise<unknown>) => fn(), onSuccess: refresh, onError: (e) => toast((e as Error).message, 'error') });
  async function remove(p: any) {
    if (await confirm({ title: `Remove “${p.name}” from hero?`, message: 'The product stays in your store; it just stops rotating on the homepage.', confirmLabel: 'Remove from hero' })) act.mutate(() => adminApi.setHero(p.id, false));
  }
  async function saveCfg() {
    const seconds = toNumberOrNull(cfg.seconds), speed = toNumberOrNull(cfg.speed);
    try { await adminApi.saveSettings({ hero_rotation_seconds: seconds, hero_animation_speed: speed, hero_autoplay: cfg.autoplay }); qc.invalidateQueries({ queryKey: ['admin', 'settings'] }); toast('Hero settings saved.'); }
    catch (e) { toast((e as Error).message, 'error'); }
  }
  const inHero = new Set(order.map((p) => p.id));
  return (
    <>
      <PageHeader title="Hero showcase" subtitle="The products rotating on the homepage, in this order. Drag to reorder." />
      <div className="grid gap-6 lg:grid-cols-[1fr_360px]">
        <section aria-label="Current hero products">
          {hero.isLoading ? <Skeleton /> : hero.error ? <ErrorBlock error={hero.error} retry={() => hero.refetch()} /> : !order.length ? <Empty title="No products in the hero yet. Add some from the right." /> : (
            <ol className="space-y-2">
              {order.map((p, i) => (
                <li key={p.id} draggable onDragStart={() => setDrag(i)} onDragOver={(e) => e.preventDefault()} onDrop={() => { if (drag !== null && drag !== i) persist(moveItem(order, drag, i)); setDrag(null); }} onDragEnd={() => setDrag(null)}
                  className={`card flex items-center gap-3 p-3 ${drag === i ? 'opacity-40' : ''} ${!p.is_active ? 'opacity-70' : ''}`}>
                  <GripVertical className="hidden h-5 w-5 shrink-0 cursor-grab text-white/30 sm:block" aria-hidden="true" />
                  <span className="w-6 shrink-0 text-center font-display text-sm text-white/40">{i + 1}</span>
                  <ProductImage src={p.thumb_url ?? p.main_image_url} alt="" className="h-14 w-14 shrink-0 rounded-lg border border-white/10 p-1" />
                  <div className="min-w-0 flex-1"><p className="truncate font-medium">{p.name}</p><p className="text-xs text-white/40">{p.is_active ? 'Showing' : 'Disabled — hidden from the hero'}</p></div>
                  <Toggle label={`Enable ${p.name}`} checked={p.is_active} onChange={(v) => act.mutate(() => adminApi.updateProduct(p.id, { is_active: v }))} />
                  <div className="flex shrink-0">
                    <button type="button" aria-label="Move up" disabled={i === 0} onClick={() => persist(moveItem(order, i, i - 1))} className="grid h-10 w-10 place-items-center rounded-lg hover:bg-white/10 disabled:opacity-25"><ArrowUp className="h-4 w-4" /></button>
                    <button type="button" aria-label="Move down" disabled={i === order.length - 1} onClick={() => persist(moveItem(order, i, i + 1))} className="grid h-10 w-10 place-items-center rounded-lg hover:bg-white/10 disabled:opacity-25"><ArrowDown className="h-4 w-4" /></button>
                    <button type="button" aria-label={`Remove ${p.name} from hero`} onClick={() => remove(p)} className="grid h-10 w-10 place-items-center rounded-lg text-red-300 hover:bg-red-500/10"><X className="h-4 w-4" /></button>
                  </div>
                </li>
              ))}
            </ol>
          )}
        </section>
        <div className="space-y-5">
          <section className="card space-y-3 p-5" aria-label="Add products to hero">
            <h2 className="font-display text-lg font-semibold">Add products</h2>
            <input className="input" placeholder="Search by name or SKU" aria-label="Search products to add" value={q} onChange={(e) => setQ(e.target.value)} />
            {found.isFetching && <p className="text-sm text-white/45">Searching…</p>}
            {found.data && !found.data.rows.length && <p className="text-sm text-white/50">No enabled products match.</p>}
            <ul className="space-y-2">{found.data?.rows.map((p) => (
              <li key={p.id} className="flex items-center gap-3"><ProductImage src={p.thumb_url} alt="" className="h-10 w-10 shrink-0 rounded-lg border border-white/10 p-0.5" /><span className="min-w-0 flex-1 truncate text-sm">{p.name}</span>
                {inHero.has(p.id) ? <span className="text-xs text-white/40">In hero</span> : <button className="btn btn-ghost min-h-[40px] px-3" onClick={() => act.mutate(() => adminApi.setHero(p.id, true))}><Plus className="h-4 w-4" />Add</button>}</li>))}</ul>
          </section>
          <section className="card space-y-4 p-5" aria-label="Hero animation settings">
            <h2 className="font-display text-lg font-semibold">Rotation & animation</h2>
            <ToggleRow label="Autoplay" hint="Off = visitors press play." checked={cfg.autoplay} onChange={(v) => setCfg({ ...cfg, autoplay: v })} />
            <Field label="Seconds per product (3–30)" htmlFor="h-sec"><input id="h-sec" className="input" inputMode="decimal" value={cfg.seconds} onChange={(e) => setCfg({ ...cfg, seconds: e.target.value })} /></Field>
            <Field label="Animation speed (0.5 slow – 2 fast)" htmlFor="h-spd"><input id="h-spd" className="input" inputMode="decimal" value={cfg.speed} onChange={(e) => setCfg({ ...cfg, speed: e.target.value })} /></Field>
            <button className="btn btn-primary w-full" onClick={saveCfg}>Save hero settings</button>
          </section>
        </div>
      </div>
    </>
  );
}
