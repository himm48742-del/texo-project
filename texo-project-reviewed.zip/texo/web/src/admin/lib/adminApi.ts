import { ApiError } from '../../lib/api';

// The browser only ever holds the user's own session tokens. The Supabase service-role key exists on the server only.
const BASE = (import.meta.env.VITE_API_URL as string | undefined) || '/api';
const RK = 'texo.admin.refresh';
let access: string | null = null;
let refreshing: Promise<boolean> | null = null;
const listeners = new Set<() => void>();
export const onSessionLost = (fn: () => void) => { listeners.add(fn); return () => { listeners.delete(fn); }; };

function store(r: { accessToken: string; refreshToken?: string }) {
  access = r.accessToken;
  if (r.refreshToken) { try { sessionStorage.setItem(RK, r.refreshToken); } catch { /* private mode */ } }
}
export function clearSession() { access = null; try { sessionStorage.removeItem(RK); } catch { /* ignore */ } }
export const hasStoredSession = () => { try { return !!sessionStorage.getItem(RK); } catch { return false; } };

async function raw(path: string, init: RequestInit & { auth?: boolean } = {}) {
  let res: Response;
  try {
    res = await fetch(BASE + path, { ...init, headers: { 'Content-Type': 'application/json', ...(init.auth && access ? { Authorization: `Bearer ${access}` } : {}), ...(init.headers ?? {}) } });
  } catch { throw new ApiError(0, 'NETWORK', 'Cannot reach the TEXO server. Check your connection and try again.'); }
  let body: any = null;
  try { body = await res.json(); } catch { /* empty body */ }
  if (!res.ok) throw new ApiError(res.status, body?.error?.code ?? 'ERROR', body?.error?.message ?? 'Something went wrong.', body?.error?.details);
  return body as { data: any; meta?: any };
}
export async function refreshSession(): Promise<boolean> {
  refreshing ??= (async () => {
    let t: string | null = null;
    try { t = sessionStorage.getItem(RK); } catch { /* ignore */ }
    if (!t) return false;
    try { store((await raw('/admin/refresh', { method: 'POST', body: JSON.stringify({ refreshToken: t }) })).data); return true; }
    catch { clearSession(); return false; }
  })().finally(() => { refreshing = null; });
  return refreshing;
}
async function authed(path: string, init: RequestInit = {}, retried = false): Promise<{ data: any; meta?: any }> {
  if (!access && !retried && !(await refreshSession())) { listeners.forEach((f) => f()); throw new ApiError(401, 'UNAUTHENTICATED', 'Please log in.'); }
  try { return await raw(path, { ...init, auth: true }); }
  catch (e) {
    if (e instanceof ApiError && e.status === 401 && !retried) {
      access = null;
      if (await refreshSession()) return authed(path, init, true);
      listeners.forEach((f) => f());
    }
    throw e;
  }
}
const send = (method: string, body?: unknown): RequestInit => ({ method, ...(body === undefined ? {} : { body: JSON.stringify(body) }) });
const qs = (o: Record<string, unknown>) => { const p = new URLSearchParams(); for (const [k, v] of Object.entries(o)) if (v !== undefined && v !== '' && v !== null) p.set(k, String(v)); const s = p.toString(); return s ? `?${s}` : ''; };

export const login = async (email: string, password: string) => {
  const r = (await raw('/admin/login', { method: 'POST', body: JSON.stringify({ email, password }) })).data;
  store(r); return r.user as { id: string; email?: string };
};
export const me = async () => (await authed('/admin/me')).data as { id: string; email?: string };

export interface UploadHandle { promise: Promise<any>; abort: () => void }
/** XMLHttpRequest (not fetch) because browsers only report UPLOAD progress through XHR. */
export function upload(kind: 'image' | 'model', file: File, onProgress: (pct: number) => void, folder = 'products'): UploadHandle {
  const xhr = new XMLHttpRequest();
  const run = async (retried: boolean): Promise<any> => {
    if (!access && !(await refreshSession())) throw new ApiError(401, 'UNAUTHENTICATED', 'Please log in again.');
    return new Promise((resolve, reject) => {
      xhr.open('POST', `${BASE}/admin/uploads/${kind}${kind === 'image' ? qs({ folder }) : ''}`);
      xhr.setRequestHeader('Authorization', `Bearer ${access}`);
      xhr.upload.onprogress = (e) => e.lengthComputable && onProgress(Math.round((e.loaded / e.total) * 100));
      xhr.onerror = () => reject(new ApiError(0, 'NETWORK', 'Upload failed: connection lost.'));
      xhr.onabort = () => reject(new ApiError(0, 'ABORTED', 'Upload cancelled.'));
      xhr.onload = async () => {
        let body: any = null; try { body = JSON.parse(xhr.responseText); } catch { /* not json */ }
        if (xhr.status === 401 && !retried) { access = null; try { resolve(await run(true)); } catch (e) { reject(e); } return; }
        if (xhr.status >= 200 && xhr.status < 300) resolve(body.data);
        else reject(new ApiError(xhr.status, body?.error?.code ?? 'ERROR', body?.error?.message ?? 'The upload failed.'));
      };
      const fd = new FormData(); fd.append('file', file); xhr.send(fd);
    });
  };
  return { promise: run(false), abort: () => xhr.abort() };
}

type Row = Record<string, any>;
export const adminApi = {
  stats: async () => (await authed('/admin/stats')).data as Row,
  settings: async () => (await authed('/admin/settings')).data as Row,
  saveSettings: async (b: Row) => (await authed('/admin/settings', send('PUT', b))).data,
  products: async (p: Row) => { const r = await authed(`/admin/products${qs(p)}`); return { rows: r.data as Row[], total: (r.meta?.total ?? 0) as number }; },
  product: async (id: string) => (await authed(`/admin/products/${id}`)).data as Row,
  createProduct: async (b: Row) => (await authed('/admin/products', send('POST', b))).data as Row,
  updateProduct: async (id: string, b: Row) => (await authed(`/admin/products/${id}`, send('PATCH', b))).data as Row,
  deleteProduct: async (id: string) => authed(`/admin/products/${id}`, send('DELETE')),
  duplicateProduct: async (id: string) => (await authed(`/admin/products/${id}/duplicate`, send('POST'))).data as Row,
  reorder: async (table: 'products' | 'categories', ids: string[], field?: string) => authed(`/admin/${table}/reorder`, send('POST', { ids, ...(field ? { field } : {}) })),
  hero: async () => (await authed('/admin/hero')).data as Row[],
  setHero: async (id: string, featured: boolean) => authed(`/admin/products/${id}/hero`, send('POST', { featured })),
  addImage: async (id: string, b: Row) => (await authed(`/admin/products/${id}/images`, send('POST', b))).data as Row,
  removeImage: async (imageId: string) => authed(`/admin/product-images/${imageId}`, send('DELETE')),
  reorderImages: async (id: string, ids: string[]) => authed(`/admin/products/${id}/images/order`, send('PUT', { ids })),
  setModel: async (id: string, b: Row) => (await authed(`/admin/products/${id}/model`, send('PUT', b))).data as Row,
  removeModel: async (id: string) => authed(`/admin/products/${id}/model`, send('DELETE')),
  deleteFile: async (url: string) => authed('/admin/uploads', send('DELETE', { url })),
  list: async (res: 'categories' | 'offers' | 'news') => (await authed(`/admin/${res}`)).data as Row[],
  create: async (res: string, b: Row) => (await authed(`/admin/${res}`, send('POST', b))).data as Row,
  update: async (res: string, id: string, b: Row) => (await authed(`/admin/${res}/${id}`, send('PATCH', b))).data as Row,
  remove: async (res: string, id: string) => authed(`/admin/${res}/${id}`, send('DELETE')),
  previewOffer: async (b: Row) => (await authed('/admin/offers/preview', send('POST', b))).data as Row,
  orders: async (p: Row) => { const r = await authed(`/admin/orders${qs(p)}`); return { rows: r.data as Row[], total: (r.meta?.total ?? 0) as number }; },
  setOrderStatus: async (id: string, status: string) => (await authed(`/admin/orders/${id}/status`, send('PATCH', { status }))).data as Row,
};
