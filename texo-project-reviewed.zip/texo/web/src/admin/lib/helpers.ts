// Pure helpers for the admin UI (unit-tested). No React, no network.
export const MAX_IMAGE_BYTES = 5 * 1024 * 1024;
export const MAX_MODEL_BYTES = 15 * 1024 * 1024;
export interface FileLike { name: string; type?: string; size: number }
const IMG_EXT = ['jpg', 'jpeg', 'png', 'webp', 'avif'];
const ext = (n: string) => n.toLowerCase().split('.').pop() ?? '';
export const formatBytes = (b: number) => (b >= 1048576 ? `${(b / 1048576).toFixed(1)} MB` : `${Math.max(1, Math.round(b / 1024))} KB`);

/** Instant feedback in the browser. The server re-checks the real file content, so this is convenience, not security. */
export function validateImageFile(f: FileLike): string | null {
  if (!IMG_EXT.includes(ext(f.name))) return 'Use a JPG, PNG, WEBP or AVIF image.';
  if (f.type && !/^image\/(jpeg|png|webp|avif)$/.test(f.type)) return 'This file is not a supported image type.';
  if (f.size === 0) return 'The file is empty.';
  if (f.size > MAX_IMAGE_BYTES) return `This image is ${formatBytes(f.size)}. The maximum is 5 MB.`;
  return null;
}
export function validateModelFile(f: FileLike): string | null {
  if (!['glb', 'gltf'].includes(ext(f.name))) return 'Use a .glb or .gltf 3D model.';
  if (f.size === 0) return 'The file is empty.';
  if (f.size > MAX_MODEL_BYTES) return `This model is ${formatBytes(f.size)}. The maximum is 15 MB.`;
  return null;
}
/** Same maths as the server trigger, for the live preview while typing. */
export function discountPreview(regular: string | number, sale: string | number | null | undefined) {
  const r = Number(regular), hasSale = sale !== '' && sale != null, s = Number(sale);
  if (!(r > 0)) return { valid: false, save: 0, percent: 0, message: 'Enter the regular price.' };
  if (!hasSale) return { valid: true, save: 0, percent: 0, message: 'No sale price: customers pay the regular price.' };
  if (!(s > 0) || s >= r) return { valid: false, save: 0, percent: 0, message: 'Sale price must be above 0 and lower than the regular price.' };
  const save = Math.round((r - s) * 100) / 100;
  return { valid: true, save, percent: Math.round((save / r) * 100), message: '' };
}
export function moveItem<T>(list: T[], from: number, to: number): T[] {
  if (from === to || from < 0 || to < 0 || from >= list.length || to >= list.length) return list;
  const out = [...list]; const [x] = out.splice(from, 1); out.splice(to, 0, x); return out;
}
/** ISO <-> <input type="datetime-local"> (local time, no seconds). */
export function toLocalInput(iso?: string | null): string {
  if (!iso) return '';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '';
  const p = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`;
}
export function fromLocalInput(v: string): string | null {
  if (!v) return null;
  const d = new Date(v);
  return Number.isNaN(d.getTime()) ? null : d.toISOString();
}
export const fileNameFromUrl = (u?: string | null) => (u ? decodeURIComponent(u.split('?')[0].split('/').pop() ?? '') : '');
/** Total discount on an order = sum of (regular - paid) x quantity over its saved line items. */
export function orderDiscount(items: { unit_regular: number | string; unit_price: number | string; quantity: number }[] = []): number {
  return Math.round(items.reduce((s, i) => s + (Number(i.unit_regular) - Number(i.unit_price)) * i.quantity * 100, 0)) / 100;
}
export function fieldErrors(details?: { field: string; message: string }[]): Record<string, string> {
  const out: Record<string, string> = {};
  for (const d of details ?? []) if (d.field && !out[d.field]) out[d.field] = d.message;
  return out;
}
export const toNumberOrNull = (v: string): number | null => (v.trim() === '' || Number.isNaN(Number(v)) ? null : Number(v));
export const STATUSES = ['pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled'] as const;
export const statusTone = (s: string) =>
  ({ pending: 'bg-gold/15 text-gold', confirmed: 'bg-electric/20 text-sky-300', processing: 'bg-cyan/15 text-cyan', shipped: 'bg-violet-500/20 text-violet-300', delivered: 'bg-emerald-500/20 text-emerald-300', cancelled: 'bg-red-500/20 text-red-300' } as Record<string, string>)[s] ?? 'bg-white/10 text-white/70';

/** "28" % off 2490 -> "1792.80" (empty when the inputs are not usable). Mirrors the server's salePriceFromPercent. */
export function percentToSale(regular: string | number, pct: string | number): string {
  const r = Number(regular), p = Number(pct);
  if (!(r > 0) || pct === '' || !Number.isFinite(p) || p < 0 || p > 99) return '';
  if (p === 0) return '';
  return String(Math.round((r * 100 * (100 - p)) / 100) / 100);
}
/** Sale price -> whole-number % off (empty if there is no valid sale). */
export function saleToPercent(regular: string | number, sale: string | number): string {
  const d = discountPreview(regular, sale);
  return d.valid && d.percent > 0 ? String(d.percent) : '';
}
