import { Route, Routes } from 'react-router-dom';
import { AuthProvider, RequireAdmin } from './auth';
import { AdminLayout } from './components/AdminLayout';
import { AdminCategories } from './pages/Categories';
import { Dashboard } from './pages/Dashboard';
import { AdminHero } from './pages/Hero';
import { AdminLogin } from './pages/Login';
import { AdminNews } from './pages/News';
import { AdminOffers } from './pages/Offers';
import { AdminOrders } from './pages/Orders';
import { ProductEditor } from './pages/ProductEditor';
import { AdminProducts } from './pages/Products';
import { AdminSettings } from './pages/Settings';

export function AdminRoutes() {
  return (
    <AuthProvider>
      <Routes>
        <Route path="login" element={<AdminLogin />} />
        <Route element={<RequireAdmin><AdminLayout /></RequireAdmin>}>
          <Route index element={<Dashboard />} />
          <Route path="products" element={<AdminProducts />} />
          <Route path="products/:id" element={<ProductEditor />} />
          <Route path="hero" element={<AdminHero />} />
          <Route path="categories" element={<AdminCategories />} />
          <Route path="orders" element={<AdminOrders />} />
          <Route path="offers" element={<AdminOffers />} />
          <Route path="news" element={<AdminNews />} />
          <Route path="settings" element={<AdminSettings />} />
        </Route>
      </Routes>
    </AuthProvider>
  );
}
