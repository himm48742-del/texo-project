import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import type { ReactNode } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import * as api from './lib/adminApi';

interface Auth { status: 'checking' | 'in' | 'out'; user: { id: string; email?: string } | null; signIn: (e: string, p: string) => Promise<void>; signOut: () => void }
const Ctx = createContext<Auth | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [status, setStatus] = useState<Auth['status']>('checking');
  const [user, setUser] = useState<Auth['user']>(null);
  useEffect(() => {
    let live = true;
    (async () => {
      if (!api.hasStoredSession()) { setStatus('out'); return; }
      try { const u = await api.me(); if (live) { setUser(u); setStatus('in'); } } catch { if (live) setStatus('out'); }
    })();
    const off = api.onSessionLost(() => { setUser(null); setStatus('out'); });
    return () => { live = false; off(); };
  }, []);
  const signIn = useCallback(async (e: string, p: string) => { setUser(await api.login(e, p)); setStatus('in'); }, []);
  const signOut = useCallback(() => { api.clearSession(); setUser(null); setStatus('out'); }, []);
  const v = useMemo(() => ({ status, user, signIn, signOut }), [status, user, signIn, signOut]);
  return <Ctx.Provider value={v}>{children}</Ctx.Provider>;
}
export function useAuth() { const c = useContext(Ctx); if (!c) throw new Error('useAuth outside AuthProvider'); return c; }

/** UI convenience only. Real protection is on the server: every /api/admin route re-checks the token. */
export function RequireAdmin({ children }: { children: ReactNode }) {
  const { status } = useAuth();
  const loc = useLocation();
  if (status === 'checking') return <div className="grid min-h-screen place-items-center text-white/50" role="status">Checking your session…</div>;
  if (status === 'out') return <Navigate to="/admin/login" replace state={{ from: loc.pathname }} />;
  return <>{children}</>;
}
