import { Boxes, ClipboardList, Flame, Image as ImageIcon, LayoutDashboard, LogOut, Menu, Newspaper, Settings, Sparkles, Tags } from 'lucide-react';
import { useEffect, useState } from 'react';
import { Link, NavLink, Outlet } from 'react-router-dom';
import { Drawer } from '../../components/Drawer';
import { useAuth } from '../auth';
import { ConfirmProvider, ToastProvider } from './ui';

const NAV = [
  ['Dashboard', '/admin', LayoutDashboard, true], ['Products', '/admin/products', Boxes, false], ['Hero showcase', '/admin/hero', Sparkles, false],
  ['Categories', '/admin/categories', Tags, false], ['Orders', '/admin/orders', ClipboardList, false], ['Offers', '/admin/offers', Flame, false],
  ['Tech News', '/admin/news', Newspaper, false], ['Settings', '/admin/settings', Settings, false],
] as const;

function NavList({ onNavigate }: { onNavigate?: () => void }) {
  return (
    <nav aria-label="Admin" className="space-y-1">
      {NAV.map(([label, to, Icon, end]) => (
        <NavLink key={to} to={to} end={end} onClick={onNavigate}
          className={({ isActive }) => `flex min-h-[46px] items-center gap-3 rounded-xl px-3 text-sm font-medium transition ${isActive ? 'bg-cyan/10 text-cyan' : 'text-white/65 hover:bg-white/5 hover:text-white'}`}>
          <Icon className="h-[18px] w-[18px]" aria-hidden="true" />{label}
        </NavLink>
      ))}
      <a href="/" target="_blank" rel="noopener noreferrer" className="flex min-h-[46px] items-center gap-3 rounded-xl px-3 text-sm text-white/45 hover:text-white"><ImageIcon className="h-[18px] w-[18px]" />View storefront ↗</a>
    </nav>
  );
}

export function AdminLayout() {
  const { user, signOut } = useAuth();
  const [open, setOpen] = useState(false);
  useEffect(() => { // the admin area must never be indexed by search engines
    const m = document.createElement('meta'); m.name = 'robots'; m.content = 'noindex,nofollow'; document.head.appendChild(m);
    document.title = 'TEXO Admin';
    return () => { m.remove(); };
  }, []);
  const account = (
    <div className="border-t border-white/10 pt-4">
      <p className="truncate px-3 text-xs text-white/40">{user?.email}</p>
      <button onClick={signOut} className="mt-1 flex min-h-[44px] w-full items-center gap-3 rounded-xl px-3 text-sm text-white/65 hover:bg-white/5 hover:text-white"><LogOut className="h-[18px] w-[18px]" />Log out</button>
    </div>
  );
  return (
    <ToastProvider>
      <ConfirmProvider>
        <div className="min-h-screen lg:grid lg:grid-cols-[250px_1fr]">
          <aside className="sticky top-0 hidden h-screen flex-col justify-between border-r border-white/10 bg-panel/60 p-4 lg:flex">
            <div><Link to="/admin" className="mb-6 flex items-baseline gap-2 px-3 pt-2"><span className="font-display text-xl font-bold tracking-[0.18em]">TEXO</span><span className="text-xs text-cyan">ADMIN</span></Link><NavList /></div>
            {account}
          </aside>
          <div className="min-w-0">
            <header className="sticky top-0 z-30 flex h-14 items-center justify-between border-b border-white/10 bg-ink/85 px-4 backdrop-blur lg:hidden">
              <button className="grid h-11 w-11 place-items-center rounded-full hover:bg-white/10" aria-label="Open admin menu" onClick={() => setOpen(true)}><Menu className="h-5 w-5" /></button>
              <span className="font-display font-bold tracking-[0.18em]">TEXO <span className="text-xs text-cyan">ADMIN</span></span><span className="w-11" />
            </header>
            <Drawer open={open} onClose={() => setOpen(false)} title="Admin menu"><div className="flex h-full flex-col justify-between gap-6"><NavList onNavigate={() => setOpen(false)} />{account}</div></Drawer>
            <main className="mx-auto w-full max-w-[1200px] p-4 sm:p-6 lg:p-8"><Outlet /></main>
          </div>
        </div>
      </ConfirmProvider>
    </ToastProvider>
  );
}
