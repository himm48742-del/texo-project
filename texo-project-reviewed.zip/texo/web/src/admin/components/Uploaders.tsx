import { Box, ImagePlus, Loader2, RefreshCw, Trash2, X } from 'lucide-react';
import { useRef, useState } from 'react';
import { ProductImage } from '../../components/ProductImage';
import * as api from '../lib/adminApi';
import { adminApi } from '../lib/adminApi';
import { fileNameFromUrl, formatBytes, validateImageFile, validateModelFile } from '../lib/helpers';
import { useConfirm, useToast } from './ui';

/** Shared upload state machine: validate -> upload with progress -> done / error. */
function useUpload(kind: 'image' | 'model', folder?: string) {
  const [progress, setProgress] = useState<number | null>(null);
  const [error, setError] = useState('');
  const handle = useRef<api.UploadHandle | null>(null);
  async function start(file: File): Promise<any | null> {
    setError('');
    const problem = kind === 'image' ? validateImageFile(file) : validateModelFile(file);
    if (problem) { setError(problem); return null; }
    setProgress(0);
    try { handle.current = api.upload(kind, file, setProgress, folder); return await handle.current.promise; }
    catch (e) { if ((e as any)?.code !== 'ABORTED') setError((e as Error).message); return null; }
    finally { setProgress(null); handle.current = null; }
  }
  return { progress, error, start, cancel: () => handle.current?.abort(), busy: progress !== null, setError };
}
const Progress = ({ pct, onCancel }: { pct: number; onCancel: () => void }) => (
  <div className="w-full" role="progressbar" aria-valuenow={pct} aria-valuemin={0} aria-valuemax={100} aria-label="Upload progress">
    <div className="mb-1 flex items-center justify-between text-xs text-white/60"><span className="flex items-center gap-1"><Loader2 className="h-3 w-3 animate-spin" /> {pct < 100 ? `Uploading ${pct}%` : 'Processing…'}</span><button type="button" onClick={onCancel} className="inline-flex items-center gap-1 hover:text-white"><X className="h-3 w-3" />Cancel</button></div>
    <div className="h-1.5 overflow-hidden rounded bg-white/10"><div className="h-full bg-gradient-to-r from-cyan to-electric transition-all" style={{ width: `${pct}%` }} /></div>
  </div>
);

/** Single image: preview, upload with progress, replace, remove (also deletes the stored file). */
export function ImageUploader({ label, value, folder = 'products', onUploaded, onRemove }: {
  label: string; value?: string | null; folder?: string; onUploaded: (url: string, thumb: string | null) => void | Promise<void>; onRemove: (url: string) => void | Promise<void>;
}) {
  const up = useUpload('image', folder);
  const input = useRef<HTMLInputElement>(null);
  const toast = useToast(); const confirm = useConfirm();
  async function pick(f?: File) {
    if (!f) return;
    const old = value;
    const r = await up.start(f);
    if (!r) return;
    await onUploaded(r.url, r.thumb_url ?? null);
    if (old) api.adminApi.deleteFile(old).catch(() => {}); // replaced file no longer needed
    toast('Image uploaded.');
  }
  async function remove() {
    if (!value || !(await confirm({ title: 'Remove image?', message: 'The image is removed and its file is deleted from storage.', confirmLabel: 'Remove', danger: true }))) return;
    try { await onRemove(value); await api.adminApi.deleteFile(value).catch(() => {}); toast('Image removed.'); } catch (e) { toast((e as Error).message, 'error'); }
  }
  return (
    <div>
      <span className="label">{label}</span>
      <div className="flex flex-wrap items-center gap-4 rounded-xl border border-dashed border-white/20 p-3">
        <ProductImage src={value} alt={label} className="h-24 w-24 shrink-0 rounded-xl border border-white/10 bg-white/[0.03] p-1" />
        <div className="min-w-0 flex-1 space-y-2">
          {up.progress !== null ? <Progress pct={up.progress} onCancel={up.cancel} /> : (
            <div className="flex flex-wrap gap-2">
              <button type="button" className="btn btn-ghost min-h-[40px] px-4" onClick={() => input.current?.click()}>{value ? <><RefreshCw className="h-4 w-4" /> Replace</> : <><ImagePlus className="h-4 w-4" /> Upload image</>}</button>
              {value && <button type="button" className="btn btn-ghost min-h-[40px] px-4 hover:border-red-500/50 hover:text-red-300" onClick={remove}><Trash2 className="h-4 w-4" /> Remove</button>}
            </div>
          )}
          <p className="text-xs text-white/40">JPG, PNG, WEBP or AVIF · max 5 MB · best: 1600×1600 px, transparent background for the hero.</p>
          {up.error && <p role="alert" className="text-sm text-red-400">{up.error}</p>}
        </div>
        <input ref={input} type="file" hidden accept=".jpg,.jpeg,.png,.webp,.avif,image/jpeg,image/png,image/webp,image/avif" onChange={(e) => { pick(e.target.files?.[0]); e.target.value = ''; }} />
      </div>
    </div>
  );
}

/** Multiple gallery images for a saved product: add (with progress), reorder, delete. */
export function GalleryManager({ productId, images, onChange }: { productId: string; images: any[]; onChange: () => void }) {
  const up = useUpload('image', 'products');
  const input = useRef<HTMLInputElement>(null);
  const toast = useToast(); const confirm = useConfirm();
  const sorted = [...images].sort((a, b) => a.sort_order - b.sort_order);
  async function add(files: FileList | null) {
    for (const f of Array.from(files ?? [])) {
      const r = await up.start(f);
      if (!r) continue;
      try { await api.adminApi.addImage(productId, { url: r.url, thumb_url: r.thumb_url, alt_text: null }); onChange(); toast('Gallery image added.'); }
      catch (e) { toast((e as Error).message, 'error'); }
    }
  }
  async function move(i: number, d: number) {
    const ids = sorted.map((x) => x.id); const j = i + d;
    if (j < 0 || j >= ids.length) return;
    [ids[i], ids[j]] = [ids[j], ids[i]];
    try { await api.adminApi.reorderImages(productId, ids); onChange(); } catch (e) { toast((e as Error).message, 'error'); }
  }
  async function del(img: any) {
    if (!(await confirm({ title: 'Delete gallery image?', message: 'This removes the image from the product and from storage.', confirmLabel: 'Delete', danger: true }))) return;
    try { await api.adminApi.removeImage(img.id); await api.adminApi.deleteFile(img.url).catch(() => {}); onChange(); toast('Image deleted.'); } catch (e) { toast((e as Error).message, 'error'); }
  }
  return (
    <div>
      <span className="label">Gallery images</span>
      {sorted.length === 0 && up.progress === null && <p className="mb-3 text-sm text-white/45">No gallery images yet.</p>}
      <ul className="mb-3 grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4">
        {sorted.map((im, i) => (
          <li key={im.id} className="card overflow-hidden">
            <ProductImage src={im.thumb_url ?? im.url} alt={im.alt_text ?? `Gallery image ${i + 1}`} className="aspect-square w-full p-2" />
            <div className="flex justify-between border-t border-white/10 p-1">
              <button type="button" aria-label="Move earlier" disabled={i === 0} onClick={() => move(i, -1)} className="h-9 w-9 rounded hover:bg-white/10 disabled:opacity-30">◀</button>
              <button type="button" aria-label="Delete image" onClick={() => del(im)} className="grid h-9 w-9 place-items-center rounded text-red-300 hover:bg-red-500/10"><Trash2 className="h-4 w-4" /></button>
              <button type="button" aria-label="Move later" disabled={i === sorted.length - 1} onClick={() => move(i, 1)} className="h-9 w-9 rounded hover:bg-white/10 disabled:opacity-30">▶</button>
            </div>
          </li>
        ))}
      </ul>
      {up.progress !== null ? <Progress pct={up.progress} onCancel={up.cancel} /> : <button type="button" className="btn btn-ghost min-h-[44px]" onClick={() => input.current?.click()}><ImagePlus className="h-4 w-4" /> Add images</button>}
      {up.error && <p role="alert" className="mt-2 text-sm text-red-400">{up.error}</p>}
      <input ref={input} type="file" multiple hidden accept=".jpg,.jpeg,.png,.webp,.avif" onChange={(e) => { add(e.target.files); e.target.value = ''; }} />
    </div>
  );
}

/** Optional 3D model (.glb/.gltf) for a saved product: upload with progress, file name, status, replace, remove. */
export function ModelUploader({ productId, model, onChange }: { productId: string; model?: { model_url: string; format: string } | null; onChange: () => void }) {
  const up = useUpload('model');
  const input = useRef<HTMLInputElement>(null);
  const toast = useToast(); const confirm = useConfirm();
  const [lastSize, setLastSize] = useState<number | null>(null);
  async function pick(f?: File) {
    if (!f) return;
    const old = model?.model_url;
    const r = await up.start(f);
    if (!r) return;
    try {
      await api.adminApi.setModel(productId, { model_url: r.model_url, format: r.format });
      setLastSize(f.size);
      if (old) api.adminApi.deleteFile(old).catch(() => {});
      onChange(); toast('3D model uploaded and attached.');
    } catch (e) { up.setError((e as Error).message); }
  }
  async function remove() {
    if (!model || !(await confirm({ title: 'Remove 3D model?', message: 'The product goes back to the image-based 3D-style presentation.', confirmLabel: 'Remove', danger: true }))) return;
    try { await api.adminApi.removeModel(productId); await api.adminApi.deleteFile(model.model_url).catch(() => {}); onChange(); toast('3D model removed.'); } catch (e) { toast((e as Error).message, 'error'); }
  }
  return (
    <div>
      <span className="label">3D model (optional)</span>
      <div className="space-y-3 rounded-xl border border-dashed border-white/20 p-4">
        <div className="flex items-center gap-3">
          <span className="grid h-12 w-12 place-items-center rounded-xl bg-white/5"><Box className="h-6 w-6 text-cyan" /></span>
          <div className="min-w-0 flex-1">
            {model ? (<><p className="truncate text-sm font-medium">{fileNameFromUrl(model.model_url)}</p>
              <p className="text-xs text-emerald-400">● Active · {model.format.toUpperCase()}{lastSize ? ` · ${formatBytes(lastSize)}` : ''} · shown in the hero 3D viewer</p></>)
              : <p className="text-sm text-white/55">No 3D model. The product uses the image-based 3D-style presentation.</p>}
          </div>
        </div>
        {up.progress !== null ? <Progress pct={up.progress} onCancel={up.cancel} /> : (
          <div className="flex flex-wrap gap-2">
            <button type="button" className="btn btn-ghost min-h-[40px] px-4" onClick={() => input.current?.click()}>{model ? <><RefreshCw className="h-4 w-4" /> Replace</> : 'Upload .glb / .gltf'}</button>
            {model && <button type="button" className="btn btn-ghost min-h-[40px] px-4 hover:border-red-500/50 hover:text-red-300" onClick={remove}><Trash2 className="h-4 w-4" /> Remove</button>}
          </div>
        )}
        <p className="text-xs text-white/40">.glb or .gltf · max 15 MB · the file content is verified on the server.</p>
        {up.error && <p role="alert" className="text-sm text-red-400">{up.error}</p>}
        <input ref={input} type="file" hidden accept=".glb,.gltf,model/gltf-binary,model/gltf+json" onChange={(e) => { pick(e.target.files?.[0]); e.target.value = ''; }} />
      </div>
    </div>
  );
}
