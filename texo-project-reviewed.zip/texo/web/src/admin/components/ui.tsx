import { AnimatePresence, motion } from 'framer-motion';
import { AlertTriangle, CheckCircle2, Info, X } from 'lucide-react';
import { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import type { ReactNode } from 'react';
import { statusTone } from '../lib/helpers';

// ---------- toasts
type Tone = 'success' | 'error' | 'info';
const ToastCtx = createContext<(m: string, t?: Tone) => void>(() => {});
export const useToast = () => useContext(ToastCtx);
export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<{ id: number; m: string; t: Tone }[]>([]);
  const push = useCallback((m: string, t: Tone = 'success') => {
    const id = Date.now() + Math.random();
    setItems((c) => [...c.slice(-3), { id, m, t }]);
    setTimeout(() => setItems((c) => c.filter((x) => x.id !== id)), t === 'error' ? 7000 : 3500);
  }, []);
  return (
    <ToastCtx.Provider value={push}>
      {children}
      <div className="pointer-events-none fixed inset-x-0 bottom-4 z-[90] flex flex-col items-center gap-2 px-4" role="status" aria-live="polite">
        <AnimatePresence>
          {items.map((i) => (
            <motion.div key={i.id} layout initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, scale: 0.95 }}
              className={`pointer-events-auto flex max-w-md items-start gap-2 rounded-xl border px-4 py-3 text-sm shadow-2xl backdrop-blur ${i.t === 'error' ? 'border-red-500/40 bg-red-950/90 text-red-100' : i.t === 'info' ? 'border-white/20 bg-panel/95' : 'border-cyan/40 bg-panel/95'}`}>
              {i.t === 'error' ? <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-red-400" /> : i.t === 'info' ? <Info className="mt-0.5 h-4 w-4 shrink-0" /> : <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-cyan" />}
              {i.m}
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </ToastCtx.Provider>
  );
}

// ---------- modal + confirm dialog
export function Modal({ open, onClose, title, children, wide }: { open: boolean; onClose: () => void; title: string; children: ReactNode; wide?: boolean }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const k = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    document.addEventListener('keydown', k);
    const prev = document.body.style.overflow; document.body.style.overflow = 'hidden';
    ref.current?.focus();
    return () => { document.removeEventListener('keydown', k); document.body.style.overflow = prev; };
  }, [open, onClose]);
  return (
    <AnimatePresence>
      {open && (
        <div className="fixed inset-0 z-[80] flex items-end justify-center sm:items-center sm:p-4">
          <motion.div className="absolute inset-0 bg-black/70 backdrop-blur-sm" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose} />
          <motion.div ref={ref} tabIndex={-1} role="dialog" aria-modal="true" aria-label={title} initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 20 }}
            className={`relative flex max-h-[92vh] w-full flex-col overflow-hidden rounded-t-3xl border border-white/10 bg-panel outline-none sm:rounded-2xl ${wide ? 'sm:max-w-3xl' : 'sm:max-w-lg'}`}>
            <div className="flex items-center justify-between border-b border-white/10 px-5 py-4">
              <h2 className="font-display text-lg font-semibold">{title}</h2>
              <button onClick={onClose} aria-label="Close" className="grid h-10 w-10 place-items-center rounded-full hover:bg-white/10"><X className="h-5 w-5" /></button>
            </div>
            <div className="overflow-y-auto p-5">{children}</div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
interface ConfirmOpts { title: string; message: string; confirmLabel?: string; danger?: boolean }
const ConfirmCtx = createContext<(o: ConfirmOpts) => Promise<boolean>>(async () => false);
export const useConfirm = () => useContext(ConfirmCtx);
export function ConfirmProvider({ children }: { children: ReactNode }) {
  const [st, setSt] = useState<(ConfirmOpts & { done: (v: boolean) => void }) | null>(null);
  const ask = useCallback((o: ConfirmOpts) => new Promise<boolean>((done) => setSt({ ...o, done })), []);
  const close = (v: boolean) => { st?.done(v); setSt(null); };
  return (
    <ConfirmCtx.Provider value={ask}>
      {children}
      <Modal open={!!st} onClose={() => close(false)} title={st?.title ?? ''}>
        <p className="text-white/75">{st?.message}</p>
        <div className="mt-6 flex justify-end gap-3">
          <button className="btn btn-ghost" onClick={() => close(false)}>Cancel</button>
          <button className={`btn ${st?.danger ? 'bg-red-500 text-white hover:bg-red-400' : 'btn-primary'}`} onClick={() => close(true)}>{st?.confirmLabel ?? 'Confirm'}</button>
        </div>
      </Modal>
    </ConfirmCtx.Provider>
  );
}

// ---------- small building blocks
export function Field({ label, error, hint, children, htmlFor }: { label: string; error?: string; hint?: string; children: ReactNode; htmlFor?: string }) {
  return (
    <div>
      <label className="label" htmlFor={htmlFor}>{label}</label>
      {children}
      {hint && !error && <p className="mt-1.5 text-xs text-white/40">{hint}</p>}
      {error && <p role="alert" className="mt-1.5 text-sm text-red-400">{error}</p>}
    </div>
  );
}
export function Toggle({ checked, onChange, label, disabled }: { checked: boolean; onChange: (v: boolean) => void; label: string; disabled?: boolean }) {
  return (
    <button type="button" role="switch" aria-checked={checked} aria-label={label} disabled={disabled} onClick={() => onChange(!checked)}
      className={`relative h-7 w-12 shrink-0 rounded-full transition disabled:opacity-40 ${checked ? 'bg-cyan' : 'bg-white/20'}`}>
      <span className={`absolute top-0.5 h-6 w-6 rounded-full bg-white shadow transition-all ${checked ? 'left-[22px] bg-ink' : 'left-0.5'}`} />
    </button>
  );
}
export const ToggleRow = ({ label, hint, ...p }: { label: string; hint?: string; checked: boolean; onChange: (v: boolean) => void }) => (
  <div className="flex items-center justify-between gap-4 rounded-xl border border-white/10 px-4 py-3">
    <div><p className="text-sm font-medium">{label}</p>{hint && <p className="text-xs text-white/45">{hint}</p>}</div>
    <Toggle {...p} label={label} />
  </div>
);
export const Badge = ({ status }: { status: string }) => <span className={`inline-block rounded-full px-2.5 py-0.5 text-xs font-semibold capitalize ${statusTone(status)}`}>{status.replace('_', ' ')}</span>;
export const Skeleton = ({ rows = 5 }: { rows?: number }) => (
  <div className="space-y-3" aria-busy="true" aria-label="Loading">{Array.from({ length: rows }).map((_, i) => <div key={i} className="h-14 animate-pulse rounded-xl bg-white/5" />)}</div>
);
export const ErrorBlock = ({ error, retry }: { error: unknown; retry?: () => void }) => (
  <div role="alert" className="card flex flex-col items-center gap-3 p-8 text-center">
    <AlertTriangle className="h-8 w-8 text-gold" />
    <p className="text-white/80">{(error as Error)?.message ?? 'Something went wrong.'}</p>
    {retry && <button className="btn btn-ghost" onClick={retry}>Try again</button>}
  </div>
);
export const Empty = ({ title, action }: { title: string; action?: ReactNode }) => (
  <div className="card flex flex-col items-center gap-3 px-6 py-14 text-center"><p className="text-white/60">{title}</p>{action}</div>
);
export const PageHeader = ({ title, subtitle, action }: { title: string; subtitle?: string; action?: ReactNode }) => (
  <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
    <div><h1 className="font-display text-2xl font-bold sm:text-3xl">{title}</h1>{subtitle && <p className="mt-1 text-sm text-white/50">{subtitle}</p>}</div>{action}
  </div>
);

/** Table on desktop, stacked cards on phones: works properly on small screens. */
export interface Col<T = Record<string, any>> { key: string; label: string; render: (r: T) => ReactNode; className?: string; hideOnMobile?: boolean }
export function ResponsiveTable<T extends Record<string, any> = Record<string, any>>({ rows, cols, rowKey, actions, onRowClick }: { rows: T[]; cols: Col<T>[]; rowKey: (r: T) => string; actions?: (r: T) => ReactNode; onRowClick?: (r: T) => void }) {
  return (
    <>
      <div className="card hidden overflow-x-auto md:block">
        <table className="w-full text-left text-sm">
          <thead className="border-b border-white/10 text-xs uppercase tracking-wider text-white/45"><tr>{cols.map((c) => <th key={c.key} scope="col" className="px-4 py-3 font-semibold">{c.label}</th>)}{actions && <th scope="col" className="px-4 py-3 text-right">Actions</th>}</tr></thead>
          <tbody className="divide-y divide-white/5">
            {rows.map((r) => (
              <tr key={rowKey(r)} className={`align-middle ${onRowClick ? 'cursor-pointer hover:bg-white/[0.03]' : ''}`} onClick={() => onRowClick?.(r)}>
                {cols.map((c) => <td key={c.key} className={`px-4 py-3 ${c.className ?? ''}`}>{c.render(r)}</td>)}
                {actions && <td className="px-4 py-3 text-right" onClick={(e) => e.stopPropagation()}>{actions(r)}</td>}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <ul className="space-y-3 md:hidden">
        {rows.map((r) => (
          <li key={rowKey(r)} className="card space-y-2 p-4" onClick={() => onRowClick?.(r)}>
            {cols.filter((c) => !c.hideOnMobile).map((c) => <div key={c.key} className="flex items-start justify-between gap-4 text-sm"><span className="shrink-0 text-xs uppercase tracking-wider text-white/40">{c.label}</span><span className="min-w-0 text-right">{c.render(r)}</span></div>)}
            {actions && <div className="flex flex-wrap justify-end gap-2 border-t border-white/10 pt-3" onClick={(e) => e.stopPropagation()}>{actions(r)}</div>}
          </li>
        ))}
      </ul>
    </>
  );
}
export const IconBtn = ({ label, onClick, children, danger, disabled }: { label: string; onClick: () => void; children: ReactNode; danger?: boolean; disabled?: boolean }) => (
  <button type="button" aria-label={label} title={label} disabled={disabled} onClick={onClick}
    className={`inline-grid h-10 min-w-10 place-items-center rounded-lg border border-white/10 px-2 text-sm transition disabled:opacity-30 ${danger ? 'hover:border-red-500/50 hover:bg-red-500/10 hover:text-red-300' : 'hover:border-cyan/50 hover:bg-white/5'}`}>{children}</button>
);
export const Pager = ({ page, total, limit, onPage }: { page: number; total: number; limit: number; onPage: (p: number) => void }) => {
  const pages = Math.max(1, Math.ceil(total / limit));
  return pages <= 1 ? null : (
    <div className="mt-5 flex items-center justify-center gap-3 text-sm">
      <button className="btn btn-ghost min-h-[40px] px-4" disabled={page <= 1} onClick={() => onPage(page - 1)}>Previous</button>
      <span className="text-white/60">Page {page} of {pages} · {total} items</span>
      <button className="btn btn-ghost min-h-[40px] px-4" disabled={page >= pages} onClick={() => onPage(page + 1)}>Next</button>
    </div>
  );
};
