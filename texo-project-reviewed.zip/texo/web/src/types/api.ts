export interface PriceBlock {
  regular: number; final: number; save: number; percent: number;
  source: 'regular' | 'sale' | 'offer'; offerText: string | null; offerEndsAt: string | null;
}
export interface Category { id: string; name: string; slug: string; icon_url: string | null; display_order: number }
export interface ProductSummary {
  id: string; slug: string; sku: string; name: string; short_desc: string | null;
  stock: number; stock_status: 'in_stock' | 'low_stock' | 'out_of_stock' | 'preorder';
  main_image_url: string | null; thumb_url: string | null; is_featured: boolean;
  categories: { name: string; slug: string } | null; price: PriceBlock | null;
  order_button_enabled?: boolean; order_button_text?: string | null;
  model?: { model_url: string; format: 'glb' | 'gltf' } | null;
}
export interface ProductDetail extends ProductSummary {
  full_desc: string | null; features: string[]; specifications: Record<string, string>; video_url: string | null;
  images: { id: string; url: string; thumb_url: string | null; alt_text: string | null }[];
  related: ProductSummary[];
}
export type Settings = Record<string, any>;
export interface Offer {
  id: string; title: string; offer_text: string | null; discount_percent: number | null; offer_price: number | null;
  starts_at: string | null; ends_at: string | null; banner_url: string | null; product_id: string | null; category_id: string | null;
}
export interface NewsItem { id: string; slug: string; title: string; description: string | null; thumbnail_url: string | null; published_at: string }
export interface QuoteLine {
  productId: string; slug: string | null; name: string; image: string | null; quantity: number;
  regularPrice: number; unitPrice: number; lineTotal: number; priceSource: 'regular' | 'sale' | 'offer'; offerText: string | null;
}
export interface Quote {
  lines: QuoteLine[]; regularSubtotal: number; subtotal: number; discount: number; deliveryCharge: number; total: number;
  deliveryZone: 'inside_dhaka' | 'outside_dhaka' | null; deliveryPending: boolean; freeDeliveryThreshold: number;
}
export interface PlacedOrder extends Quote { orderNo: number }
export interface PageMeta { page: number; limit: number; total: number }
export interface HeroMeta { total: number; nextOffset: number }
export interface Page<T, M = PageMeta> { data: T; meta?: M }
export interface HeroProduct {
  id: string; slug: string; name: string; short_desc: string | null; stock_status: ProductSummary['stock_status'];
  main_image_url: string | null; thumb_url: string | null; price: PriceBlock | null;
  model: { model_url: string; format: 'glb' | 'gltf' } | null;
}
export interface CartItem { productId: string; quantity: number }
