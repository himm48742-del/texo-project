let symbol = '৳';
/** Currency symbol comes from Admin settings (set once by the layout). */
export const setCurrencySymbol = (s?: string) => { symbol = s && s.trim() ? s.trim() : '৳'; };
/** 2490 -> "৳2,490"; 59.97 -> "৳59.97" */
export function formatTaka(n: number): string {
  const v = Math.round(n * 100) / 100;
  const s = Number.isInteger(v)
    ? v.toLocaleString('en-IN')
    : v.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  return `${symbol}${s}`;
}
export function formatDate(iso: string): string {
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? '' : d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
}
