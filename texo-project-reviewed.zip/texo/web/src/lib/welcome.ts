import { clampSpeed } from './heroQueue.ts';

export type WelcomeMode = 'full' | 'short' | 'skip';
/** First ever visit: full intro. Later visit in a new session: short. Same session / reduced motion / not the home page: none. */
export function welcomeMode(o: { seenBefore: boolean; seenThisSession: boolean; reducedMotion: boolean; isHome: boolean }): WelcomeMode {
  if (!o.isHome || o.reducedMotion || o.seenThisSession) return 'skip';
  return o.seenBefore ? 'short' : 'full';
}
export type StepId = 'line1' | 'line2' | 'logo' | 'brand';
export interface Step { id: StepId; ms: number }
const FULL: [StepId, number][] = [['line1', 1900], ['line2', 2100], ['logo', 1200], ['brand', 1600]];
const SHORT: [StepId, number][] = [['logo', 900], ['brand', 1300]];
export function welcomeTimeline(mode: WelcomeMode, speed: unknown): Step[] {
  if (mode === 'skip') return [];
  const s = clampSpeed(speed);
  return (mode === 'full' ? FULL : SHORT).map(([id, ms]) => ({ id, ms: Math.round(ms / s) }));
}
export const exitMs = (speed: unknown) => Math.round(900 / clampSpeed(speed));

/** Splits text into user-perceived characters so Bangla conjuncts/vowel signs are never torn apart. */
export function splitGraphemes(text: string): string[] {
  try {
    const seg = new Intl.Segmenter('bn', { granularity: 'grapheme' });
    return Array.from(seg.segment(text), (x) => x.segment);
  } catch {
    return Array.from(text);
  }
}
/** Deterministic pseudo-random numbers (same particles every render, no flicker). */
export function seeded(seed: number) {
  let a = seed >>> 0;
  return () => { a = (a + 0x6d2b79f5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}
