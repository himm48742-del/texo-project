import type { CartItem, Category, HeroMeta, HeroProduct, NewsItem, Offer, Page, PageMeta, PlacedOrder, ProductDetail, ProductSummary, Quote, Settings } from '../types/api';

const BASE = (import.meta.env.VITE_API_URL as string | undefined) || '/api';

export class ApiError extends Error {
  status: number; code: string; details?: { field: string; message: string }[];
  constructor(status: number, code: string, message: string, details?: { field: string; message: string }[]) {
    super(message); this.status = status; this.code = code; this.details = details;
  }
}

async function request<T, M = PageMeta>(path: string, init?: RequestInit): Promise<Page<T, M>> {
  let res: Response;
  try {
    res = await fetch(BASE + path, { ...init, headers: { 'Content-Type': 'application/json', ...(init?.headers ?? {}) } });
  } catch {
    throw new ApiError(0, 'NETWORK', 'We cannot reach TEXO right now. Please check your connection and try again.');
  }
  let body: any = null;
  try { body = await res.json(); } catch { /* non-JSON response */ }
  if (!res.ok) {
    throw new ApiError(res.status, body?.error?.code ?? 'ERROR',
      body?.error?.message ?? 'Something went wrong. Please try again.', body?.error?.details);
  }
  return body as Page<T, M>;
}
const qs = (o: Record<string, string | number | undefined>) => {
  const p = new URLSearchParams();
  for (const [k, v] of Object.entries(o)) if (v !== undefined && v !== '') p.set(k, String(v));
  const s = p.toString();
  return s ? `?${s}` : '';
};
const post = (body: unknown): RequestInit => ({ method: 'POST', body: JSON.stringify(body) });

export const api = {
  settings: async () => (await request<Settings>('/settings')).data,
  categories: async () => (await request<Category[]>('/categories')).data,
  products: (p: { category?: string; view?: string; page?: number; limit?: number }) => request<ProductSummary[]>(`/products${qs(p)}`),
  product: async (slug: string) => (await request<ProductDetail>(`/products/${encodeURIComponent(slug)}`)).data,
  heroPage: (offset: number, limit = 6) => request<HeroProduct[], HeroMeta>(`/hero${qs({ offset, limit })}`),
  search: async (q: string, limit = 12) => (await request<ProductSummary[]>(`/search${qs({ q, limit })}`)).data,
  offers: async () => (await request<Offer[]>('/offers')).data,
  news: async (limit = 6) => (await request<NewsItem[]>(`/news${qs({ limit })}`)).data,
  quote: async (items: CartItem[], district: string | null) => (await request<Quote>('/orders/quote', post({ items, district }))).data,
  placeOrder: async (b: { customer: Record<string, string>; items: CartItem[]; channel: 'web' | 'whatsapp' }) =>
    (await request<PlacedOrder>('/orders', post(b))).data,
};
