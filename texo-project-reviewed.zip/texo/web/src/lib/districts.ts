export const DISTRICTS = [
  'Dhaka', 'Gazipur', 'Narayanganj', 'Narsingdi', 'Manikganj', 'Munshiganj', 'Tangail', 'Kishoreganj', 'Faridpur', 'Gopalganj',
  'Madaripur', 'Rajbari', 'Shariatpur', 'Chattogram', "Cox's Bazar", 'Cumilla', 'Feni', 'Brahmanbaria', 'Chandpur', 'Lakshmipur',
  'Noakhali', 'Khagrachhari', 'Rangamati', 'Bandarban', 'Sylhet', 'Moulvibazar', 'Habiganj', 'Sunamganj', 'Rajshahi', 'Natore',
  'Naogaon', 'Chapainawabganj', 'Pabna', 'Bogura', 'Sirajganj', 'Joypurhat', 'Khulna', 'Jashore', 'Satkhira', 'Bagerhat',
  'Narail', 'Magura', 'Jhenaidah', 'Chuadanga', 'Kushtia', 'Meherpur', 'Barishal', 'Bhola', 'Patuakhali', 'Pirojpur',
  'Jhalokati', 'Barguna', 'Rangpur', 'Dinajpur', 'Gaibandha', 'Kurigram', 'Lalmonirhat', 'Nilphamari', 'Panchagarh',
  'Thakurgaon', 'Mymensingh', 'Jamalpur', 'Netrokona', 'Sherpur',
];
