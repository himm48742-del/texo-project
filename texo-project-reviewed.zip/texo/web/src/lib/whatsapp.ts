import { formatTaka } from './format.ts';

/** "01601603092" -> "8801601603092"; "+880 1601-603092" -> "8801601603092" */
export function normalizeWaNumber(raw: string): string {
  const d = raw.replace(/\D/g, '');
  if (d.startsWith('01')) return `880${d.slice(1)}`;
  return d;
}
export const whatsappUrl = (number: string, text: string) => `https://wa.me/${normalizeWaNumber(number)}?text=${encodeURIComponent(text)}`;

export interface WaLine { name: string; quantity: number; unitPrice: number; regularPrice: number }
export interface WaInput {
  orderNo?: number;
  lines: WaLine[];
  subtotal?: number; deliveryCharge?: number; total?: number;
  customer?: { name: string; phone: string; address: string; district: string; area?: string; notes?: string };
}
/** Message text. All amounts come from the server (quote/order), never from the browser's own maths. */
export function buildWhatsAppMessage(i: WaInput): string {
  const out: string[] = [i.orderNo ? `TEXO Order #${i.orderNo}` : 'TEXO — I want to order', ''];
  for (const l of i.lines) {
    const off = l.regularPrice > l.unitPrice ? ` (was ${formatTaka(l.regularPrice)})` : '';
    out.push(`• ${l.name} × ${l.quantity} — ${formatTaka(l.unitPrice)}${off}`);
  }
  if (i.total !== undefined) {
    out.push('');
    if (i.subtotal !== undefined) out.push(`Subtotal: ${formatTaka(i.subtotal)}`);
    if (i.deliveryCharge !== undefined) out.push(`Delivery: ${formatTaka(i.deliveryCharge)}`);
    out.push(`Total: ${formatTaka(i.total)}`);
  }
  if (i.customer) {
    const c = i.customer;
    out.push('', `Name: ${c.name}`, `Phone: ${c.phone}`, `Address: ${c.address}${c.area ? `, ${c.area}` : ''}, ${c.district}`);
    if (c.notes) out.push(`Notes: ${c.notes}`);
  }
  return out.join('\n');
}
