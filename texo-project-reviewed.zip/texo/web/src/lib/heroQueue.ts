// Pure helpers for the hero product queue (no React) so they can be unit-tested.
export interface HasId { id: string }
export interface HasImage extends HasId { main_image_url: string | null; thumb_url: string | null }

/** Appends only products not already in the queue (a batch may repeat after the server wraps around). */
export function mergeBatch<T extends HasId>(current: T[], batch: T[]): T[] {
  const seen = new Set(current.map((i) => i.id));
  const fresh: T[] = [];
  for (const b of batch) if (!seen.has(b.id)) { seen.add(b.id); fresh.push(b); }
  return fresh.length ? [...current, ...fresh] : current;
}
/** Next position. At the end: wait (stay) if more products are still loading, otherwise loop to the start. */
export function nextIndex(i: number, length: number, hasMore: boolean): number {
  if (length <= 1) return 0;
  const n = i + 1;
  return n < length ? n : hasMore ? i : 0;
}
export const prevIndex = (i: number, length: number): number => (length <= 1 ? 0 : (i - 1 + length) % length);
/** Fetch the next batch when the viewer is within `ahead` products of the end of what is loaded. */
export function shouldFetchMore(index: number, length: number, total: number, ahead = 3): boolean {
  if (length === 0) return true;
  return length < total && index >= length - ahead;
}
/** Image URLs worth preloading: only the next `count` products after the current one. */
export function preloadTargets<T extends HasImage>(items: T[], index: number, count = 2): string[] {
  if (items.length < 2) return [];
  const urls: string[] = [];
  for (let k = 1; k <= count && k < items.length; k++) {
    const it = items[(index + k) % items.length];
    const u = it.main_image_url ?? it.thumb_url;
    if (u && !urls.includes(u)) urls.push(u);
  }
  return urls;
}
const num = (v: unknown, def: number, min: number, max: number) => {
  const n = Number(v);
  return Number.isFinite(n) && v !== null && v !== '' ? Math.min(max, Math.max(min, n)) : def;
};
/** Admin setting hero_rotation_seconds -> 3..30 s (default 6). */
export const clampSeconds = (v: unknown) => num(v, 6, 3, 30);
/** Admin setting hero_animation_speed -> 0.5..2 (default 1). */
export const clampSpeed = (v: unknown) => num(v, 1, 0.5, 2);
