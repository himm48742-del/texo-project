// Mirrors the server rules so customers get instant feedback. The server remains the authority.
export function normalizePhone(raw: string): string | null {
  let p = raw.replace(/[\s\-()]/g, '');
  if (p.startsWith('+88')) p = p.slice(3);
  else if (p.startsWith('88') && p.length === 13) p = p.slice(2);
  return /^01[3-9]\d{8}$/.test(p) ? p : null;
}
export interface CheckoutForm { name: string; phone: string; address: string; district: string; area: string; notes: string }
export function validateCheckout(f: CheckoutForm): Partial<Record<keyof CheckoutForm, string>> {
  const e: Partial<Record<keyof CheckoutForm, string>> = {};
  if (f.name.trim().length < 2) e.name = 'Please enter your name.';
  if (!normalizePhone(f.phone)) e.phone = 'Enter a valid mobile number, e.g. 01XXXXXXXXX.';
  if (f.address.trim().length < 8) e.address = 'Please enter your full address.';
  if (!f.district) e.district = 'Please select your district.';
  return e;
}
