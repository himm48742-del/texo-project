const done = new Set<string>();
/** Warms the browser cache + decodes an image off-screen. Each URL is requested at most once. */
export function preloadImage(url: string) {
  if (done.has(url)) return;
  done.add(url);
  const img = new Image();
  img.decoding = 'async';
  img.src = url;
  img.decode?.().catch(() => { /* broken image: the visible <img> shows the fallback */ });
}
let webgl: boolean | undefined;
export function canWebGL(): boolean {
  if (webgl !== undefined) return webgl;
  try {
    const c = document.createElement('canvas');
    webgl = !!(c.getContext('webgl2') || c.getContext('webgl'));
  } catch { webgl = false; }
  return webgl;
}
