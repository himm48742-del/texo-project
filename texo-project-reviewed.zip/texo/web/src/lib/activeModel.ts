// Only ONE product card may run a real 3D (WebGL) scene at a time. Browsers allow only a handful of WebGL
// contexts, and a grid with dozens of live 3D scenes would be slow. Tiny shared store, no React needed.
let active: string | null = null;
const subs = new Set<() => void>();
export const getActive = (): string | null => active;
export const setActive = (id: string | null): void => { if (active !== id) { active = id; subs.forEach((f) => f()); } };
export const subscribe = (f: () => void): (() => void) => { subs.add(f); return () => { subs.delete(f); }; };
