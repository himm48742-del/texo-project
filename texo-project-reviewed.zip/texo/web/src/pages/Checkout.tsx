import { Trash2 } from 'lucide-react';
import { useRef, useState } from 'react';
import type { InputHTMLAttributes, ReactNode } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { EmptyState } from '../components/States';
import { useCart } from '../hooks/cart';
import { useDocumentTitle, useQuote, useSettings } from '../hooks/queries';
import { ApiError, api } from '../lib/api';
import { DISTRICTS } from '../lib/districts';
import { formatTaka } from '../lib/format';
import { validateCheckout } from '../lib/validation';
import type { CheckoutForm } from '../lib/validation';
import { ProductImage } from '../components/ProductImage';
import { Qty } from './ProductPage';

type Errors = Partial<Record<keyof CheckoutForm, string>>;
const EMPTY: CheckoutForm = { name: '', phone: '', address: '', district: '', area: '', notes: '' };

export function Checkout({ header }: { header?: ReactNode } = {}) {
  useDocumentTitle('Order');
  const cart = useCart();
  const nav = useNavigate();
  const { data: settings } = useSettings();
  const [form, setForm] = useState<CheckoutForm>(EMPTY);
  const [errors, setErrors] = useState<Errors>({});
  const [busy, setBusy] = useState<null | 'web' | 'whatsapp'>(null);
  const [formError, setFormError] = useState('');
  const formRef = useRef<HTMLFormElement>(null);
  const quote = useQuote(cart.items, form.district);
  const q = quote.data;
  const set = (k: keyof CheckoutForm) => (e: { target: { value: string } }) => { setForm((f) => ({ ...f, [k]: e.target.value })); setErrors((x) => ({ ...x, [k]: undefined })); };

  if (cart.items.length === 0)
    return <div className="container-x py-16"><EmptyState title="Your order is empty. Choose a product to get started." /></div>;

  async function submit(channel: 'web' | 'whatsapp') {
    const e = validateCheckout(form);
    setErrors(e);
    if (Object.keys(e).length) {
      (formRef.current?.querySelector(`[name="${Object.keys(e)[0]}"]`) as HTMLElement | null)?.focus();
      return;
    }
    setBusy(channel); setFormError('');
    try {
      const order = await api.placeOrder({
        customer: { name: form.name, phone: form.phone, address: form.address, district: form.district, area: form.area, notes: form.notes },
        items: cart.items, channel,
      });
      cart.clear();
      nav(`/order-success/${order.orderNo}`, { state: { order, customer: form, channel } });
    } catch (err) {
      if (err instanceof ApiError) {
        if (err.details) {
          const m: Errors = {};
          for (const d of err.details) { const k = d.field.replace('customer.', '') as keyof CheckoutForm; if (k in EMPTY) m[k] = d.message; }
          setErrors(m);
        }
        setFormError(err.message);
        if (err.status === 404 || err.status === 409) quote.refetch();
      } else setFormError('Something went wrong. Please try again.');
    } finally { setBusy(null); }
  }

  const field = (k: keyof CheckoutForm, label: string, props: InputHTMLAttributes<HTMLInputElement> = {}) => (
    <div>
      <label className="label" htmlFor={`f-${k}`}>{label}</label>
      <input id={`f-${k}`} name={k} className="input" value={form[k]} onChange={set(k)} aria-invalid={!!errors[k]} aria-describedby={errors[k] ? `e-${k}` : undefined} {...props} />
      {errors[k] && <p id={`e-${k}`} className="mt-1.5 text-sm text-red-400">{errors[k]}</p>}
    </div>
  );
  const needMore = q && !q.deliveryPending && q.freeDeliveryThreshold > 0 && q.deliveryCharge > 0 ? q.freeDeliveryThreshold - q.subtotal : 0;

  return (
    <div className="container-x py-8 lg:py-12">
      <h1 className="font-display text-3xl font-bold sm:text-4xl">{header ? 'Order now' : 'Your order'}</h1>
      {header}
      <div className="mt-8 grid gap-8 lg:grid-cols-[minmax(0,1fr)_420px]">
        <form ref={formRef} noValidate onSubmit={(e) => { e.preventDefault(); submit('web'); }} className="card space-y-5 p-5 sm:p-7" aria-label="Delivery details">
          <h2 className="font-display text-xl font-semibold">Delivery details</h2>
          {field('name', 'Full name', { autoComplete: 'name' })}
          {field('phone', 'Mobile number', { inputMode: 'tel', autoComplete: 'tel', placeholder: '01XXXXXXXXX' })}
          <div>
            <label className="label" htmlFor="f-address">Full address</label>
            <textarea id="f-address" name="address" rows={3} className="input py-3" value={form.address} onChange={set('address')} autoComplete="street-address" aria-invalid={!!errors.address} />
            {errors.address && <p className="mt-1.5 text-sm text-red-400">{errors.address}</p>}
          </div>
          <div className="grid gap-5 sm:grid-cols-2">
            <div>
              <label className="label" htmlFor="f-district">District</label>
              <select id="f-district" name="district" className="input" value={form.district} onChange={set('district')} aria-invalid={!!errors.district}>
                <option value="">Select district</option>
                {DISTRICTS.map((d) => <option key={d} value={d}>{d}</option>)}
              </select>
              {errors.district && <p className="mt-1.5 text-sm text-red-400">{errors.district}</p>}
            </div>
            {field('area', 'Area / Thana')}
          </div>
          <div>
            <label className="label" htmlFor="f-notes">Order notes (optional)</label>
            <textarea id="f-notes" name="notes" rows={2} maxLength={500} className="input py-3" value={form.notes} onChange={set('notes')} />
          </div>
          <fieldset>
            <legend className="label">Delivery option</legend>
            <div className="grid gap-3 sm:grid-cols-2">
              {([['inside_dhaka', 'Inside Dhaka', Number(settings?.delivery_inside_dhaka ?? 60)], ['outside_dhaka', 'Outside Dhaka', Number(settings?.delivery_outside_dhaka ?? 120)]] as const).map(([zone, label, fee]) => {
                const on = q?.deliveryZone === zone;
                return <div key={zone} aria-current={on ? 'true' : undefined} className={`rounded-xl border px-4 py-3 text-sm ${on ? 'border-cyan bg-cyan/10' : 'border-white/10 text-white/55'}`}><p className="font-semibold">{label}</p><p>{formatTaka(fee)}{on && q && q.deliveryCharge === 0 ? ' — free for this order' : ''}</p></div>;
              })}
            </div>
            <p className="mt-2 text-xs text-white/50">{q?.deliveryPending === false ? 'Chosen automatically from your district.' : 'Select your district to see which delivery charge applies.'} Payment: cash on delivery.</p>
          </fieldset>
          {formError && <p role="alert" className="rounded-xl border border-red-500/40 bg-red-500/10 p-3 text-sm text-red-300">{formError}</p>}
          <div className="flex flex-col gap-3 sm:flex-row">
            <button type="submit" className="btn btn-primary flex-1" disabled={!!busy || !q}>{busy === 'web' ? 'Placing order…' : 'CONFIRM ORDER'}</button>
            {settings?.whatsapp_number && (
              <button type="button" className="btn btn-ghost flex-1" disabled={!!busy || !q} onClick={() => submit('whatsapp')}>{busy === 'whatsapp' ? 'Please wait…' : 'Order via WhatsApp'}</button>
            )}
          </div>
        </form>

        <aside className="card h-fit space-y-5 p-5 sm:p-7 lg:sticky lg:top-24" aria-label="Order summary" aria-busy={quote.isFetching}>
          <h2 className="font-display text-xl font-semibold">Summary</h2>
          {quote.isError && (
            <div role="alert" className="rounded-xl border border-gold/40 bg-gold/10 p-3 text-sm text-gold">
              {(quote.error as Error).message}
              <button className="ml-2 underline" onClick={() => cart.clear()}>Clear order</button>
            </div>
          )}
          <ul className="space-y-4">
            {q?.lines.map((l) => (
              <li key={l.productId} className="flex gap-3">
                <ProductImage src={l.image} alt="" className="h-16 w-16 shrink-0 rounded-xl border border-white/10 p-1" />
                <div className="min-w-0 flex-1">
                  <Link to={l.slug ? `/product/${l.slug}` : '#'} className="block truncate text-sm font-medium hover:text-cyan">{l.name}</Link>
                  <p className="text-sm">
                    <span className="font-semibold">{formatTaka(l.unitPrice)}</span>
                    {l.regularPrice > l.unitPrice && <s className="ml-2 text-white/40">{formatTaka(l.regularPrice)}</s>}
                  </p>
                  <div className="mt-1 flex items-center gap-2">
                    <Qty value={l.quantity} onChange={(n) => cart.setQty(l.productId, n)} label={`Quantity of ${l.name}`} />
                    <button type="button" className="grid h-11 w-11 place-items-center rounded-full text-white/50 hover:bg-white/10 hover:text-red-400" aria-label={`Remove ${l.name}`} onClick={() => cart.remove(l.productId)}><Trash2 className="h-4 w-4" /></button>
                  </div>
                </div>
                <p className="text-sm font-semibold">{formatTaka(l.lineTotal)}</p>
              </li>
            ))}
          </ul>
          {q ? (
            <dl className="space-y-2.5 border-t border-white/10 pt-4 text-sm">
              <Row k="Regular price" v={formatTaka(q.regularSubtotal)} />
              {q.discount > 0 && <Row k="Discount" v={`−${formatTaka(q.discount)}`} accent />}
              <Row k="Subtotal" v={formatTaka(q.subtotal)} />
              <Row k="Delivery" v={q.deliveryPending ? 'Select district' : q.deliveryCharge === 0 ? 'Free' : formatTaka(q.deliveryCharge)} />
              {needMore > 0 && <p className="text-xs text-cyan">Add {formatTaka(needMore)} more for free delivery.</p>}
              <div className="flex items-baseline justify-between border-t border-white/10 pt-3"><dt className="font-semibold">Grand total</dt><dd className="font-display text-2xl font-bold">{formatTaka(q.total)}</dd></div>
            </dl>
          ) : !quote.isError && <div className="h-24 animate-pulse rounded-xl bg-white/5" />}
          <p className="text-xs text-white/40">Final prices are confirmed by TEXO when you place the order.</p>
        </aside>
      </div>
    </div>
  );
}
const Row = ({ k, v, accent }: { k: string; v: string; accent?: boolean }) => (
  <div className="flex justify-between"><dt className="text-white/60">{k}</dt><dd className={accent ? 'font-medium text-gold' : ''}>{v}</dd></div>
);
