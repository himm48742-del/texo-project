import { ArrowRight } from 'lucide-react';
import { HeroShowcase } from '../components/hero/HeroShowcase';
import { Link } from 'react-router-dom';
import { Catalogue } from '../components/Catalogue';
import { StoreShell } from '../components/StoreShell';
import { useDocumentTitle, useSettings } from '../hooks/queries';

export function Home() {
  const { data: s } = useSettings();
  useDocumentTitle(undefined, 'TEXO — modern gadgets, smart devices and everyday technology.');
  const headline = String(s?.hero_headline ?? 'YOUR TECH.\nYOUR\nEXPERIENCE.').split('\n');
  return (
    <StoreShell>
      <section className="card relative mb-10 overflow-hidden px-5 py-6 sm:px-10 lg:py-8" aria-label="Welcome">
        <div className="absolute -right-24 -top-24 h-72 w-72 rounded-full bg-cyan/10 blur-3xl" aria-hidden="true" />
        <div className="relative grid items-center gap-6 md:grid-cols-[0.9fr_1.1fr]">
          <div>
            <h1 className="font-display text-3xl font-bold leading-[1.05] tracking-tight sm:text-5xl xl:text-6xl">
              {headline.map((l, i) => <span key={i} className={`block max-sm:inline max-sm:mr-2 ${i === headline.length - 1 ? 'bg-gradient-to-r from-cyan to-electric bg-clip-text text-transparent' : ''}`}>{l}</span>)}
            </h1>
            <p className="mt-5 hidden max-w-md text-white/65 sm:block">{s?.hero_description ?? 'Modern gadgets, smart devices and everyday technology — selected to make your digital life simpler, smarter and better.'}</p>
            <div className="mt-7 hidden flex-wrap gap-3 sm:flex">
              <Link to="/products" className="btn btn-primary">Shop now <ArrowRight className="h-4 w-4" /></Link>
              <Link to="/products?view=offers" className="btn btn-ghost">View offers</Link>
            </div>
          </div>
          <HeroShowcase />
        </div>
      </section>
      <Catalogue />
    </StoreShell>
  );
}

export function Products() {
  useDocumentTitle('Products');
  return <StoreShell><Catalogue /></StoreShell>;
}
