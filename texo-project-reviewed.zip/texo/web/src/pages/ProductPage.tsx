import { motion } from 'framer-motion';
import { Box, Check, Image as ImageIcon, Minus, Plus, ShoppingBag } from 'lucide-react';
import { lazy, Suspense, useEffect, useRef, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { SoftBoundary } from '../components/hero/SoftBoundary';
import { PriceRows } from '../components/PriceTag';
import { ProductCard } from '../components/ProductCard';
import { ProductImage } from '../components/ProductImage';
import { ErrorState } from '../components/States';
import { useCart } from '../hooks/cart';
import { useDocumentTitle, useProduct, useSettings } from '../hooks/queries';
import { ApiError } from '../lib/api';
import { canWebGL } from '../lib/preload';
import { buildWhatsAppMessage, whatsappUrl } from '../lib/whatsapp';

const ModelStage = lazy(() => import('../components/hero/ModelStage')); // real 3D viewer: downloaded only when needed

export function Qty({ value, onChange, label = 'Quantity' }: { value: number; onChange: (n: number) => void; label?: string }) {
  return (
    <div className="inline-flex items-center rounded-full border border-white/15" role="group" aria-label={label}>
      <button type="button" className="grid h-11 w-11 place-items-center rounded-full hover:bg-white/10 disabled:opacity-30" aria-label="Decrease quantity" disabled={value <= 1} onClick={() => onChange(value - 1)}><Minus className="h-4 w-4" /></button>
      <span className="w-10 text-center font-semibold tabular-nums" aria-live="polite">{value}</span>
      <button type="button" className="grid h-11 w-11 place-items-center rounded-full hover:bg-white/10 disabled:opacity-30" aria-label="Increase quantity" disabled={value >= 20} onClick={() => onChange(value + 1)}><Plus className="h-4 w-4" /></button>
    </div>
  );
}

export function ProductPage() {
  const { slug = '' } = useParams();
  const { data: p, isLoading, error, refetch } = useProduct(slug);
  const { data: settings } = useSettings();
  const cart = useCart();
  const nav = useNavigate();
  const [qty, setQty] = useState(1);
  const [active, setActive] = useState(0);
  const [view, setView] = useState<'photo' | '3d'>('photo');
  const moved = useRef(false);
  const [added, setAdded] = useState(false);
  useDocumentTitle(p ? `${p.name} | ${p.categories?.name ?? 'Gadgets'}` : 'Product', p?.short_desc ?? undefined);
  useEffect(() => { setQty(1); setActive(0); setView('photo'); }, [slug]);

  if (isLoading) return <div className="container-x grid gap-8 py-10 md:grid-cols-2" aria-busy="true"><div className="aspect-square animate-pulse rounded-3xl bg-white/5" /><div className="space-y-4"><div className="h-8 w-2/3 animate-pulse rounded bg-white/10" /><div className="h-6 w-1/3 animate-pulse rounded bg-white/10" /></div></div>;
  if (error || !p) {
    const missing = error instanceof ApiError && error.status === 404;
    return (
      <div className="container-x py-16">
        <ErrorState message={missing ? 'This product could not be found. It may have been removed.' : (error as Error | null)?.message} onRetry={missing ? undefined : () => refetch()} />
        <div className="mt-6 text-center"><Link to="/products" className="btn btn-primary">Explore All Products</Link></div>
      </div>
    );
  }

  const gallery = [p.main_image_url, ...p.images.map((i) => i.url)].filter((v, i, a): v is string => !!v && a.indexOf(v) === i);
  const out = p.stock_status === 'out_of_stock';
  const orderable = !out && p.order_button_enabled !== false;
  const can3D = !!p.model && canWebGL();
  const stockLabel = out ? 'Out of stock' : p.stock_status === 'low_stock' ? `Only ${p.stock} left` : p.stock_status === 'preorder' ? 'Pre-order' : 'In stock';
  const waNumber = settings?.whatsapp_number as string | undefined;
  const wa = waNumber && p.price ? whatsappUrl(waNumber, buildWhatsAppMessage({ lines: [{ name: p.name, quantity: qty, unitPrice: p.price.final, regularPrice: p.price.regular }], total: p.price.final * qty })) : null;

  return (
    <div className="container-x py-6 lg:py-10">
      <nav aria-label="Breadcrumb" className="mb-5 text-sm text-white/50">
        <Link to="/" className="hover:text-cyan">Home</Link> / <Link to="/products" className="hover:text-cyan">Products</Link>
        {p.categories && <> / <Link to={`/products?category=${p.categories.slug}`} className="hover:text-cyan">{p.categories.name}</Link></>}
      </nav>
      <div className="grid gap-8 lg:grid-cols-2 lg:gap-14">
        <div>
          <motion.div key={active} initial={{ opacity: 0, scale: 0.98 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.35 }}
            className="relative aspect-square overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-b from-white/[0.06] to-transparent">
            <div className="absolute inset-x-10 bottom-6 h-10 rounded-full bg-black/60 blur-2xl" aria-hidden="true" />
            {view === '3d' && can3D ? (
              <SoftBoundary fallback={<ProductImage src={gallery[active]} alt={p.name} eager className="relative h-full w-full p-8" />}>
                <Suspense fallback={<div className="grid h-full place-items-center text-white/50" role="status">Loading 3D…</div>}><ModelStage url={p.model!.model_url} speed={1} active movedRef={moved} /></Suspense>
              </SoftBoundary>
            ) : <ProductImage src={gallery[active]} alt={p.name} eager className="relative h-full w-full p-8" />}
            {p.price && p.price.percent > 0 && !out && <span className="absolute left-4 top-4 rounded-full bg-gold px-3 py-1 text-xs font-bold text-ink">{p.price.percent}% OFF</span>}
          </motion.div>
          {can3D && (
            <div className="mt-3 inline-flex rounded-full border border-white/15 p-1" role="group" aria-label="Product view">
              <button type="button" aria-pressed={view === 'photo'} onClick={() => setView('photo')} className={`inline-flex min-h-10 items-center gap-2 rounded-full px-4 text-sm font-semibold ${view === 'photo' ? 'bg-white text-ink' : 'text-white/70'}`}><ImageIcon className="h-4 w-4" />Photos</button>
              <button type="button" aria-pressed={view === '3d'} onClick={() => setView('3d')} className={`inline-flex min-h-10 items-center gap-2 rounded-full px-4 text-sm font-semibold ${view === '3d' ? 'bg-cyan text-ink' : 'text-white/70'}`}><Box className="h-4 w-4" />3D view</button>
            </div>
          )}
          {gallery.length > 1 && (
            <div className="mt-3 flex gap-2 overflow-x-auto pb-1" role="tablist" aria-label="Product images">
              {gallery.map((g, i) => (
                <button key={g} role="tab" aria-selected={i === active} aria-label={`Image ${i + 1}`} onClick={() => setActive(i)}
                  className={`h-16 w-16 shrink-0 overflow-hidden rounded-xl border ${i === active ? 'border-cyan' : 'border-white/10'}`}><ProductImage src={g} alt="" className="h-full w-full p-1" /></button>
              ))}
            </div>
          )}
        </div>

        <div>
          {p.categories && <p className="text-xs font-semibold uppercase tracking-widest text-cyan">{p.categories.name}</p>}
          <h1 className="mt-2 font-display text-3xl font-bold leading-tight sm:text-4xl">{p.name}</h1>
          <p className="mt-1 text-sm text-white/40">SKU: {p.sku}</p>
          {p.short_desc && <p className="mt-4 text-lg text-white/70">{p.short_desc}</p>}
          <div className="mt-6 max-w-sm rounded-2xl border border-white/10 bg-white/[0.03] p-4"><PriceRows price={p.price} large />{(p.price?.offerText ?? p.offer_text) && <p className="mt-3 inline-block rounded-full bg-cyan/10 px-3 py-1 text-xs font-semibold text-cyan">{p.price?.offerText ?? p.offer_text}</p>}</div>
          <p className={`mt-4 inline-flex items-center gap-2 text-sm font-medium ${out ? 'text-red-400' : 'text-emerald-400'}`}><span className="h-2 w-2 rounded-full bg-current" />{stockLabel}</p>

          <div className="mt-6 flex flex-wrap items-center gap-4">
            <Qty value={qty} onChange={setQty} />
            <button className="btn btn-primary flex-1 sm:flex-none sm:px-10" disabled={!orderable} onClick={() => nav(`/order/${p.slug}?qty=${qty}`)}>{!orderable ? (out ? 'Out of stock' : 'Unavailable') : (p.order_button_text || 'ORDER NOW →')}</button>
          </div>
          <div className="mt-3 flex flex-wrap gap-3">
            <button className="btn btn-ghost" disabled={!orderable} onClick={() => { cart.add(p.id, qty); setAdded(true); setTimeout(() => setAdded(false), 2000); }}>
              {added ? <><Check className="h-4 w-4 text-cyan" /> Added</> : <><ShoppingBag className="h-4 w-4" /> Add to order</>}
            </button>
            {wa && <a className="btn btn-ghost" href={wa} target="_blank" rel="noopener noreferrer">Order via WhatsApp</a>}
          </div>

          {p.features.length > 0 && (
            <section className="mt-10"><h2 className="font-display text-xl font-semibold">Features</h2>
              <ul className="mt-3 space-y-2">{p.features.map((f) => <li key={f} className="flex gap-3 text-white/75"><Check className="mt-0.5 h-4 w-4 shrink-0 text-cyan" aria-hidden="true" />{f}</li>)}</ul></section>
          )}
          {p.full_desc && <section className="mt-8"><h2 className="font-display text-xl font-semibold">Description</h2><p className="mt-3 whitespace-pre-line text-white/70">{p.full_desc}</p></section>}
          {Object.keys(p.specifications ?? {}).length > 0 && (
            <section className="mt-8"><h2 className="font-display text-xl font-semibold">Specifications</h2>
              <dl className="mt-3 divide-y divide-white/10 rounded-2xl border border-white/10">
                {Object.entries(p.specifications).map(([k, v]) => <div key={k} className="grid grid-cols-2 gap-4 px-4 py-3 text-sm"><dt className="text-white/50">{k}</dt><dd>{v}</dd></div>)}
              </dl></section>
          )}
        </div>
      </div>

      {p.related.length > 0 && (
        <section className="mt-20" aria-labelledby="rel"><h2 id="rel" className="mb-5 font-display text-2xl font-bold">Related products</h2>
          <div className="grid grid-cols-2 gap-3 sm:gap-5 lg:grid-cols-4">{p.related.map((r, i) => <ProductCard key={r.id} p={r} index={i} />)}</div></section>
      )}
    </div>
  );
}
