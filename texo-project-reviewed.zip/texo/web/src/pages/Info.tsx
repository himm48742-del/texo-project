import type { ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { ProductImage } from '../components/ProductImage';
import { EmptyState, ErrorState, GridSkeleton } from '../components/States';
import { useDocumentTitle, useNews, useOffers, useSettings } from '../hooks/queries';
import { formatDate, formatTaka } from '../lib/format';
import { whatsappUrl } from '../lib/whatsapp';

const Page = ({ title, children }: { title: string; children: ReactNode }) => (
  <div className="container-x py-10 lg:py-14"><h1 className="font-display text-3xl font-bold sm:text-5xl">{title}</h1><div className="mt-8">{children}</div></div>
);

export function Offers() {
  useDocumentTitle('Offers');
  const { data, isLoading, isError, refetch } = useOffers();
  return (
    <Page title="Offers">
      {isLoading ? <GridSkeleton n={3} /> : isError ? <ErrorState onRetry={() => refetch()} /> : !data?.length ? <EmptyState title="No active offers right now. Check back soon." /> : (
        <div className="grid gap-5 md:grid-cols-2">
          {data.map((o) => (
            <article key={o.id} className="card overflow-hidden">
              {o.banner_url && <ProductImage src={o.banner_url} alt="" className="h-44 w-full" />}
              <div className="space-y-2 p-6">
                <h2 className="font-display text-2xl font-bold">{o.title}</h2>
                {o.offer_text && <p className="text-white/70">{o.offer_text}</p>}
                <p className="text-gold">{o.offer_price ? `Now ${formatTaka(o.offer_price)}` : o.discount_percent ? `${o.discount_percent}% OFF` : ''}{o.ends_at ? ` · ends ${formatDate(o.ends_at)}` : ''}</p>
                <Link to="/products?view=offers" className="btn btn-primary mt-2">Shop offers</Link>
              </div>
            </article>
          ))}
        </div>
      )}
    </Page>
  );
}

export function News() {
  useDocumentTitle('Tech News');
  const { data, isLoading, isError, refetch } = useNews(12);
  return (
    <Page title="Tech News">
      {isLoading ? <GridSkeleton n={3} /> : isError ? <ErrorState onRetry={() => refetch()} /> : !data?.length ? <EmptyState title="No articles published yet." cta={false} /> : (
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {data.map((n) => (
            <article key={n.id} className="card overflow-hidden">
              <ProductImage src={n.thumbnail_url} alt="" className="aspect-video w-full" />
              <div className="space-y-2 p-5"><p className="text-xs text-cyan">{formatDate(n.published_at)}</p><h2 className="font-display text-lg font-semibold">{n.title}</h2>{n.description && <p className="line-clamp-3 text-sm text-white/60">{n.description}</p>}</div>
            </article>
          ))}
        </div>
      )}
    </Page>
  );
}

export function About() {
  useDocumentTitle('About TEXO');
  return (
    <Page title="About TEXO">
      <div className="max-w-2xl space-y-4 text-lg text-white/70">
        <p><span className="font-semibold text-white">TEXO</span> stands for <span className="text-cyan">Technology Extra Experience</span>.</p>
        <p>We select modern gadgets, smart devices and everyday technology that make your digital life simpler, smarter and better — with honest prices and fast delivery across Bangladesh.</p>
        <p className="font-display text-2xl font-bold text-white">YOUR TECH.</p>
      </div>
    </Page>
  );
}

export function Contact() {
  useDocumentTitle('Contact');
  const { data: s } = useSettings();
  const social = (s?.social_links ?? {}) as Record<string, string>;
  const rows: [string, string | undefined, string | undefined][] = [
    ['Phone', s?.business_phone, s?.business_phone ? `tel:${s.business_phone}` : undefined],
    ['WhatsApp', s?.whatsapp_number ? 'Chat with us' : undefined, s?.whatsapp_number ? whatsappUrl(s.whatsapp_number, 'Hello TEXO') : undefined],
    ['Facebook', social.facebook, social.facebook], ['Instagram', social.instagram, social.instagram],
    ['Email', social.email, social.email ? `mailto:${social.email}` : undefined],
  ];
  return (
    <Page title="Contact">
      <p className="font-display text-2xl font-bold">{s?.brand_name ?? 'TEXO'} <span className="text-cyan">{s?.tagline ?? 'Your Tech.'}</span></p>
      <dl className="mt-6 max-w-lg divide-y divide-white/10 rounded-2xl border border-white/10">
        {rows.filter(([, v]) => v).map(([k, v, href]) => (
          <div key={k} className="flex items-center justify-between gap-4 px-5 py-4"><dt className="text-white/50">{k}</dt>
            <dd>{href ? <a className="text-cyan hover:underline" href={href} target={href.startsWith('http') ? '_blank' : undefined} rel="noopener noreferrer">{v}</a> : v}</dd></div>
        ))}
      </dl>
    </Page>
  );
}

export function NotFound() {
  useDocumentTitle('Page not found');
  return <Page title="Page not found"><p className="text-white/60">The page you are looking for does not exist.</p><Link to="/" className="btn btn-primary mt-6">Back to home</Link></Page>;
}
