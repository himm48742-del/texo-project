import { useEffect, useState } from 'react';
import { Link, useParams, useSearchParams } from 'react-router-dom';
import { PriceRows } from '../components/PriceTag';
import { ProductImage } from '../components/ProductImage';
import { ErrorState } from '../components/States';
import { useCart } from '../hooks/cart';
import { useDocumentTitle, useProduct } from '../hooks/queries';
import { ApiError } from '../lib/api';
import { Checkout } from './Checkout';

/** /order/:slug : Home -> (product details) -> Order page. Shows the product, then quantity, customer details, delivery and summary. */
export function OrderPage() {
  const { slug = '' } = useParams();
  const [sp] = useSearchParams();
  const { data: p, isLoading, error, refetch } = useProduct(slug);
  const cart = useCart();
  const [ready, setReady] = useState(false);
  useDocumentTitle(p ? `Order ${p.name}` : 'Order');
  // This page orders exactly this product: the order starts with it (quantity from ?qty=). Prices are fetched from the server by the form below.
  useEffect(() => {
    if (!p) return;
    const q = Math.min(20, Math.max(1, parseInt(sp.get('qty') ?? '1', 10) || 1));
    cart.setOnly(p.id, q);
    setReady(true);
  }, [p?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  if (isLoading) return <div className="container-x py-10" aria-busy="true"><div className="h-40 animate-pulse rounded-3xl bg-white/5" /></div>;
  if (error || !p) {
    const missing = error instanceof ApiError && error.status === 404;
    return <div className="container-x py-16"><ErrorState message={missing ? 'This product could not be found.' : (error as Error | null)?.message} onRetry={missing ? undefined : () => refetch()} /><div className="mt-6 text-center"><Link to="/products" className="btn btn-primary">Explore All Products</Link></div></div>;
  }
  const out = p.stock_status === 'out_of_stock';
  if (out || p.order_button_enabled === false)
    return <div className="container-x py-16"><ErrorState message={out ? `Sorry, "${p.name}" is out of stock right now.` : `"${p.name}" cannot be ordered online right now.`} /><div className="mt-6 text-center"><Link to="/products" className="btn btn-primary">Explore All Products</Link></div></div>;

  const offer = p.price?.offerText ?? p.offer_text;
  return ready ? (
    <Checkout header={
      <section className="card mt-6 grid gap-5 p-4 sm:grid-cols-[160px_1fr] sm:p-6" aria-label="Product being ordered">
        <Link to={`/product/${p.slug}`} className="relative mx-auto aspect-square w-40 overflow-hidden rounded-2xl border border-white/10 bg-gradient-to-b from-white/[0.06] to-transparent">
          <ProductImage src={p.main_image_url ?? p.thumb_url} alt={p.name} eager className="h-full w-full p-3" />
        </Link>
        <div className="min-w-0">
          {p.categories && <p className="text-xs font-semibold uppercase tracking-widest text-cyan">{p.categories.name}</p>}
          <h2 className="font-display text-2xl font-bold"><Link to={`/product/${p.slug}`} className="hover:text-cyan">{p.name}</Link></h2>
          {p.short_desc && <p className="mt-1 text-white/60">{p.short_desc}</p>}
          <div className="mt-3 max-w-xs"><PriceRows price={p.price} large /></div>
          {offer && <p className="mt-3 inline-block rounded-full bg-cyan/10 px-3 py-1 text-xs font-semibold text-cyan">Offer: {offer}</p>}
        </div>
      </section>
    } />
  ) : <div className="container-x py-10" aria-busy="true"><div className="h-40 animate-pulse rounded-3xl bg-white/5" /></div>;
}
