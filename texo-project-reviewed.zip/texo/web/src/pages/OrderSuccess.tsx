import { CheckCircle2, MessageCircle } from 'lucide-react';
import { Link, useLocation, useParams } from 'react-router-dom';
import { useDocumentTitle, useSettings } from '../hooks/queries';
import { formatTaka } from '../lib/format';
import { buildWhatsAppMessage, whatsappUrl } from '../lib/whatsapp';
import type { PlacedOrder } from '../types/api';
import type { CheckoutForm } from '../lib/validation';

export function OrderSuccess() {
  useDocumentTitle('Order received');
  const { no } = useParams();
  const st = useLocation().state as { order?: PlacedOrder; customer?: CheckoutForm; channel?: string } | null;
  const { data: s } = useSettings();
  const o = st?.order;
  const wa = o && s?.whatsapp_number
    ? whatsappUrl(s.whatsapp_number, buildWhatsAppMessage({
        orderNo: o.orderNo, lines: o.lines, subtotal: o.subtotal, deliveryCharge: o.deliveryCharge, total: o.total,
        customer: st?.customer ? { ...st.customer } : undefined,
      }))
    : null;
  return (
    <div className="container-x grid min-h-[60vh] place-items-center py-14">
      <div className="card w-full max-w-xl space-y-5 p-7 text-center sm:p-10">
        <CheckCircle2 className="mx-auto h-14 w-14 text-cyan" aria-hidden="true" />
        <h1 className="font-display text-3xl font-bold">Thank you! Order received.</h1>
        <p className="text-white/70">Your order number is <span className="font-display text-xl font-bold text-white">#{no}</span>. We will call you shortly to confirm.</p>
        {o && (
          <ul className="space-y-1 rounded-xl bg-white/[0.04] p-4 text-left text-sm">
            {o.lines.map((l) => <li key={l.productId} className="flex justify-between gap-4"><span>{l.name} × {l.quantity}</span><span>{formatTaka(l.lineTotal)}</span></li>)}
            <li className="flex justify-between border-t border-white/10 pt-2 font-semibold"><span>Total (incl. delivery)</span><span>{formatTaka(o.total)}</span></li>
          </ul>
        )}
        {wa && <a href={wa} target="_blank" rel="noopener noreferrer" className="btn btn-primary w-full"><MessageCircle className="h-4 w-4" /> Send order details on WhatsApp</a>}
        <Link to="/products" className="btn btn-ghost w-full">Continue shopping</Link>
      </div>
    </div>
  );
}
