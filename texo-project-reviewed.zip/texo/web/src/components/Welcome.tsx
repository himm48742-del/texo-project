import { AnimatePresence, motion } from 'framer-motion';
import { Fragment, useEffect, useMemo, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { useSettings } from '../hooks/queries';
import { clampSpeed } from '../lib/heroQueue';
import { exitMs, seeded, splitGraphemes, welcomeMode, welcomeTimeline } from '../lib/welcome';
import type { WelcomeMode } from '../lib/welcome';

const LS = 'texo.welcome.seen', SS = 'texo.welcome.session';
const read = (s: 'local' | 'session', k: string) => { try { return (s === 'local' ? localStorage : sessionStorage).getItem(k) === '1'; } catch { return false; } };
const write = () => { try { localStorage.setItem(LS, '1'); sessionStorage.setItem(SS, '1'); } catch { /* storage blocked: intro simply plays again next time */ } };

function Letters({ text, speed, delay = 0, className = '' }: { text: string; speed: number; delay?: number; className?: string }) {
  const words = text.split(' ');
  let n = 0;
  return (
    <span aria-label={text} className={className}>
      {words.map((w, wi) => (
        <Fragment key={wi}>
          {wi > 0 && ' '}
          <span aria-hidden="true" className="inline-block whitespace-nowrap">
            {splitGraphemes(w).map((g, gi) => (
              <motion.span key={gi} className="inline-block" initial={{ opacity: 0, y: 22, filter: 'blur(10px)' }} animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
                transition={{ duration: 0.6 / speed, delay: (delay + n++ * 0.05) / speed, ease: [0.22, 1, 0.36, 1] }}>{g}</motion.span>
            ))}
          </span>
        </Fragment>
      ))}
    </span>
  );
}

function Particles() {
  const dots = useMemo(() => {
    const r = seeded(42), count = typeof window !== 'undefined' && window.innerWidth < 640 ? 12 : 26;
    return Array.from({ length: count }, () => ({ x: r() * 100, y: r() * 100, s: 1 + r() * 2.5, d: 4 + r() * 5, t: r() * 3, gold: r() > 0.9 }));
  }, []);
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden="true">
      {dots.map((d, i) => (
        <motion.span key={i} className={`absolute rounded-full ${d.gold ? 'bg-gold' : 'bg-cyan'}`} style={{ left: `${d.x}%`, top: `${d.y}%`, width: d.s, height: d.s }}
          animate={{ y: [0, -46, 0], opacity: [0, 0.7, 0] }} transition={{ duration: d.d, delay: d.t, repeat: Infinity, ease: 'easeInOut' }} />
      ))}
    </div>
  );
}

/** Cinematic first-visit intro. Texts and speed come from Admin settings; skippable; respects reduced motion. */
export function Welcome() {
  const { pathname } = useLocation();
  const { data: s, isSuccess, isError } = useSettings();
  const [mode] = useState<WelcomeMode>(() => welcomeMode({
    seenBefore: read('local', LS), seenThisSession: read('session', SS), isHome: pathname === '/',
    reducedMotion: typeof matchMedia !== 'undefined' && matchMedia('(prefers-reduced-motion: reduce)').matches,
  }));
  const [open, setOpen] = useState(mode !== 'skip');
  const [ready, setReady] = useState(false);
  const [step, setStep] = useState(0);
  const speed = clampSpeed(s?.hero_animation_speed);
  const steps = useMemo(() => welcomeTimeline(mode, speed), [mode, speed]);
  const finish = () => { write(); setOpen(false); };

  // Cover the page immediately, but wait (max 1.2 s) for the admin-edited texts before starting.
  useEffect(() => {
    if (!open) return;
    if (isSuccess || isError) { setReady(true); return; }
    const t = setTimeout(() => setReady(true), 1200);
    return () => clearTimeout(t);
  }, [open, isSuccess, isError]);
  useEffect(() => {
    if (!open || !ready) return;
    if (s?.welcome_enabled === false || !steps[step]) { finish(); return; }
    const t = setTimeout(() => setStep((i) => i + 1), steps[step].ms);
    return () => clearTimeout(t);
  }, [open, ready, step, steps, s?.welcome_enabled]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const k = (e: KeyboardEvent) => e.key === 'Escape' && finish();
    document.addEventListener('keydown', k);
    return () => { document.body.style.overflow = prev; document.removeEventListener('keydown', k); };
  }, [open]); // eslint-disable-line react-hooks/exhaustive-deps

  const id = ready ? steps[step]?.id : undefined;
  const line1 = String(s?.welcome_line1 ?? 'স্বাগতম TEXO-তে');
  const line2 = String(s?.welcome_line2 ?? 'আপনার Tech Experience শুরু হোক।');
  const brand = String(s?.brand_name ?? 'TEXO'), tagline = String(s?.tagline ?? 'YOUR TECH.');

  return (
    <AnimatePresence>
      {open && (
        <motion.div role="dialog" aria-modal="true" aria-label="Welcome to TEXO" className="fixed inset-0 z-[100] grid place-items-center overflow-hidden bg-ink"
          exit={{ opacity: 0, scale: 1.08, filter: 'blur(12px)' }} transition={{ duration: exitMs(speed) / 1000, ease: [0.22, 1, 0.36, 1] }}>
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(0,102,255,.18),transparent_60%)]" aria-hidden="true" />
          <Particles />
          {id && <motion.div key={`streak-${id}`} aria-hidden="true" className="absolute h-px w-[70%] -rotate-[8deg] bg-gradient-to-r from-transparent via-cyan to-transparent"
            initial={{ x: '-120%', opacity: 0 }} animate={{ x: '120%', opacity: [0, 1, 0] }} transition={{ duration: 1.4 / speed, ease: 'easeInOut' }} />}
          <div className="relative px-6 text-center" aria-live="polite">
            <AnimatePresence mode="wait">
              {id === 'line1' && <motion.p key="l1" exit={{ opacity: 0, y: -14, filter: 'blur(8px)' }} transition={{ duration: 0.4 }} className="font-bn text-4xl font-semibold leading-snug sm:text-6xl"><Letters text={line1} speed={speed} /></motion.p>}
              {id === 'line2' && <motion.p key="l2" exit={{ opacity: 0, y: -14, filter: 'blur(8px)' }} transition={{ duration: 0.4 }} className="mx-auto max-w-3xl font-bn text-3xl font-medium leading-snug text-white/90 sm:text-5xl"><Letters text={line2} speed={speed} /></motion.p>}
              {id === 'logo' && (
                <motion.div key="logo" className="relative grid place-items-center" exit={{ opacity: 0, scale: 0.9 }} transition={{ duration: 0.35 }}>
                  <motion.div aria-hidden="true" className="absolute h-44 w-44 rounded-full bg-cyan/25 blur-3xl" initial={{ scale: 0.4, opacity: 0 }} animate={{ scale: 1.3, opacity: 1 }} transition={{ duration: 1.1 / speed }} />
                  <motion.svg viewBox="0 0 64 64" className="relative h-28 w-28" initial={{ scale: 0.7 }} animate={{ scale: 1 }} transition={{ duration: 0.9 / speed, ease: [0.22, 1, 0.36, 1] }} aria-hidden="true">
                    <motion.rect x="2" y="2" width="60" height="60" rx="16" fill="none" stroke="#00E5FF" strokeWidth="1.5" initial={{ pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ duration: 0.9 / speed }} />
                    <motion.path d="M14 18h36v7H36v23h-8V25H14z" fill="#00E5FF" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.4 / speed, duration: 0.5 / speed }} />
                  </motion.svg>
                </motion.div>
              )}
              {id === 'brand' && (
                <motion.div key="brand" exit={{ opacity: 0 }} transition={{ duration: 0.3 }}>
                  <motion.h1 className="font-display text-6xl font-bold sm:text-8xl" initial={{ letterSpacing: '0.7em', opacity: 0 }} animate={{ letterSpacing: '0.22em', opacity: 1 }} transition={{ duration: 1.2 / speed, ease: [0.22, 1, 0.36, 1] }}>{brand}</motion.h1>
                  <motion.div aria-hidden="true" className="mx-auto mt-5 h-px bg-gold" initial={{ width: 0 }} animate={{ width: 120 }} transition={{ delay: 0.5 / speed, duration: 0.7 / speed }} />
                  <motion.p className="mt-4 font-display text-lg tracking-[0.5em] text-cyan sm:text-xl" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.7 / speed, duration: 0.6 / speed }}>{tagline}</motion.p>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
          <button onClick={finish} className="absolute bottom-6 right-6 min-h-[44px] rounded-full border border-white/20 px-5 text-sm text-white/70 backdrop-blur hover:border-white/50 hover:text-white" autoFocus>Skip</button>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
