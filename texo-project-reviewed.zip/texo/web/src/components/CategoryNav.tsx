import { Flame, LayoutGrid, Sparkles, Star } from 'lucide-react';
import { Link, useSearchParams } from 'react-router-dom';
import { useCategories } from '../hooks/queries';

const VIEWS = [
  { label: 'All Products', to: '/products', key: '', icon: LayoutGrid },
  { label: 'New Arrivals', to: '/products?view=new', key: 'view:new', icon: Sparkles },
  { label: 'Featured', to: '/products?view=featured', key: 'view:featured', icon: Star },
  { label: 'Offers', to: '/products?view=offers', key: 'view:offers', icon: Flame },
];

/** Categories come from the API (managed in Admin). Used by the desktop sidebar and the mobile drawer. */
export function CategoryNav({ onNavigate }: { onNavigate?: () => void }) {
  const [sp] = useSearchParams();
  const { data: cats, isLoading, isError, refetch } = useCategories();
  const current = sp.get('category') ? `cat:${sp.get('category')}` : sp.get('view') ? `view:${sp.get('view')}` : '';
  const item = (key: string, to: string, label: string, Icon?: typeof Flame, img?: string | null) => {
    const active = current === key;
    return (
      <li key={key || 'all'}>
        <Link to={to} onClick={onNavigate} aria-current={active ? 'page' : undefined}
          className={`flex min-h-[44px] items-center gap-3 rounded-xl px-3 text-sm font-medium transition ${active ? 'bg-cyan/10 text-cyan' : 'text-white/70 hover:bg-white/5 hover:text-white'}`}>
          {img ? <img src={img} alt="" className="h-5 w-5 rounded object-cover" loading="lazy" /> : Icon ? <Icon className="h-[18px] w-[18px]" aria-hidden="true" /> : <span className="h-1.5 w-1.5 rounded-full bg-current opacity-60" />}
          {label}
        </Link>
      </li>
    );
  };
  return (
    <nav aria-label="Product categories">
      <ul className="space-y-1">{VIEWS.map((v) => item(v.key, v.to, v.label, v.icon))}</ul>
      <p className="mb-2 mt-6 px-3 text-[11px] font-semibold uppercase tracking-widest text-white/35">Categories</p>
      {isLoading && <div className="space-y-2" aria-busy="true">{[0, 1, 2, 3, 4].map((i) => <div key={i} className="mx-3 h-4 animate-pulse rounded bg-white/10" />)}</div>}
      {isError && <button onClick={() => refetch()} className="px-3 text-sm text-gold underline">Could not load categories. Retry</button>}
      <ul className="space-y-1">{cats?.map((c) => item(`cat:${c.slug}`, `/products?category=${c.slug}`, c.name, undefined, c.icon_url))}</ul>
    </nav>
  );
}
