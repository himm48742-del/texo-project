import { motion, useMotionValue, useSpring, useTransform } from 'framer-motion';
import { ProductImage } from './ProductImage';

/** Fake 3D for a plain product photo: floating, pointer/touch tilt, glow and a floor shadow. */
export function CardImage({ src, alt, delay = 0 }: { src?: string | null; alt: string; delay?: number }) {
  const mx = useMotionValue(0), my = useMotionValue(0);
  const sx = useSpring(mx, { stiffness: 140, damping: 16 }), sy = useSpring(my, { stiffness: 140, damping: 16 });
  const rotY = useTransform(sx, [-1, 1], [-16, 16]);
  const rotX = useTransform(sy, [-1, 1], [14, -14]);
  return (
    <div className="absolute inset-0 grid place-items-center [perspective:700px]"
      onPointerMove={(e) => { const r = e.currentTarget.getBoundingClientRect(); mx.set(((e.clientX - r.left) / r.width - 0.5) * 2); my.set(((e.clientY - r.top) / r.height - 0.5) * 2); }}
      onPointerLeave={() => { mx.set(0); my.set(0); }}>
      <div className="absolute h-[62%] w-[62%] rounded-full bg-gradient-to-br from-cyan/15 to-electric/20 blur-2xl" aria-hidden="true" />
      <motion.div style={{ rotateX: rotX, rotateY: rotY, transformStyle: 'preserve-3d' }} className="relative h-[78%] w-[78%]">
        <div className="card-float h-full w-full" style={{ animationDelay: `${-delay}s` }}>
          <ProductImage src={src} alt={alt} className="h-full w-full drop-shadow-[0_18px_18px_rgba(0,0,0,.55)]" />
        </div>
      </motion.div>
      <div className="card-shadow absolute bottom-[7%] h-3 w-[46%] rounded-full bg-black/70 blur-md" style={{ animationDelay: `${-delay}s` }} aria-hidden="true" />
    </div>
  );
}
