import { Link } from 'react-router-dom';
import { useSettings } from '../hooks/queries';

export function Footer() {
  const { data: s } = useSettings();
  return (
    <footer className="mt-24 border-t border-white/10 bg-panel/50">
      <div className="container-x grid gap-10 py-12 md:grid-cols-3">
        <div>
          <p className="font-display text-2xl font-bold tracking-[0.18em]">{s?.brand_name ?? 'TEXO'}</p>
          <p className="mt-1 text-cyan">{s?.tagline ?? 'YOUR TECH.'}</p>
          <p className="mt-3 max-w-xs text-sm text-white/50">Technology Extra Experience</p>
        </div>
        <nav aria-label="Footer" className="grid grid-cols-2 gap-2 text-sm text-white/65">
          {[['Products', '/products'], ['Offers', '/offers'], ['Tech News', '/news'], ['About', '/about'], ['Contact', '/contact']].map(([l, to]) => <Link key={to} to={to} className="py-1 hover:text-cyan">{l}</Link>)}
        </nav>
        <div className="text-sm text-white/65">
          {s?.business_phone && <p>Call: <a className="text-white hover:text-cyan" href={`tel:${s.business_phone}`}>{s.business_phone}</a></p>}
        </div>
      </div>
      <p className="border-t border-white/10 py-5 text-center text-xs text-white/40">{s?.footer_text ?? '© TEXO. Your Tech.'}</p>
    </footer>
  );
}
