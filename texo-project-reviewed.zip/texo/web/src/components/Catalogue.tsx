import { AnimatePresence, motion } from 'framer-motion';
import { SlidersHorizontal } from 'lucide-react';
import { useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useCategories, useProducts, useSearch } from '../hooks/queries';
import { CategoryNav } from './CategoryNav';
import { Drawer } from './Drawer';
import { ProductCard } from './ProductCard';
import { EmptyState, ErrorState, GridSkeleton } from './States';

const VIEW_TITLES: Record<string, string> = { new: 'New Arrivals', featured: 'Featured', offers: 'Offers' };

/** Product listing driven by URL (?category= ?view= ?q=) so filters are shareable and back-button friendly. */
export function Catalogue() {
  const [sp] = useSearchParams();
  const category = sp.get('category') ?? undefined;
  const view = sp.get('view') ?? undefined;
  const q = (sp.get('q') ?? '').trim();
  const [drawer, setDrawer] = useState(false);
  const { data: cats } = useCategories();
  const list = useProducts({ category, view });
  const found = useSearch(q, 30);
  const searching = q.length >= 2;

  const title = searching ? `Results for “${q}”` : category ? cats?.find((c) => c.slug === category)?.name ?? 'Products' : view ? VIEW_TITLES[view] ?? 'Products' : 'All Products';
  const products = searching ? found.data : list.data?.pages.flatMap((p) => p.data);
  const loading = searching ? found.isLoading : list.isLoading;
  const error = searching ? found.isError : list.isError;
  const refetch = searching ? found.refetch : list.refetch;
  const key = `${category ?? ''}|${view ?? ''}|${q}`;

  return (
    <section aria-labelledby="catalogue-title">
      <div className="mb-5 flex items-center justify-between gap-3">
        <h2 id="catalogue-title" className="font-display text-2xl font-bold sm:text-3xl">{title}</h2>
        <button className="btn btn-ghost min-h-[44px] px-4 lg:hidden" onClick={() => setDrawer(true)}><SlidersHorizontal className="h-4 w-4" /> Categories</button>
      </div>
      <AnimatePresence mode="wait">
        <motion.div key={key} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} transition={{ duration: 0.25 }}>
          {loading ? <GridSkeleton /> : error ? <ErrorState message="We could not load the products." onRetry={() => refetch()} /> :
            !products?.length ? <EmptyState title={searching ? `No products found for “${q}”.` : undefined} /> : (
              <>
                <div className="grid grid-cols-2 gap-3 sm:gap-5 md:grid-cols-3 xl:grid-cols-4">
                  {products.map((p, i) => <ProductCard key={p.id} p={p} index={i} />)}
                </div>
                {!searching && list.hasNextPage && (
                  <div className="mt-10 text-center">
                    <button className="btn btn-ghost" disabled={list.isFetchingNextPage} onClick={() => list.fetchNextPage()}>{list.isFetchingNextPage ? 'Loading…' : 'Load more'}</button>
                  </div>
                )}
              </>
            )}
        </motion.div>
      </AnimatePresence>
      <Drawer open={drawer} onClose={() => setDrawer(false)} title="Categories"><CategoryNav onNavigate={() => setDrawer(false)} /></Drawer>
    </section>
  );
}
