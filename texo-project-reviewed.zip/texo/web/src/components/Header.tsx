import { Menu, Search, ShoppingBag, X } from 'lucide-react';
import { useState } from 'react';
import { Link, NavLink } from 'react-router-dom';
import { useCart } from '../hooks/cart';
import { useSettings } from '../hooks/queries';
import { Drawer } from './Drawer';
import { SearchBox } from './SearchBox';

const LINKS = [['Home', '/'], ['Products', '/products'], ['Offers', '/offers'], ['Tech News', '/news'], ['About', '/about'], ['Contact', '/contact']] as const;

export function Logo() {
  const { data } = useSettings();
  return (
    <Link to="/" aria-label={`${data?.brand_name ?? 'TEXO'} home`} className="flex items-baseline gap-2">
      <span className="font-display text-2xl font-bold tracking-[0.18em]">{data?.brand_name ?? 'TEXO'}</span>
      <span className="hidden h-1.5 w-1.5 rounded-full bg-cyan sm:block" aria-hidden="true" />
    </Link>
  );
}

export function Header() {
  const [menu, setMenu] = useState(false);
  const [search, setSearch] = useState(false);
  const { count } = useCart();
  return (
    <header className="sticky top-0 z-40 border-b border-white/10 bg-ink/80 backdrop-blur-xl">
      <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-2 focus:rounded focus:bg-cyan focus:px-3 focus:py-2 focus:text-ink">Skip to content</a>
      <div className="container-x flex h-16 items-center gap-4 lg:gap-8">
        <Logo />
        <nav aria-label="Main" className="ml-4 hidden items-center gap-1 lg:flex">
          {LINKS.map(([l, to]) => (
            <NavLink key={to} to={to} end={to === '/'} className={({ isActive }) => `rounded-full px-3.5 py-2 text-sm font-medium transition ${isActive ? 'text-cyan' : 'text-white/65 hover:text-white'}`}>{l}</NavLink>
          ))}
        </nav>
        <div className="ml-auto hidden w-full max-w-sm lg:block"><SearchBox /></div>
        <div className="ml-auto flex items-center gap-1 lg:ml-0">
          <button className="grid h-11 w-11 place-items-center rounded-full hover:bg-white/10 lg:hidden" aria-label={search ? 'Close search' : 'Search'} onClick={() => setSearch((s) => !s)}>
            {search ? <X className="h-5 w-5" /> : <Search className="h-5 w-5" />}
          </button>
          <Link to="/checkout" className="relative grid h-11 w-11 place-items-center rounded-full hover:bg-white/10" aria-label={`Your order, ${count} item${count === 1 ? '' : 's'}`}>
            <ShoppingBag className="h-5 w-5" />
            {count > 0 && <span className="absolute right-0.5 top-0.5 grid h-5 min-w-5 place-items-center rounded-full bg-cyan px-1 text-[11px] font-bold text-ink">{count}</span>}
          </Link>
          <button className="grid h-11 w-11 place-items-center rounded-full hover:bg-white/10 lg:hidden" aria-label="Open menu" onClick={() => setMenu(true)}><Menu className="h-5 w-5" /></button>
        </div>
      </div>
      {search && <div className="container-x pb-3 lg:hidden"><SearchBox autoFocus onDone={() => setSearch(false)} /></div>}
      <Drawer open={menu} onClose={() => setMenu(false)} title="Menu" side="right">
        <nav aria-label="Mobile">
          <ul className="space-y-1">{LINKS.map(([l, to]) => (
            <li key={to}><NavLink to={to} end={to === '/'} onClick={() => setMenu(false)} className={({ isActive }) => `flex min-h-[52px] items-center rounded-xl px-4 text-lg font-medium ${isActive ? 'bg-cyan/10 text-cyan' : 'text-white/80 hover:bg-white/5'}`}>{l}</NavLink></li>
          ))}</ul>
        </nav>
      </Drawer>
    </header>
  );
}
