import { Float, ContactShadows, Environment, Lightformer, useGLTF } from '@react-three/drei';
import { Canvas, useFrame } from '@react-three/fiber';
import { useMemo, useRef } from 'react';
import type { MutableRefObject } from 'react';
import { Box3, Group, Vector3 } from 'three';

export const preloadModel = (url: string) => useGLTF.preload(url);

interface Drag { active: boolean; x: number; pending: number; inertia: number; total: number }

function Model({ url, speed, drag }: { url: string; speed: number; drag: MutableRefObject<Drag> }) {
  const { scene } = useGLTF(url);
  const spin = useRef<Group>(null);
  // Centre and scale any model to the same visual size, so admins can upload models of any scale.
  const fitted = useMemo(() => {
    const clone = scene.clone(true);
    const box = new Box3().setFromObject(clone);
    const size = box.getSize(new Vector3());
    const centre = box.getCenter(new Vector3());
    clone.position.sub(centre);
    const wrap = new Group();
    wrap.add(clone);
    wrap.scale.setScalar(2.2 / Math.max(size.x, size.y, size.z, 0.0001));
    return wrap;
  }, [scene]);
  useFrame((_, dt) => {
    const g = spin.current; const d = drag.current;
    if (!g) return;
    if (d.active) { g.rotation.y += d.pending; d.pending = 0; }
    else { g.rotation.y += dt * 0.7 * speed + d.inertia; d.inertia *= 0.93; }
  });
  return <group ref={spin}><primitive object={fitted} /></group>;
}

/** Real 3D viewer (.glb/.gltf): studio lighting, soft shadow, floating motion, drag-to-rotate. Lazy-loaded. */
export default function ModelStage({ url, speed, active, movedRef }: { url: string; speed: number; active: boolean; movedRef: MutableRefObject<boolean> }) {
  const drag = useRef<Drag>({ active: false, x: 0, pending: 0, inertia: 0, total: 0 });
  const d = drag.current;
  return (
    <div className="absolute inset-0 cursor-grab touch-pan-y active:cursor-grabbing" role="img" aria-label="Interactive 3D product view. Drag to rotate."
      onPointerDown={(e) => { d.active = true; d.x = e.clientX; d.total = 0; movedRef.current = false; (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId); }}
      onPointerMove={(e) => { if (!d.active) return; const dx = e.clientX - d.x; d.x = e.clientX; d.total += Math.abs(dx); d.pending += dx * 0.012; d.inertia = dx * 0.006; if (d.total > 6) movedRef.current = true; }}
      onPointerUp={() => { d.active = false; }} onPointerCancel={() => { d.active = false; }}>
      <Canvas dpr={[1, 1.75]} camera={{ position: [0, 0.4, 4.2], fov: 32 }} frameloop={active ? 'always' : 'demand'}
        gl={{ alpha: true, antialias: true, powerPreference: 'high-performance' }}>
        <ambientLight intensity={0.35} />
        <directionalLight position={[3, 5, 4]} intensity={1.3} />
        {/* Procedural studio lighting: no HDR download needed, works offline and under strict CSP. */}
        <Environment resolution={256} frames={1}>
          <Lightformer form="rect" intensity={2.2} position={[0, 5, -5]} scale={[10, 3, 1]} />
          <Lightformer form="rect" intensity={1.4} position={[-5, 1, 2]} scale={[3, 6, 1]} color="#00E5FF" />
          <Lightformer form="rect" intensity={1.2} position={[5, 1, 2]} scale={[3, 6, 1]} color="#0066FF" />
        </Environment>
        <Float speed={1.6 * speed} rotationIntensity={0.12} floatIntensity={0.6}>
          <Model url={url} speed={speed} drag={drag} />
        </Float>
        <ContactShadows position={[0, -1.3, 0]} opacity={0.55} scale={7} blur={2.6} far={3} />
      </Canvas>
    </div>
  );
}
