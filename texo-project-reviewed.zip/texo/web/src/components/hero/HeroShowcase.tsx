import { AnimatePresence, motion, useReducedMotion } from 'framer-motion';
import { ChevronLeft, ChevronRight, Pause, Play } from 'lucide-react';
import { lazy, Suspense, useEffect, useRef, useState } from 'react';
import type { RefObject } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useSettings } from '../../hooks/queries';
import { useHeroQueue } from '../../hooks/useHeroQueue';
import { clampSeconds, clampSpeed } from '../../lib/heroQueue';
import { canWebGL } from '../../lib/preload';
import { PriceTag } from '../PriceTag';
import { ImageStage } from './ImageStage';
import { SoftBoundary } from './SoftBoundary';

const ModelStage = lazy(() => import('./ModelStage')); // three.js is downloaded only when needed

function useInView(ref: RefObject<Element>) {
  const [v, setV] = useState(true);
  useEffect(() => {
    if (!ref.current || typeof IntersectionObserver === 'undefined') return;
    const o = new IntersectionObserver(([e]) => setV(e.isIntersecting), { threshold: 0.15 });
    o.observe(ref.current);
    return () => o.disconnect();
  }, [ref]);
  return v;
}
function useTabVisible() {
  const [v, setV] = useState(true);
  useEffect(() => {
    const f = () => setV(document.visibilityState === 'visible');
    document.addEventListener('visibilitychange', f);
    return () => document.removeEventListener('visibilitychange', f);
  }, []);
  return v;
}

export function HeroShowcase() {
  const { data: s } = useSettings();
  const reduced = !!useReducedMotion();
  const speed = clampSpeed(s?.hero_animation_speed);
  const rotateMs = clampSeconds(s?.hero_rotation_seconds) * 1000;
  const root = useRef<HTMLElement>(null);
  const inView = useInView(root);
  const visible = useTabVisible();
  const [userPaused, setUserPaused] = useState(false);
  const [hover, setHover] = useState(false);
  const [focus, setFocus] = useState(false);
  // No auto-rotation when the admin turned autoplay off, or the visitor prefers reduced motion (they can still press play).
  const autoplay = s?.hero_autoplay !== false;
  useEffect(() => { setUserPaused(reduced || !autoplay); }, [reduced, autoplay]);
  const paused = userPaused || hover || focus || !inView || !visible;
  const q = useHeroQueue({ rotateMs, paused });
  const nav = useNavigate();
  const moved = useRef(false);
  const p = q.current;
  const d = 0.9 / speed;
  const out = p?.stock_status === 'out_of_stock';
  const use3D = !!p?.model && !reduced && canWebGL();
  const still = <ImageStage p={p!} speed={speed} animate={!reduced && inView && visible} />;

  return (
    <section ref={root} aria-roledescription="carousel" aria-label="Featured products" className="relative"
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)} onFocus={() => setFocus(true)} onBlur={() => setFocus(false)}
      onKeyDown={(e) => { if (e.key === 'ArrowRight') q.next(); if (e.key === 'ArrowLeft') q.prev(); }}>
      {/* Fixed-height stage: products swap inside it, so the page never jumps. */}
      <div className="relative h-[320px] overflow-hidden rounded-3xl sm:h-[400px] lg:h-[440px]">
        <div className="absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-white/[0.04] to-transparent" aria-hidden="true" />
        {q.status === 'loading' && <div className="absolute inset-0 grid place-items-center" aria-busy="true"><div className="h-52 w-52 animate-pulse rounded-full bg-white/5" /></div>}
        {q.status === 'error' && <div className="absolute inset-0 grid place-items-center text-center" role="alert"><div><p className="text-white/60">Featured products are unavailable right now.</p><button className="btn btn-ghost mt-3" onClick={() => q.retry()}>Try again</button></div></div>}
        {q.status === 'empty' && <div className="absolute inset-0 grid place-items-center text-white/50">New products are coming soon.</div>}
        <AnimatePresence initial={false}>
          {p && (
            <motion.div key={p.id} className="absolute inset-0 cursor-pointer [perspective:1200px]"
              initial={reduced ? { opacity: 0 } : { opacity: 0, scale: 0.82, rotateY: -40, x: 70, filter: 'blur(14px)' }}
              animate={{ opacity: 1, scale: 1, rotateY: 0, x: 0, filter: 'blur(0px)' }}
              exit={reduced ? { opacity: 0 } : { opacity: 0, scale: 1.15, rotateY: 40, x: -70, filter: 'blur(14px)' }}
              transition={{ duration: d, ease: [0.22, 1, 0.36, 1] }}
              onClick={() => { if (!moved.current) nav(`/product/${p.slug}`); moved.current = false; }}>
              {use3D ? (
                <SoftBoundary fallback={still}>
                  <Suspense fallback={still}><ModelStage url={p.model!.model_url} speed={speed} active={inView && visible} movedRef={moved} /></Suspense>
                </SoftBoundary>
              ) : still}
            </motion.div>
          )}
        </AnimatePresence>
        {p && q.items.length > 1 && (
          <div className="absolute inset-x-3 bottom-3 flex items-center justify-between">
            <div className="flex items-center gap-1">
              <button className="grid h-11 w-11 place-items-center rounded-full bg-black/40 backdrop-blur hover:bg-black/60" aria-label="Previous product" onClick={q.prev}><ChevronLeft className="h-5 w-5" /></button>
              <button className="grid h-11 w-11 place-items-center rounded-full bg-black/40 backdrop-blur hover:bg-black/60" aria-label="Next product" onClick={q.next}><ChevronRight className="h-5 w-5" /></button>
            </div>
            <div className="flex items-center gap-2">
              <span className="font-display text-sm tabular-nums text-white/60" aria-hidden="true">{String(q.index + 1).padStart(2, '0')} / {q.total}</span>
              <button className="grid h-11 w-11 place-items-center rounded-full bg-black/40 backdrop-blur hover:bg-black/60" aria-label={userPaused ? 'Play automatic rotation' : 'Pause automatic rotation'} onClick={() => setUserPaused((x) => !x)}>
                {userPaused ? <Play className="h-4 w-4" /> : <Pause className="h-4 w-4" />}
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Time-to-next-product indicator */}
      <div className="mx-1 mt-2 h-0.5 overflow-hidden rounded bg-white/10" aria-hidden="true">
        {p && q.items.length > 1 && !userPaused && (
          <div key={`${p.id}-${rotateMs}`} className="hero-progress h-full bg-gradient-to-r from-cyan to-electric" style={{ animationDuration: `${rotateMs}ms`, animationPlayState: paused ? 'paused' : 'running' }} />
        )}
      </div>

      {/* Product info: fixed minimum height so text changes never shift the layout */}
      <div className="min-h-[188px] pt-5" aria-live={userPaused ? 'polite' : 'off'}>
        <AnimatePresence mode="wait" initial={false}>
          {p && (
            <motion.div key={p.id} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.28 / speed }}>
              <Link to={`/product/${p.slug}`} className="font-display text-2xl font-bold hover:text-cyan sm:text-3xl">{p.name}</Link>
              {p.short_desc && <p className="mt-1 text-white/60">{p.short_desc}</p>}
              <div className="mt-3"><PriceTag price={p.price} size="lg" /></div>
              <div className="mt-4 flex flex-wrap gap-3">
                <Link to={out ? `/product/${p.slug}` : `/order/${p.slug}`} className="btn btn-primary px-8">{out ? 'VIEW PRODUCT' : 'ORDER NOW →'}</Link>
                {!out && <Link to={`/product/${p.slug}`} className="btn btn-ghost">View product</Link>}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </section>
  );
}
