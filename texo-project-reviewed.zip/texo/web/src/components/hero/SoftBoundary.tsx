import { Component } from 'react';
import type { ReactNode } from 'react';

/** If the 3D viewer fails (bad model, no GPU), quietly fall back to the image presentation. */
export class SoftBoundary extends Component<{ fallback: ReactNode; children: ReactNode }, { failed: boolean }> {
  state = { failed: false };
  static getDerivedStateFromError() { return { failed: true }; }
  componentDidCatch(e: unknown) { console.warn('3D viewer unavailable, using image mode.', e); }
  render() { return this.state.failed ? this.props.fallback : this.props.children; }
}
