import { motion, useMotionValue, useSpring, useTransform } from 'framer-motion';
import type { HeroProduct } from '../../types/api';
import { ProductImage } from '../ProductImage';

/** "3D-style" presentation for ordinary product photos: depth, floating, pointer parallax, glow, shadow. */
export function ImageStage({ p, speed, animate }: { p: HeroProduct; speed: number; animate: boolean }) {
  const mx = useMotionValue(0), my = useMotionValue(0);
  const sx = useSpring(mx, { stiffness: 90, damping: 16 }), sy = useSpring(my, { stiffness: 90, damping: 16 });
  const rotY = useTransform(sx, [-1, 1], [-16, 16]);
  const rotX = useTransform(sy, [-1, 1], [10, -10]);
  const glowX = useTransform(sx, [-1, 1], [-24, 24]);
  const sway = animate ? { y: [0, -14, 0], rotateY: [-9, 9, -9], rotateZ: [-1.2, 1.2, -1.2] } : undefined;
  const loop = { duration: 7 / speed, repeat: Infinity, ease: 'easeInOut' as const };
  const src = p.main_image_url ?? p.thumb_url;
  return (
    <div className="absolute inset-0 grid place-items-center [perspective:1100px]"
      onPointerMove={(e) => { const r = e.currentTarget.getBoundingClientRect(); mx.set(((e.clientX - r.left) / r.width - 0.5) * 2); my.set(((e.clientY - r.top) / r.height - 0.5) * 2); }}
      onPointerLeave={() => { mx.set(0); my.set(0); }}>
      <motion.div style={{ x: glowX }} className="absolute h-[68%] w-[68%] rounded-full bg-gradient-to-br from-cyan/25 to-electric/30 blur-3xl" aria-hidden="true" />
      <motion.div style={{ rotateX: rotX, rotateY: rotY, transformStyle: 'preserve-3d' }} className="relative grid place-items-center">
        <motion.div animate={sway} transition={loop} style={{ transformStyle: 'preserve-3d' }}>
          {src ? (
            <ProductImage src={src} alt={p.name} eager className="h-[250px] w-[250px] drop-shadow-[0_30px_35px_rgba(0,0,0,.55)] sm:h-[340px] sm:w-[340px] lg:h-[380px] lg:w-[380px]" />
          ) : (
            // No photo uploaded yet: a premium device-style placeholder so the hero never looks empty.
            <div role="img" aria-label={p.name} className="relative grid h-[230px] w-[230px] place-items-center rounded-[2.2rem] border border-white/15 bg-gradient-to-br from-white/15 via-white/[0.04] to-cyan/10 shadow-[0_30px_60px_-20px_rgba(0,229,255,.35)] sm:h-[300px] sm:w-[300px]">
              <svg viewBox="0 0 64 64" className="h-1/3 w-1/3" aria-hidden="true"><path d="M14 18h36v7H36v23h-8V25H14z" fill="#00E5FF" /></svg>
              <span className="absolute bottom-5 px-4 text-center font-display text-xs font-semibold uppercase tracking-[0.25em] text-white/50">{p.name}</span>
            </div>
          )}
        </motion.div>
      </motion.div>
      <motion.div aria-hidden="true" animate={animate ? { scaleX: [1, 0.82, 1], opacity: [0.55, 0.35, 0.55] } : undefined} transition={loop}
        className="absolute bottom-[7%] h-6 w-48 rounded-full bg-black/70 blur-xl sm:w-60" />
    </div>
  );
}
