import { Outlet, useLocation } from 'react-router-dom';
import { useEffect } from 'react';
import { useSettings } from '../hooks/queries';
import { setCurrencySymbol } from '../lib/format';
import { Footer } from './Footer';
import { Header } from './Header';

export function Layout() {
  const { pathname } = useLocation();
  const { data: settings } = useSettings();
  setCurrencySymbol(settings?.currency_symbol); // before children render, so every price uses the admin-chosen symbol
  useEffect(() => { window.scrollTo({ top: 0 }); }, [pathname]);
  return (
    <>
      <Header />
      <main id="main" tabIndex={-1} className="min-h-[70vh] outline-none"><Outlet /></main>
      <Footer />
    </>
  );
}
