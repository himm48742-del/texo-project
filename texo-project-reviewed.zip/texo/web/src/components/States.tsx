import { AlertTriangle, PackageSearch } from 'lucide-react';
import { Link } from 'react-router-dom';

export const GridSkeleton = ({ n = 8 }: { n?: number }) => (
  <div className="grid grid-cols-2 gap-3 sm:gap-5 md:grid-cols-3 xl:grid-cols-4" aria-busy="true" aria-label="Loading products">
    {Array.from({ length: n }).map((_, i) => (
      <div key={i} className="card animate-pulse overflow-hidden"><div className="aspect-square bg-white/5" /><div className="space-y-2 p-4"><div className="h-3 w-1/3 rounded bg-white/10" /><div className="h-4 w-3/4 rounded bg-white/10" /><div className="h-5 w-1/2 rounded bg-white/10" /></div></div>
    ))}
  </div>
);

export function ErrorState({ message, onRetry }: { message?: string; onRetry?: () => void }) {
  return (
    <div role="alert" className="card flex flex-col items-center gap-3 px-6 py-14 text-center">
      <AlertTriangle className="h-9 w-9 text-gold" aria-hidden="true" />
      <p className="max-w-md text-white/80">{message ?? 'Something went wrong. Please try again.'}</p>
      {onRetry && <button className="btn btn-ghost" onClick={onRetry}>Try again</button>}
    </div>
  );
}

export function EmptyState({ title = 'No products available in this category.', cta = true }: { title?: string; cta?: boolean }) {
  return (
    <div className="card flex flex-col items-center gap-4 px-6 py-16 text-center">
      <PackageSearch className="h-10 w-10 text-cyan/70" aria-hidden="true" />
      <p className="text-lg font-medium">{title}</p>
      {cta && <Link to="/products" className="btn btn-primary">Explore All Products</Link>}
    </div>
  );
}
