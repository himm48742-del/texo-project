import { useState } from 'react';

/** Image with lazy loading and a branded placeholder when the file is missing or broken. */
export function ProductImage({ src, alt, eager = false, className = '' }: { src?: string | null; alt: string; eager?: boolean; className?: string }) {
  const [failed, setFailed] = useState(false);
  if (!src || failed) {
    return (
      <div role="img" aria-label={alt} className={`flex items-center justify-center bg-gradient-to-br from-white/[0.06] to-white/[0.01] ${className}`}>
        <svg viewBox="0 0 64 64" className="h-1/4 w-1/4 opacity-40" aria-hidden="true"><path d="M14 18h36v7H36v23h-8V25H14z" fill="#00E5FF" /></svg>
      </div>
    );
  }
  return <img src={src} alt={alt} loading={eager ? 'eager' : 'lazy'} decoding="async" onError={() => setFailed(true)} className={`object-contain ${className}`} />;
}
