import { motion, useReducedMotion } from 'framer-motion';
import { Box } from 'lucide-react';
import { lazy, Suspense, useEffect, useRef, useSyncExternalStore } from 'react';
import { Link } from 'react-router-dom';
import { getActive, setActive, subscribe } from '../lib/activeModel';
import { canWebGL } from '../lib/preload';
import type { ProductSummary } from '../types/api';
import { CardImage } from './CardImage';
import { SoftBoundary } from './hero/SoftBoundary';
import { PriceRows } from './PriceTag';

const ModelStage = lazy(() => import('./hero/ModelStage')); // three.js is only downloaded when a 3D card is activated

/**
 * Hybrid 3D card:
 *  - product has a .glb/.gltf  -> "3D" chip; hover (mouse) or tap the chip starts the REAL 3D viewer (one card at a time)
 *  - otherwise / before that   -> floating + tilting fake-3D photo
 */
export function ProductCard({ p, index = 0 }: { p: ProductSummary; index?: number }) {
  const reduced = !!useReducedMotion();
  const activeId = useSyncExternalStore(subscribe, getActive, () => null);
  const live = activeId === p.id;
  const can3D = !!p.model && !reduced && canWebGL();
  const timer = useRef<ReturnType<typeof setTimeout>>();
  const moved = useRef(false);
  useEffect(() => () => { clearTimeout(timer.current); if (getActive() === p.id) setActive(null); }, [p.id]);

  const out = p.stock_status === 'out_of_stock';
  const orderable = !out && p.order_button_enabled !== false;
  const label = out ? 'Out of stock' : p.order_button_enabled === false ? 'Unavailable' : p.order_button_text || 'ORDER NOW';
  const photo = p.main_image_url ?? p.thumb_url;
  const fake = <CardImage src={photo} alt={p.name} delay={(index % 6) * 0.9} />;

  return (
    <motion.article
      initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4, delay: Math.min(index, 8) * 0.04, ease: [0.22, 1, 0.36, 1] }}
      className="group card flex flex-col overflow-hidden transition duration-300 hover:-translate-y-1 hover:border-cyan/40 hover:shadow-glow"
    >
      <div className="relative aspect-square overflow-hidden bg-gradient-to-b from-white/[0.05] to-transparent"
        onPointerEnter={(e) => { if (can3D && e.pointerType === 'mouse') timer.current = setTimeout(() => setActive(p.id), 350); }}
        onPointerLeave={() => { clearTimeout(timer.current); if (getActive() === p.id) setActive(null); }}>
        {live ? (
          <SoftBoundary fallback={fake}><Suspense fallback={fake}><ModelStage url={p.model!.model_url} speed={1} active movedRef={moved} /></Suspense></SoftBoundary>
        ) : fake}
        {!live && <Link to={`/product/${p.slug}`} className="absolute inset-0" aria-label={`${p.name}, view details`} tabIndex={-1} />}
        {p.price && p.price.percent > 0 && !out && <span className="pointer-events-none absolute left-3 top-3 rounded-full bg-gold px-2.5 py-1 text-[11px] font-bold text-ink">-{p.price.percent}%</span>}
        {can3D && (
          <button type="button" aria-pressed={live} aria-label={live ? `Stop 3D view of ${p.name}` : `View ${p.name} in 3D`} onClick={() => setActive(live ? null : p.id)}
            className={`absolute right-2 top-2 inline-flex min-h-9 items-center gap-1 rounded-full px-3 text-[11px] font-bold backdrop-blur ${live ? 'bg-cyan text-ink' : 'bg-black/50 text-cyan hover:bg-black/70'}`}><Box className="h-3.5 w-3.5" aria-hidden="true" />3D</button>
        )}
        {out && <span className="pointer-events-none absolute inset-x-0 bottom-0 bg-black/70 py-1.5 text-center text-xs font-semibold text-white/80">Out of stock</span>}
      </div>

      <div className="flex flex-1 flex-col gap-2.5 p-3 sm:p-4">
        {p.categories && <p className="text-[11px] font-semibold uppercase tracking-widest text-cyan/80">{p.categories.name}</p>}
        <h3 className="font-display text-sm font-semibold leading-snug sm:text-base"><Link to={`/product/${p.slug}`} className="hover:text-cyan">{p.name}</Link></h3>
        <PriceRows price={p.price} />
        <div className="mt-auto pt-1">
          {orderable
            ? <Link to={`/order/${p.slug}`} className="btn btn-primary min-h-[44px] w-full px-3 text-xs sm:text-sm">{label}{label === 'ORDER NOW' ? ' →' : ''}</Link>
            : <span className="btn w-full cursor-not-allowed border border-white/10 px-3 text-xs text-white/40 sm:text-sm" aria-disabled="true">{label}</span>}
        </div>
      </div>
    </motion.article>
  );
}
