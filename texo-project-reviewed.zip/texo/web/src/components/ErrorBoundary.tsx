import { Component } from 'react';
import type { ReactNode } from 'react';

export class ErrorBoundary extends Component<{ children: ReactNode }, { failed: boolean }> {
  state = { failed: false };
  static getDerivedStateFromError() { return { failed: true }; }
  componentDidCatch(err: unknown) { console.error(err); }
  render() {
    if (!this.state.failed) return this.props.children;
    return (
      <div role="alert" className="grid min-h-screen place-items-center px-6 text-center">
        <div><p className="font-display text-3xl font-bold">Something went wrong</p>
          <p className="mt-2 text-white/60">Please refresh the page. If it keeps happening, contact us.</p>
          <button className="btn btn-primary mt-6" onClick={() => location.reload()}>Refresh</button></div>
      </div>
    );
  }
}
