import type { ReactNode } from 'react';
import { CategoryNav } from './CategoryNav';

/** Desktop: sticky left category sidebar. Mobile: sidebar hidden (drawer is opened from the page). */
export function StoreShell({ children }: { children: ReactNode }) {
  return (
    <div className="container-x grid gap-8 py-6 lg:grid-cols-[230px_minmax(0,1fr)] lg:py-8">
      <aside className="hidden lg:block">
        <div className="sticky top-24 max-h-[calc(100vh-7rem)] overflow-y-auto rounded-2xl border border-white/10 bg-white/[0.02] p-3">
          <CategoryNav />
        </div>
      </aside>
      <div className="min-w-0">{children}</div>
    </div>
  );
}
