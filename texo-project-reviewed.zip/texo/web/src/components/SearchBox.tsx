import { Search } from 'lucide-react';
import { useEffect, useId, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDebounced, useSearch } from '../hooks/queries';
import { PriceTag } from './PriceTag';
import { ProductImage } from './ProductImage';

export function SearchBox({ autoFocus = false, onDone }: { autoFocus?: boolean; onDone?: () => void }) {
  const [q, setQ] = useState('');
  const [open, setOpen] = useState(false);
  const dq = useDebounced(q.trim(), 250);
  const { data, isFetching, isError } = useSearch(dq);
  const nav = useNavigate();
  const box = useRef<HTMLDivElement>(null);
  const listId = useId();
  useEffect(() => {
    const h = (e: MouseEvent) => { if (!box.current?.contains(e.target as Node)) setOpen(false); };
    document.addEventListener('mousedown', h);
    return () => document.removeEventListener('mousedown', h);
  }, []);
  const go = (to: string) => { setOpen(false); setQ(''); onDone?.(); nav(to); };
  return (
    <div ref={box} className="relative w-full">
      <form role="search" onSubmit={(e) => { e.preventDefault(); if (q.trim().length >= 2) go(`/products?q=${encodeURIComponent(q.trim())}`); }}>
        <label htmlFor={listId + 'in'} className="sr-only">Search products</label>
        <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-white/45" aria-hidden="true" />
        <input id={listId + 'in'} className="input rounded-full pl-11" placeholder="Search products, SKU, category" autoFocus={autoFocus} value={q}
          onChange={(e) => { setQ(e.target.value); setOpen(true); }} onFocus={() => setOpen(true)} onKeyDown={(e) => e.key === 'Escape' && setOpen(false)}
          autoComplete="off" aria-controls={listId} aria-expanded={open && dq.length >= 2} />
      </form>
      {open && dq.length >= 2 && (
        <div id={listId} role="listbox" className="absolute left-0 right-0 top-full z-50 mt-2 max-h-[70vh] overflow-y-auto rounded-2xl border border-white/10 bg-panel p-2 shadow-2xl">
          {isFetching && !data && <p className="p-4 text-sm text-white/50">Searching…</p>}
          {isError && <p className="p-4 text-sm text-gold">Search is unavailable right now.</p>}
          {data && data.length === 0 && <p className="p-4 text-sm text-white/60">No products match “{dq}”.</p>}
          {data?.map((p) => (
            <button key={p.id} role="option" aria-selected="false" onClick={() => go(`/product/${p.slug}`)} className="flex w-full items-center gap-3 rounded-xl p-2 text-left hover:bg-white/5">
              <ProductImage src={p.thumb_url ?? p.main_image_url} alt="" className="h-12 w-12 shrink-0 rounded-lg" />
              <span className="min-w-0 flex-1"><span className="block truncate text-sm font-medium">{p.name}</span><span className="block text-xs text-white/40">{p.sku}</span></span>
              <PriceTag price={p.price} />
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
