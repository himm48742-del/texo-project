import { formatTaka } from '../lib/format';
import type { PriceBlock } from '../types/api';

/** Compact price (search results, summaries). */
export function PriceTag({ price, size = 'md' }: { price: PriceBlock | null; size?: 'md' | 'lg' }) {
  if (!price) return null;
  const big = size === 'lg';
  const discounted = price.save > 0;
  return (
    <div>
      <div className="flex flex-wrap items-baseline gap-x-3 gap-y-1">
        <span className={`font-display font-bold ${big ? 'text-4xl' : 'text-lg'} text-white`}>{formatTaka(price.final)}</span>
        {discounted && (
          <s className={`${big ? 'text-xl' : 'text-sm'} text-white/45`}>
            <span className="sr-only">Regular price </span>{formatTaka(price.regular)}
          </s>
        )}
        {discounted && price.percent > 0 && (
          <span className="rounded-full bg-gold/15 px-2.5 py-0.5 text-xs font-bold text-gold">{price.percent}% OFF</span>
        )}
      </div>
      {big && discounted && <p className="mt-2 text-sm font-medium text-cyan">You save {formatTaka(price.save)}{price.offerText ? ` · ${price.offerText}` : ''}</p>}
    </div>
  );
}

/**
 * Labelled price layout used on product cards and the order page:
 *   Regular Price: ৳2,490 (crossed out)
 *   Discount Price: ৳1,790
 *   Save ৳700 — 28% OFF
 * Every number comes from the server (same code as checkout).
 */
export function PriceRows({ price, large = false }: { price: PriceBlock | null; large?: boolean }) {
  if (!price) return null;
  const sz = large ? 'text-base' : 'text-xs sm:text-sm';
  if (price.save <= 0)
    return <p className={`flex items-baseline justify-between gap-2 ${sz}`}><span className="text-white/60">Price:</span><b className={`font-display ${large ? 'text-2xl' : 'text-base'}`}>{formatTaka(price.final)}</b></p>;
  return (
    <div className={`space-y-1 ${sz}`}>
      <p className="flex items-baseline justify-between gap-2"><span className="text-white/55">Regular Price:</span><s className="text-white/45">{formatTaka(price.regular)}</s></p>
      <p className="flex items-baseline justify-between gap-2"><span className="text-white/80">Discount Price:</span><b className={`font-display text-cyan ${large ? 'text-3xl' : 'text-base sm:text-lg'}`}>{formatTaka(price.final)}</b></p>
      <p className="font-semibold text-gold">Save {formatTaka(price.save)}{price.percent > 0 ? ` — ${price.percent}% OFF` : ''}</p>
    </div>
  );
}
