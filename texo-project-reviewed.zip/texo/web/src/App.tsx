import { lazy, Suspense } from 'react';
import { Route, Routes } from 'react-router-dom';
import { Layout } from './components/Layout';
import { Welcome } from './components/Welcome';
import { Home, Products } from './pages/Products';

// Code splitting: heavy/secondary pages load on demand.
const ProductPage = lazy(() => import('./pages/ProductPage').then((m) => ({ default: m.ProductPage })));
const OrderPage = lazy(() => import('./pages/OrderPage').then((m) => ({ default: m.OrderPage })));
const Checkout = lazy(() => import('./pages/Checkout').then((m) => ({ default: m.Checkout })));
const OrderSuccess = lazy(() => import('./pages/OrderSuccess').then((m) => ({ default: m.OrderSuccess })));
const Offers = lazy(() => import('./pages/Info').then((m) => ({ default: m.Offers })));
const News = lazy(() => import('./pages/Info').then((m) => ({ default: m.News })));
const About = lazy(() => import('./pages/Info').then((m) => ({ default: m.About })));
const Contact = lazy(() => import('./pages/Info').then((m) => ({ default: m.Contact })));
// Admin area: its own code-split bundle, never loaded for normal shoppers.
const AdminRoot = lazy(() => import('./admin/AdminRoutes').then((m) => ({ default: m.AdminRoutes })));
const NotFound = lazy(() => import('./pages/Info').then((m) => ({ default: m.NotFound })));

export default function App() {
  return (
    <>
    <Welcome />
    <Suspense fallback={<div className="grid min-h-screen place-items-center text-white/50" role="status">Loading…</div>}>
      <Routes>
        <Route path="admin/*" element={<AdminRoot />} />
        <Route element={<Layout />}>
          <Route index element={<Home />} />
          <Route path="products" element={<Products />} />
          <Route path="product/:slug" element={<ProductPage />} />
          <Route path="order/:slug" element={<OrderPage />} />
          <Route path="checkout" element={<Checkout />} />
          <Route path="order-success/:no" element={<OrderSuccess />} />
          <Route path="offers" element={<Offers />} />
          <Route path="news" element={<News />} />
          <Route path="about" element={<About />} />
          <Route path="contact" element={<Contact />} />
          <Route path="*" element={<NotFound />} />
        </Route>
      </Routes>
    </Suspense>
    </>
  );
}
