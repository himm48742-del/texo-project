import { test } from 'node:test';
import assert from 'node:assert/strict';
import { clampSeconds, clampSpeed, mergeBatch, nextIndex, preloadTargets, prevIndex, shouldFetchMore } from '../src/lib/heroQueue.ts';
import { exitMs, seeded, splitGraphemes, welcomeMode, welcomeTimeline } from '../src/lib/welcome.ts';

const P = (id: string, img: string | null = `/${id}.webp`) => ({ id, main_image_url: img, thumb_url: null });

test('queue: merge de-duplicates (server wrap-around never doubles products)', () => {
  const a = [P('1'), P('2')];
  assert.deepEqual(mergeBatch(a, [P('2'), P('3'), P('3')]).map((x) => x.id), ['1', '2', '3']);
  assert.equal(mergeBatch(a, [P('1')]), a);
});
test('queue: rotation order, loop and wait-for-more', () => {
  assert.equal(nextIndex(0, 3, false), 1);
  assert.equal(nextIndex(2, 3, false), 0);   // loops forever
  assert.equal(nextIndex(2, 3, true), 2);    // more products loading: wait on the last one
  assert.equal(nextIndex(0, 1, false), 0);
  assert.equal(prevIndex(0, 3), 2);
  assert.equal(prevIndex(2, 3), 1);
});
test('queue: loads in small batches, never everything up front (500+ products)', () => {
  assert.equal(shouldFetchMore(0, 0, 500), true);
  assert.equal(shouldFetchMore(0, 6, 500), false);
  assert.equal(shouldFetchMore(3, 6, 500), true);
  assert.equal(shouldFetchMore(5, 6, 6), false);   // everything loaded
});
test('queue: preloads only the next 2 images', () => {
  const items = Array.from({ length: 500 }, (_, i) => P(String(i)));
  assert.deepEqual(preloadTargets(items, 0), ['/1.webp', '/2.webp']);
  assert.deepEqual(preloadTargets(items.slice(0, 3), 2), ['/0.webp', '/1.webp']); // wraps
  assert.deepEqual(preloadTargets([P('1', null), P('2', null)], 0), []);
  assert.deepEqual(preloadTargets([P('1')], 0), []);
});
test('admin settings are clamped to safe ranges', () => {
  assert.equal(clampSeconds(undefined), 6);
  assert.equal(clampSeconds(1), 3);
  assert.equal(clampSeconds('12'), 12);
  assert.equal(clampSeconds(999), 30);
  assert.equal(clampSpeed('abc'), 1);
  assert.equal(clampSpeed(0), 0.5);
  assert.equal(clampSpeed(5), 2);
});
test('welcome: first visit full, later short, same session skipped, reduced motion skipped', () => {
  const base = { seenBefore: false, seenThisSession: false, reducedMotion: false, isHome: true };
  assert.equal(welcomeMode(base), 'full');
  assert.equal(welcomeMode({ ...base, seenBefore: true }), 'short');
  assert.equal(welcomeMode({ ...base, seenBefore: true, seenThisSession: true }), 'skip');
  assert.equal(welcomeMode({ ...base, reducedMotion: true }), 'skip');
  assert.equal(welcomeMode({ ...base, isHome: false }), 'skip');
});
test('welcome: timeline order, speed setting and short mode', () => {
  assert.deepEqual(welcomeTimeline('full', 1).map((s) => s.id), ['line1', 'line2', 'logo', 'brand']);
  assert.deepEqual(welcomeTimeline('short', 1).map((s) => s.id), ['logo', 'brand']);
  assert.deepEqual(welcomeTimeline('skip', 1), []);
  const total = (m: 'full' | 'short', sp: number) => welcomeTimeline(m, sp).reduce((a, s) => a + s.ms, 0);
  assert.ok(total('full', 2) < total('full', 1));
  assert.ok(total('short', 1) < total('full', 1));
  assert.ok(exitMs(2) < exitMs(1));
});
test('Bangla text is split into whole characters', () => {
  const t = 'স্বাগতম TEXO-তে';
  const parts = splitGraphemes(t);
  assert.equal(parts.join(''), t);
  assert.ok(parts.length > 0 && parts.length <= Array.from(t).length);
  assert.ok(!parts.some((p) => /^[\u09BE-\u09CC\u09CD]/.test(p)), 'no piece may start with a vowel sign or virama');
});
test('particles are deterministic', () => {
  const a = seeded(7), b = seeded(7);
  assert.deepEqual([a(), a(), a()], [b(), b(), b()]);
});
