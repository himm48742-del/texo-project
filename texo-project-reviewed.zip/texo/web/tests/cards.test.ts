import { test } from 'node:test';
import assert from 'node:assert/strict';
import { getActive, setActive, subscribe } from '../src/lib/activeModel.ts';

test('only ONE product card can run the real 3D scene at a time', () => {
  let calls = 0;
  const off = subscribe(() => { calls++; });
  setActive('a'); assert.equal(getActive(), 'a');
  setActive('b'); assert.equal(getActive(), 'b');   // starting b replaces a
  setActive('b'); assert.equal(calls, 2);           // no change = no re-render
  setActive(null); assert.equal(getActive(), null);
  off(); setActive('c'); assert.equal(calls, 3);    // unsubscribed listeners are not called
  setActive(null);
});
