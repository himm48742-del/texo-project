import { test } from 'node:test';
import assert from 'node:assert/strict';
import { percentToSale, saleToPercent, discountPreview, fieldErrors, fileNameFromUrl, formatBytes, fromLocalInput, moveItem, orderDiscount, toLocalInput, toNumberOrNull, validateImageFile, validateModelFile } from '../src/admin/lib/helpers.ts';
import { formatTaka, setCurrencySymbol } from '../src/lib/format.ts';

test('image file checks (type + 5 MB)', () => {
  assert.equal(validateImageFile({ name: 'a.JPG', type: 'image/jpeg', size: 1000 }), null);
  assert.equal(validateImageFile({ name: 'a.avif', type: 'image/avif', size: 1000 }), null);
  assert.match(validateImageFile({ name: 'a.gif', type: 'image/gif', size: 10 })!, /JPG, PNG/);
  assert.match(validateImageFile({ name: 'a.jpg', type: 'application/pdf', size: 10 })!, /not a supported/);
  assert.match(validateImageFile({ name: 'a.png', type: 'image/png', size: 6 * 1024 * 1024 })!, /maximum is 5 MB/);
  assert.match(validateImageFile({ name: 'a.png', type: 'image/png', size: 0 })!, /empty/);
});
test('3D model file checks (.glb/.gltf + 15 MB)', () => {
  assert.equal(validateModelFile({ name: 'chair.glb', size: 1e6 }), null);
  assert.equal(validateModelFile({ name: 'chair.gltf', size: 1e6 }), null);
  assert.match(validateModelFile({ name: 'chair.obj', size: 10 })!, /\.glb or \.gltf/);
  assert.match(validateModelFile({ name: 'chair.glb', size: 16 * 1024 * 1024 })!, /15 MB/);
});
test('price/discount preview matches the server maths', () => {
  assert.deepEqual(discountPreview(2490, 1790), { valid: true, save: 700, percent: 28, message: '' });
  assert.equal(discountPreview('2490', '').valid, true);
  assert.equal(discountPreview('2490', '').percent, 0);
  assert.equal(discountPreview(2490, 2490).valid, false);
  assert.equal(discountPreview(2490, 3000).valid, false);
  assert.equal(discountPreview(2490, -5).valid, false);
  assert.equal(discountPreview('', 100).valid, false);
  assert.equal(discountPreview(59.97, 49.97).save, 10);
});
test('moveItem (drag & drop / up-down reorder)', () => {
  assert.deepEqual(moveItem(['a', 'b', 'c', 'd'], 0, 2), ['b', 'c', 'a', 'd']);
  assert.deepEqual(moveItem(['a', 'b', 'c'], 2, 0), ['c', 'a', 'b']);
  const l = ['a', 'b']; assert.equal(moveItem(l, 0, 5), l); assert.equal(moveItem(l, 1, 1), l);
});
test('datetime-local conversion round-trips', () => {
  const iso = '2026-10-31T09:30:00.000Z';
  assert.equal(fromLocalInput(toLocalInput(iso)), iso);
  assert.equal(toLocalInput(null), ''); assert.equal(fromLocalInput(''), null); assert.equal(fromLocalInput('garbage'), null);
});
test('misc helpers', () => {
  assert.equal(fileNameFromUrl('https://x.co/storage/v1/object/public/product-models/my%20chair.glb?v=1'), 'my chair.glb');
  assert.equal(formatBytes(2.5 * 1048576), '2.5 MB');
  assert.equal(orderDiscount([{ unit_regular: 2490, unit_price: 1790, quantity: 2 }, { unit_regular: 990, unit_price: 990, quantity: 1 }]), 1400);
  assert.equal(orderDiscount(), 0);
  assert.deepEqual(fieldErrors([{ field: 'sku', message: 'bad' }, { field: 'sku', message: 'dup' }]), { sku: 'bad' });
  assert.equal(toNumberOrNull(' '), null); assert.equal(toNumberOrNull('12.5'), 12.5); assert.equal(toNumberOrNull('x'), null);
});
test('currency symbol is admin-configurable', () => {
  setCurrencySymbol('$'); assert.equal(formatTaka(10), '$10');
  setCurrencySymbol(''); assert.equal(formatTaka(10), '৳10');
});

test('discount % and sale price stay linked in the editor', () => {
  assert.equal(percentToSale(2490, 28), '1792.8');
  assert.equal(percentToSale('1000', '50'), '500');
  assert.equal(percentToSale(1000, ''), ''); assert.equal(percentToSale(1000, 0), ''); assert.equal(percentToSale(1000, 100), ''); assert.equal(percentToSale('', 10), '');
  assert.equal(saleToPercent(2490, 1790), '28');
  assert.equal(saleToPercent(2490, 2490), ''); assert.equal(saleToPercent(2490, ''), ''); assert.equal(saleToPercent('', 100), '');
});
