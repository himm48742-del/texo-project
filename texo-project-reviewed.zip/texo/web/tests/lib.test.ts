import { test } from 'node:test';
import assert from 'node:assert/strict';
import { formatTaka } from '../src/lib/format.ts';
import { normalizePhone, validateCheckout } from '../src/lib/validation.ts';
import { buildWhatsAppMessage, normalizeWaNumber, whatsappUrl } from '../src/lib/whatsapp.ts';
import { DISTRICTS } from '../src/lib/districts.ts';

test('formatTaka', () => {
  assert.equal(formatTaka(2490), '৳2,490');
  assert.equal(formatTaka(125000), '৳1,25,000');
  assert.equal(formatTaka(59.97), '৳59.97');
});
test('phone + checkout validation', () => {
  assert.equal(normalizePhone('+880 1712-345678'), '01712345678');
  assert.equal(normalizePhone('0212345678'), null);
  const f = { name: 'A', phone: '123', address: 'short', district: '', area: '', notes: '' };
  assert.deepEqual(Object.keys(validateCheckout(f)).sort(), ['address', 'district', 'name', 'phone']);
  assert.deepEqual(validateCheckout({ name: 'Rahim', phone: '01712345678', address: 'House 5, Road 3, Dhanmondi', district: 'Dhaka', area: '', notes: '' }), {});
});
test('WhatsApp number comes from settings and is normalised', () => {
  assert.equal(normalizeWaNumber('01601603092'), '8801601603092');
  assert.equal(normalizeWaNumber('+880 1601-603092'), '8801601603092');
  assert.equal(normalizeWaNumber('8801601603092'), '8801601603092');
  assert.match(whatsappUrl('01601603092', 'hi there'), /^https:\/\/wa\.me\/8801601603092\?text=hi%20there$/);
});
test('WhatsApp message has product, quantity, price and customer info', () => {
  const m = buildWhatsAppMessage({
    orderNo: 1001, lines: [{ name: 'TEXO AirBuds X1', quantity: 2, unitPrice: 1790, regularPrice: 2490 }],
    subtotal: 3580, deliveryCharge: 60, total: 3640,
    customer: { name: 'Rahim', phone: '01712345678', address: 'House 5', district: 'Dhaka', area: 'Dhanmondi' },
  });
  for (const part of ['Order #1001', 'TEXO AirBuds X1 × 2', '৳1,790', 'was ৳2,490', 'Total: ৳3,640', 'Rahim', '01712345678', 'Dhanmondi, Dhaka'])
    assert.ok(m.includes(part), part);
  assert.ok(buildWhatsAppMessage({ lines: [{ name: 'X', quantity: 1, unitPrice: 5, regularPrice: 5 }] }).startsWith('TEXO — I want to order'));
});
test('64 districts, unique', () => {
  assert.equal(DISTRICTS.length, 64);
  assert.equal(new Set(DISTRICTS).size, 64);
});
