import react from '@vitejs/plugin-react';
import { defineConfig } from 'vite';

// In development, /api is forwarded to the TEXO server (npm run dev in /server).
export default defineConfig({
  plugins: [react()],
  server: { port: 5173, proxy: { '/api': 'http://localhost:4000' } },
  preview: { port: 4173, proxy: { '/api': 'http://localhost:4000' } }, // so `npm run preview` can reach the API too
  build: {
    target: 'es2022', sourcemap: false,
    rollupOptions: {
      output: {
        // The 3D engine lives in its own chunk and is only downloaded when a product has a 3D model.
        manualChunks(id) {
          if (id.includes('/node_modules/three/') || id.includes('/node_modules/@react-three/')) return 'three';
          if (id.includes('/node_modules/framer-motion/')) return 'motion';
          if (id.includes('/node_modules/react') || id.includes('/node_modules/@tanstack/')) return 'react';
        },
      },
    },
  },
});
