/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: { ink: '#04060A', panel: '#0A0F18', cyan: { DEFAULT: '#00E5FF' }, electric: '#0066FF', gold: '#D4AF37' },
      fontFamily: {
        display: ['"Space Grotesk"', 'system-ui', 'sans-serif'],
        sans: ['"Plus Jakarta Sans"', '"Hind Siliguri"', 'system-ui', 'sans-serif'],
        bn: ['"Hind Siliguri"', '"Plus Jakarta Sans"', 'sans-serif'],
      },
      boxShadow: { glow: '0 0 40px -10px rgba(0,229,255,.35)' },
    },
  },
  plugins: [],
};
