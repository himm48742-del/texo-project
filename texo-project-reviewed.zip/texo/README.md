# TEXO — Your Tech.

Online store + admin dashboard. React web app (`web/`), Node API (`server/`), Supabase database (`supabase/`).

## Folders
```
texo/
  supabase/migrations/   001..005 SQL files (run once, in order, in the Supabase SQL Editor)
  supabase/seed.sql      20 demo products + default settings
  server/                API (port 4000)   scripts: dev, test, build, typecheck, start, doctor
  web/                   Website + /admin  scripts: dev, test, build, typecheck, preview
  VERIFY.md              Beginner step-by-step verification + browser test checklist
```

## What you need
- Node.js **22.18 or newer** (https://nodejs.org, choose "LTS"). Check with `node -v`.
- A free Supabase project (https://supabase.com).
- VS Code (any editor works).

## Settings ("environment variables")
Only **server/.env** needs secrets. The web folder needs none.

| File | Variable | Required? | Where to find it |
|---|---|---|---|
| server/.env | `SUPABASE_URL` | **Yes** | Supabase: Project Settings > API > Project URL |
| server/.env | `SUPABASE_ANON_KEY` | **Yes** | Project Settings > API > `anon` `public` key |
| server/.env | `SUPABASE_SERVICE_ROLE_KEY` | **Yes** (SECRET) | Project Settings > API > `service_role` key |
| server/.env | `PORT`, `CORS_ORIGIN`, `TRUST_PROXY`, `NODE_ENV` | No (defaults are fine locally) | |
| web/.env | `VITE_API_URL` | No (leave empty locally) | Only for a live website |

Create the file: in the `server` folder run `copy .env.example .env` (Windows) or `cp .env.example .env` (Mac/Linux), then open `.env` and replace the three placeholders. `.env` is ignored by Git. **Never paste these keys into chat, screenshots or Git.**

## One-time database setup (Supabase > SQL Editor > New query)
Open each file in VS Code, copy everything, paste into the SQL Editor, press **Run**. Order matters:
`001_schema.sql` → `seed.sql` → `002_order_functions.sql` → `003_offers_pricing.sql` → `004_phase4_settings.sql` → `005_admin_stats.sql` → `006_product_order_button.sql`.
Then create your admin: Supabase > Authentication > Users > **Add user**, copy that user's ID, and run
`insert into admin_users (user_id, full_name) values ('PASTE-USER-ID', 'Owner');`

## Run it (two terminals in VS Code: Terminal > New Terminal)
```
cd server
npm install
npm run dev
```
```
cd web
npm install
npm run dev
```
Store: http://localhost:5173 · Admin: http://localhost:5173/admin/login · API: http://localhost:4000/api/health

## Check everything
- `npm test` (in server and in web): unit tests, no database needed.
- `npm run typecheck` and `npm run build` (in server and in web).
- `npm run doctor` (in server): checks your own .env, Supabase tables/functions/buckets, security rules, the running API and the web connection. Prints PASS / FAIL with a plain-English fix. Never prints your keys.

Full beginner walkthrough and browser checklist: **VERIFY.md**. API reference: `server/docs/API.md`.

## Customer journey
Home (3D hero + product cards) → click a product (details, photos or real 3D) → **ORDER NOW** → `/order/<product>` (product, offer, quantity, your details, delivery option, summary) → **Confirm Order**.
Product cards: floating/tilting 3D-style photo; products with a `.glb/.gltf` show a **3D** chip (hover on desktop, tap on phone) that starts the real WebGL viewer (one at a time). Prices on cards: Regular Price, Discount Price, "Save ৳X — Y% OFF".

## What is built
Phase 1 database · Phase 2 API (server-side pricing, secure orders, admin auth, uploads) · Phase 3 storefront (categories, search, product page, checkout, WhatsApp) · Phase 4 hero showcase, 3D models, Bangla welcome intro · Phase 5 admin dashboard (products, gallery, 3D model, hero order, categories, orders, offers, news, settings).
