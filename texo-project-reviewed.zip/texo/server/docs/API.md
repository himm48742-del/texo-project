# TEXO API (Phase 2)

Base URL: `http://localhost:4000/api`. Success: `{ "data": ..., "meta": {...} }`. Error: `{ "error": { "code", "message", "details?" } }`.
Admin routes need `Authorization: Bearer <accessToken>` from `/admin/login`.

## Public (no login)
| Method | Path | Notes |
|---|---|---|
| GET | /health | liveness |
| GET | /settings | all public site settings as `{key: value}` (welcome text, phone, delivery, rotation speed…) |
| GET | /categories | active categories, ordered |
| GET | /products | `?category=<slug>&view=new\|featured\|offers&sort=order\|newest\|name&page=&limit=` (limit ≤ 60). Returns `meta.total` |
| GET | /products/:slug | full product, `images[]`, `model`, `related[]` |
| GET | /hero | hero queue: `?offset=&limit=` (≤ 20). `meta.nextOffset` wraps to 0 so the rotation loops |
| GET | /search | `?q=` (min 2 chars) by name, SKU, category |
| GET | /offers | active, started, not expired |
| GET | /news, /news/:slug | published articles |
| POST | /orders/quote | checkout preview `{items:[{productId,quantity}], district?}` → server-calculated lines, discount, delivery, total. Same code path as the real order |
| POST | /orders | create order (below). Limit: 10 / 10 min / IP. Optional `"channel": "whatsapp"` records the order as a WhatsApp order |

### POST /orders
```json
{ "customer": { "name": "Rahim", "phone": "01712345678", "address": "House 5, Road 3, Dhanmondi", "district": "Dhaka", "area": "Dhanmondi", "notes": "" },
  "items": [ { "productId": "<uuid>", "quantity": 2 } ] }
```
Any price, discount, subtotal, total or delivery field in the body is **ignored**. The server reads prices from `products`, delivery rules from `site_settings`, derives Inside/Outside Dhaka from `district`, and returns the authoritative breakdown (`subtotal, discount, deliveryCharge, total, orderNo`). Stock is re-checked and decremented atomically in Postgres (`place_order`). Errors: 400 `VALIDATION_ERROR`, 404 `PRODUCT_NOT_FOUND`, 409 `OUT_OF_STOCK`.

## Admin auth
| POST /admin/login | `{email,password}` → `{accessToken, refreshToken, expiresAt, user}`. 8 attempts / 15 min / IP |
|---|---|
| POST /admin/refresh | `{refreshToken}` |
| GET /admin/me | current admin |

## Admin (all require token)
| Resource | Endpoints |
|---|---|
| Products | GET/POST `/admin/products` (`?q=&category=&active=&page=&limit=`), GET/PATCH/DELETE `/admin/products/:id`, POST `/:id/duplicate`, POST `/admin/products/reorder` `{ids:[…], field:"display_order"\|"hero_order"}`, POST `/:id/images`, DELETE `/admin/product-images/:id`, PUT/DELETE `/:id/model` |
| Categories, Offers, News | GET/POST `/admin/{categories,offers,news}`, GET/PATCH/DELETE `/:id` |
| Orders | GET `/admin/orders` (`?status=&q=&phone=&from=&to=&productId=&page=`), GET `/:id`, PATCH `/:id/status` `{status}` (cancelling restocks; cancelled orders cannot be reopened) |
| Settings | GET/PUT `/admin/settings` (PUT body = `{key: value, …}`) |
| Uploads | POST `/admin/uploads/image?folder=products\|categories\|news\|offers\|site` (multipart field `file`, JPG/PNG/WEBP/AVIF, ≤ 5 MB → 1600 px WebP + 400 px thumb); POST `/admin/uploads/model` (`.glb/.gltf`, ≤ 15 MB) |

## Pricing and offers (what the customer actually pays)
Per unit the server charges the **lowest** of: `regular_price`, the product's `sale_price`, and any **live** offer that targets the product (or its category).
An offer is live only if `is_active`, `starts_at` has passed and `ends_at` has not (an unparseable date means NOT live). Offers are created at `/admin/offers`:
- Product offer with fixed price: `{title, product_id, offer_price: 1790, ends_at}`
- Percentage offer (product or category): `{title, category_id, discount_percent: 20, ends_at}` (1–99)
Prices must be > 0 with at most 2 decimals; negative, zero, NaN and sale/offer prices above the regular price are rejected (API validation, database constraints, and a final checkout guard).
Every product returned by the public API carries `price: {regular, final, save, percent, source: regular|sale|offer, offerText}`; the percentage is always computed from the real prices, so it can never disagree with the amount charged.

Pricing: send `regular_price` and `sale_price`; `discount_amount` and `discount_percent` are auto-calculated. Send `discount_percent` yourself to override (manual); changing prices later switches back to automatic.

## Testing with curl
```bash
B=http://localhost:4000/api
curl $B/health
curl "$B/products?category=audio&limit=5"
curl "$B/search?q=airbuds"
curl "$B/hero?limit=3"
# order (replace <uuid> with an id from /products)
curl -X POST $B/orders -H 'Content-Type: application/json' -d '{"customer":{"name":"Test","phone":"01712345678","address":"House 1, Road 2, Dhaka","district":"Dhaka"},"items":[{"productId":"<uuid>","quantity":1}]}'
# admin
TOKEN=$(curl -s -X POST $B/admin/login -H 'Content-Type: application/json' -d '{"email":"YOU@EMAIL","password":"YOURPASS"}' | python3 -c 'import sys,json;print(json.load(sys.stdin)["data"]["accessToken"])')
curl $B/admin/orders -H "Authorization: Bearer $TOKEN"
curl -X PATCH $B/admin/orders/<order-id>/status -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' -d '{"status":"confirmed"}'
curl -X POST $B/admin/uploads/image -H "Authorization: Bearer $TOKEN" -F file=@photo.jpg
curl -X POST $B/admin/uploads/model -H "Authorization: Bearer $TOKEN" -F file=@chair.glb
```
`npm run doctor` (in the server folder) runs a pass/fail check of your setup, the public endpoints and the admin protection.

## Admin dashboard endpoints (Phase 5; all need an admin token)
| Area | Endpoints |
|---|---|
| Overview | GET `/admin/stats` |
| Hero | GET `/admin/hero`; POST `/admin/products/:id/hero` `{featured}`; POST `/admin/products/reorder` `{ids, field:"hero_order"}` |
| Products | …plus PUT `/admin/products/:id/images/order` `{ids}`; DELETE `/admin/uploads` `{url}` (deletes a stored file + its thumbnail; only TEXO storage URLs are accepted) |
| Categories | …plus POST `/admin/categories/reorder` `{ids}` |
| Offers | …plus POST `/admin/offers/preview` (draft offer → real final price per product, status live/scheduled/expired/inactive, validation errors) |
| Settings | PUT `/admin/settings` accepts only known keys with typed ranges (brand_name, tagline, business_phone, whatsapp_number, footer_text, currency, currency_symbol, delivery_*, free_delivery_threshold, welcome_enabled, welcome_line1/2, hero_rotation_seconds 3–30, hero_animation_speed 0.5–2, hero_autoplay, hero_headline, hero_description, social_links) |
Validation errors: `400 {error:{code:"VALIDATION_ERROR", details:[{field, message}]}}`.

## Update: discount %, order button, card data
- `POST/PATCH /admin/products`: `discount_percent` (0–99) is now a real input. Sending it without `sale_price` sets the sale price to that % below the regular price (0 clears the sale). If both are sent, `sale_price` wins. The stored percent is always recalculated from the two prices.
- New product fields: `order_button_enabled` (bool), `order_button_text` (≤ 30 chars or null). A product with `order_button_enabled=false` is refused at checkout with `409 ORDER_DISABLED`.
- Public product lists now include `order_button_enabled`, `order_button_text` and `model` (`{model_url, format}` or null), so cards can show the 3D chip.
- `GET /offers` now filters with the same live-offer rule as checkout.
