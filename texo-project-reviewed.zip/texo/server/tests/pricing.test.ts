import { test } from 'node:test';
import assert from 'node:assert/strict';
import { computeTotals, salePriceFromPercent, unitCents, zoneFromDistrict } from '../src/services/pricing.ts';
import { sanitizeSearch, slugify, int, isUuid } from '../src/lib/utils.ts';

test('unit price uses sale only when valid and lower', () => {
  assert.deepEqual(unitCents({ regular_price: 2490, sale_price: 1790 }), { regular: 249000, unit: 179000 });
  assert.equal(unitCents({ regular_price: '2490.00', sale_price: null }).unit, 249000);
  assert.equal(unitCents({ regular_price: 100, sale_price: 150 }).unit, 10000); // sale above regular ignored
  assert.equal(unitCents({ regular_price: 100, sale_price: 0 }).unit, 10000);
});
test('no floating point drift', () => {
  const t = computeTotals([{ regular: 1999, unit: 1999, quantity: 3 }], { insideDhaka: 60, outsideDhaka: 120, freeThreshold: 0 }, 'inside_dhaka');
  assert.equal(t.subtotal, 59.97);
  assert.equal(t.total, 119.97); // 59.97 + 60 delivery
});
test('free delivery disabled when threshold is 0', () => {
  const t = computeTotals([{ regular: 1000000, unit: 1000000, quantity: 1 }], { insideDhaka: 60, outsideDhaka: 120, freeThreshold: 0 }, 'outside_dhaka');
  assert.equal(t.deliveryCharge, 120);
});
test('zones', () => {
  assert.equal(zoneFromDistrict(' Dhaka '), 'inside_dhaka');
  assert.equal(zoneFromDistrict('Gazipur'), 'outside_dhaka');
});
test('search sanitiser removes filter-breaking characters', () => {
  assert.equal(sanitizeSearch('a),is_active.eq.false,(b'), 'a is_active.eq.false b'.replace(/ /g, ' '));
  assert.equal(sanitizeSearch('  air%buds*  '), 'air buds');
});
test('utils', () => {
  assert.equal(slugify('TEXO AirBuds X1!'), 'texo-airbuds-x1');
  assert.match(slugify('বাংলা'), /^item-/);
  assert.equal(int('abc', 5, 1, 10), 5);
  assert.equal(int('999', 5, 1, 10), 10);
  assert.equal(isUuid('11111111-1111-4111-8111-111111111111'), true);
  assert.equal(isUuid("1' or 1=1"), false);
});

test('percent -> sale price is exact to the paisa', () => {
  assert.equal(salePriceFromPercent(2490, 28), 1792.8);
  assert.equal(salePriceFromPercent(1000, 50), 500);
  assert.equal(salePriceFromPercent('59.97', 10), 53.97);
  assert.equal(salePriceFromPercent(100, 1), 99);
});
