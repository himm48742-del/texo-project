import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createOrder, parseOrderInput, quoteOrder } from '../src/services/orderService.ts';
import type { DbProduct, OrderDeps, PlaceOrderPayload } from '../src/services/orderService.ts';
import { effectivePrice, isOfferLive, priceView } from '../src/services/pricing.ts';
import type { OfferLike } from '../src/services/pricing.ts';

const NOW = new Date('2026-10-05T12:00:00Z');
const P1 = '11111111-1111-4111-8111-111111111111';
const P2 = '22222222-2222-4222-8222-222222222222';
const CAT = 'cat-audio';
const PRODUCTS: DbProduct[] = [
  { id: P1, category_id: CAT, name: 'AirBuds', regular_price: 2000, sale_price: null, stock: 50, stock_status: 'in_stock', is_active: true },
  { id: P2, category_id: 'cat-other', name: 'Mouse', regular_price: 1000, sale_price: 900, stock: 50, stock_status: 'in_stock', is_active: true },
];
const offer = (o: Partial<OfferLike>): OfferLike => ({
  id: 'o1', offer_text: 'MEGA SALE', is_active: true, starts_at: '2026-10-01T00:00:00Z', ends_at: '2026-10-31T00:00:00Z',
  discount_percent: null, offer_price: 1500, product_id: P1, category_id: null, ...o,
});
function deps(offers: OfferLike[]) {
  const placed: PlaceOrderPayload[] = [];
  const d: OrderDeps = {
    getProducts: async (ids) => PRODUCTS.filter((p) => ids.includes(p.id)),
    getOffers: async () => offers,
    getDeliverySettings: async () => ({ insideDhaka: 60, outsideDhaka: 120, freeThreshold: 0 }),
    placeOrder: async (p) => { placed.push(p); return { id: 'x', order_no: 7 }; },
  };
  return { d, placed };
}
const cust = { name: 'Rahim', phone: '01712345678', address: 'House 5, Road 3, Dhanmondi', district: 'Dhaka' };
const order = (extra: object = {}, itemExtra: object = {}) =>
  parseOrderInput({ customer: cust, items: [{ productId: P1, quantity: 2, ...itemExtra }], ...extra });

// ---- 1. A valid active offer changes the checkout price ----
test('1a. active fixed-price offer is applied at checkout and saved on the order', async () => {
  const { d, placed } = deps([offer({})]);
  const r = await createOrder(order(), d, NOW);
  assert.equal(r.items[0].unitPrice, 1500);
  assert.equal(r.items[0].regularPrice, 2000);
  assert.equal(r.items[0].priceSource, 'offer');
  assert.equal(r.subtotal, 3000);
  assert.equal(r.discount, 1000);
  assert.equal(r.total, 3060);                       // + Dhaka delivery 60
  assert.equal(placed[0].items[0].unit_price, 1500); // what is stored in the database
  assert.equal(placed[0].order.total, 3060);
});
test('1b. percentage offer on a CATEGORY applies to its products only', async () => {
  const { d } = deps([offer({ product_id: null, category_id: CAT, offer_price: null, discount_percent: 25 })]);
  const q = await quoteOrder([{ productId: P1, quantity: 1 }, { productId: P2, quantity: 1 }], 'Dhaka', d, NOW);
  assert.equal(q.lines[0].unitPrice, 1500);          // 2000 - 25%
  assert.equal(q.lines[1].unitPrice, 900);           // other category: unchanged (own sale price)
});
test('1c. customer gets the LOWEST of sale price and offer; percent/amount are exact', () => {
  const p = PRODUCTS[1]; // regular 1000, sale 900
  assert.equal(priceView(p, [offer({ product_id: P2, offer_price: 950 })], NOW).final, 900);   // sale is better
  assert.equal(priceView(p, [offer({ product_id: P2, offer_price: 700 })], NOW).final, 700);   // offer is better
  const v = priceView(PRODUCTS[0], [offer({ offer_price: 1440 })], NOW);
  assert.deepEqual([v.regular, v.final, v.save, v.percent, v.source], [2000, 1440, 560, 28, 'offer']);
});

// ---- 2. Expired / not-started / inactive offers do NOT change the price ----
test('2. expired, future, inactive and malformed offers are ignored', async () => {
  const bad = [
    offer({ ends_at: '2026-10-04T23:59:59Z' }),                 // expired
    offer({ starts_at: '2026-10-06T00:00:00Z', ends_at: null }),// not started
    offer({ is_active: false }),                                // switched off
    offer({ ends_at: 'not-a-date' }),                           // garbage date => fail safe
    offer({ offer_price: -5 }), offer({ offer_price: 0 }),      // invalid prices
    offer({ offer_price: 2500 }),                               // "offer" above regular
    offer({ offer_price: null, discount_percent: 0 }), offer({ offer_price: null, discount_percent: 100 }),
    offer({ product_id: null, category_id: null }),             // targets nothing
    offer({ product_id: P2 }),                                  // targets another product
  ];
  for (const o of bad) {
    const { d } = deps([o]);
    const r = await createOrder(order(), d, NOW);
    assert.equal(r.items[0].unitPrice, 2000, JSON.stringify(o));
    assert.equal(r.items[0].priceSource, 'regular');
    assert.equal(r.discount, 0);
  }
  assert.equal(isOfferLive(offer({ ends_at: '2026-10-05T12:00:00Z' }), NOW), false); // ends exactly now => over
});
test('2b. the same offer stops applying once its end time passes', async () => {
  const o = offer({});
  const before = await createOrder(order(), deps([o]).d, new Date('2026-10-30T23:59:00Z'));
  const after = await createOrder(order(), deps([o]).d, new Date('2026-10-31T00:00:01Z'));
  assert.equal(before.items[0].unitPrice, 1500);
  assert.equal(after.items[0].unitPrice, 2000);
});

// ---- 3. A client cannot manipulate the discounted price ----
test('3a. price/offer fields in the request body and items are ignored', async () => {
  const { d, placed } = deps([offer({})]);
  const evil = {
    channel: 'web', subtotal: 1, total: 1, discount: 99999, deliveryCharge: 0, offerPrice: 1, offer_price: 1,
    unitPrice: 1, price: 1, discountPercent: 99, offerId: 'x',
  };
  const itemEvil = { price: 1, unitPrice: 1, offerPrice: 1, offer_price: 1, regularPrice: 1, discountPercent: 99, salePrice: 1, total: 1 };
  const r = await createOrder(order(evil, itemEvil), d, NOW);
  assert.equal(r.items[0].unitPrice, 1500);
  assert.equal(r.total, 3060);
  assert.equal(placed[0].items[0].unit_price, 1500);
  assert.equal(placed[0].order.subtotal, 3000);
});
test('3b. a client cannot claim an offer that is not live', async () => {
  const { d, placed } = deps([offer({ ends_at: '2026-10-01T00:00:00Z' })]);
  const r = await createOrder(order({ offerPrice: 1, offer_price: 1 }, { offerPrice: 1 }), d, NOW);
  assert.equal(r.items[0].unitPrice, 2000);
  assert.equal(placed[0].order.total, 4060);
});
test('3c. the quote preview equals the real order for the same input', async () => {
  const { d } = deps([offer({})]);
  const q = await quoteOrder([{ productId: P1, quantity: 2 }], 'Dhaka', d, NOW);
  const o = await createOrder(order(), d, NOW);
  assert.equal(q.total, o.total);
  assert.equal(q.subtotal, o.subtotal);
});
test('3d. zero/invalid DB price can never produce a free order', async () => {
  const d = deps([]).d;
  d.getProducts = async () => [{ ...PRODUCTS[0], regular_price: 0 }];
  await assert.rejects(createOrder(order(), d, NOW), { code: 'PRICE_UNAVAILABLE' });
});
test('quote without district defers delivery', async () => {
  const q = await quoteOrder([{ productId: P1, quantity: 1 }], null, deps([]).d, NOW);
  assert.equal(q.deliveryPending, true);
  assert.equal(q.total, 2000);
});
test('effectivePrice never exceeds regular', () => {
  const e = effectivePrice({ ...PRODUCTS[0], sale_price: 5000 }, [], NOW);
  assert.equal(e.unit, e.regular);
});
