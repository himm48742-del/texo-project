import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createOrder, parseOrderInput, normalizePhone } from '../src/services/orderService.ts';
import type { DbProduct, OrderDeps, PlaceOrderPayload } from '../src/services/orderService.ts';

const P1 = '11111111-1111-4111-8111-111111111111';
const P2 = '22222222-2222-4222-8222-222222222222';
const P3 = '33333333-3333-4333-8333-333333333333';
const DB: DbProduct[] = [
  { id: P1, category_id: 'c-audio', name: 'TEXO AirBuds X1', regular_price: 2490, sale_price: 1790, stock: 10, stock_status: 'in_stock', is_active: true },
  { id: P2, category_id: 'c-audio', name: 'TEXO Tracker T1', regular_price: 990, sale_price: null, stock: 0, stock_status: 'out_of_stock', is_active: true },
  { id: P3, category_id: 'c-audio', name: 'Hidden', regular_price: 100, sale_price: null, stock: 5, stock_status: 'in_stock', is_active: false },
];
function deps(overrides: Partial<OrderDeps> = {}) {
  const calls: PlaceOrderPayload[] = [];
  const d: OrderDeps = {
    getProducts: async (ids) => DB.filter((p) => ids.includes(p.id)),
    getOffers: async () => [],
    getDeliverySettings: async () => ({ insideDhaka: 60, outsideDhaka: 120, freeThreshold: 5000 }),
    placeOrder: async (p) => { calls.push(p); return { id: 'o1', order_no: 1001 }; },
    ...overrides,
  };
  return { d, calls };
}
const customer = { name: 'Rahim', phone: '01712345678', address: 'House 5, Road 3, Dhanmondi', district: 'Dhaka' };
const body = (items: unknown[], c: object = customer) => ({ customer: c, items });

test('SECURITY: client-sent prices/totals are ignored; DB price is used', async () => {
  const tampered = {
    ...body([{ productId: P1, quantity: 2, price: 1, unitPrice: 1, regular_price: 1, sale_price: 1 }]),
    subtotal: 1, total: 1, deliveryCharge: 0, discount: 9999,
  };
  const { d, calls } = deps();
  const r = await createOrder(parseOrderInput(tampered), d);
  assert.equal(r.subtotal, 3580);          // 2 x 1790 from DB
  assert.equal(r.deliveryCharge, 60);      // inside Dhaka from settings
  assert.equal(r.total, 3640);
  assert.equal(r.discount, 1400);          // (2490-1790) x 2
  assert.equal(calls[0].items[0].unit_price, 1790);
  assert.equal(calls[0].order.source, 'web');
  assert.equal(calls[0].order.total, 3640);
});

test('outside Dhaka charge; zone derived from district, not client', async () => {
  const { d } = deps();
  const r = await createOrder(parseOrderInput({ ...body([{ productId: P1, quantity: 1 }], { ...customer, district: 'Chattogram' }), deliveryZone: 'inside_dhaka' }), d);
  assert.equal(r.deliveryZone, 'outside_dhaka');
  assert.equal(r.total, 1790 + 120);
});

test('free delivery at/above threshold', async () => {
  const { d } = deps();
  const r = await createOrder(parseOrderInput(body([{ productId: P1, quantity: 3 }])), d); // 5370
  assert.equal(r.deliveryCharge, 0);
  assert.equal(r.total, 5370);
});

test('duplicate lines for same product are merged', () => {
  const i = parseOrderInput(body([{ productId: P1, quantity: 2 }, { productId: P1, quantity: 3 }]));
  assert.deepEqual(i.items, [{ productId: P1, quantity: 5 }]);
});

test('out of stock, insufficient stock, inactive product are rejected', async () => {
  const { d } = deps();
  await assert.rejects(createOrder(parseOrderInput(body([{ productId: P2, quantity: 1 }])), d), { code: 'OUT_OF_STOCK', status: 409 });
  await assert.rejects(createOrder(parseOrderInput(body([{ productId: P1, quantity: 11 }])), d), { code: 'OUT_OF_STOCK' });
  await assert.rejects(createOrder(parseOrderInput(body([{ productId: P3, quantity: 1 }])), d), { code: 'PRODUCT_NOT_FOUND', status: 404 });
});

test('validation: bad phone, bad qty, bad id, empty cart', () => {
  const bad = (b: unknown) => assert.throws(() => parseOrderInput(b), { code: 'VALIDATION_ERROR', status: 400 });
  bad(body([{ productId: P1, quantity: 1 }], { ...customer, phone: '12345' }));
  bad(body([{ productId: P1, quantity: 0 }]));
  bad(body([{ productId: P1, quantity: 21 }]));
  bad(body([{ productId: P1, quantity: 1.5 }]));
  bad(body([{ productId: 'abc', quantity: 1 }]));
  bad(body([]));
  bad(body([{ productId: P1, quantity: 12 }, { productId: P1, quantity: 12 }]));
  bad(null);
});

test('phone normalisation', () => {
  assert.equal(normalizePhone('+8801712345678'), '01712345678');
  assert.equal(normalizePhone('8801712 345678'), '01712345678');
  assert.equal(normalizePhone('01212345678'), null);
  assert.equal(normalizePhone(1712345678), null);
});

test('database failure propagates (not swallowed)', async () => {
  const { d } = deps({ placeOrder: async () => { throw new Error('db down'); } });
  await assert.rejects(createOrder(parseOrderInput(body([{ productId: P1, quantity: 1 }])), d), /db down/);
});

test('a product whose order button is switched off cannot be ordered (even by direct API call)', async () => {
  const { d } = deps({ getProducts: async (ids) => DB.filter((p) => ids.includes(p.id)).map((p) => ({ ...p, order_button_enabled: false })) });
  await assert.rejects(createOrder(parseOrderInput(body([{ productId: P1, quantity: 1 }])), d), { code: 'ORDER_DISABLED', status: 409 });
});
