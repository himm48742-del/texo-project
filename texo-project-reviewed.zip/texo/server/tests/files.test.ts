import { test } from 'node:test';
import assert from 'node:assert/strict';
import { detectImageType, validateModel } from '../src/services/fileValidation.ts';

const pad = (b: number[]) => Buffer.concat([Buffer.from(b), Buffer.alloc(32)]);
test('detects real image types by magic bytes', () => {
  assert.equal(detectImageType(pad([0xff, 0xd8, 0xff, 0xe0])), 'jpeg');
  assert.equal(detectImageType(pad([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])), 'png');
  assert.equal(detectImageType(Buffer.concat([Buffer.from('RIFF'), Buffer.alloc(4), Buffer.from('WEBP'), Buffer.alloc(8)])), 'webp');
  assert.equal(detectImageType(Buffer.concat([Buffer.alloc(4), Buffer.from('ftypavif'), Buffer.alloc(8)])), 'avif');
});
test('rejects disguised files (exe/html/svg renamed to .jpg)', () => {
  assert.equal(detectImageType(Buffer.from('MZ' + 'x'.repeat(40))), null);
  assert.equal(detectImageType(Buffer.from('<svg xmlns="http://www.w3.org/2000/svg"><script>alert(1)</script></svg>')), null);
  assert.equal(detectImageType(Buffer.from('<html>' + ' '.repeat(40))), null);
});
test('glb validation', () => {
  const glb = Buffer.alloc(24); glb.write('glTF', 0, 'ascii'); glb.writeUInt32LE(2, 4);
  assert.equal(validateModel(glb, 'Chair.GLB'), 'glb');
  assert.throws(() => validateModel(Buffer.alloc(24), 'x.glb'), { code: 'INVALID_FILE' });
  assert.throws(() => validateModel(glb, 'x.obj'), { code: 'INVALID_FILE' });
});
test('gltf validation', () => {
  assert.equal(validateModel(Buffer.from('{"asset":{"version":"2.0"}}'), 'a.gltf'), 'gltf');
  assert.throws(() => validateModel(Buffer.from('{"foo":1}'), 'a.gltf'), { code: 'INVALID_FILE' });
  assert.throws(() => validateModel(Buffer.from('not json'), 'a.gltf'), { code: 'INVALID_FILE' });
});
