import { randomUUID } from 'node:crypto';
import type { Store } from '../../src/services/store.ts';
import type { Row } from '../../src/validation/admin.ts';

/** In-memory Store used to test the real admin services without a database. */
export function fakeStore(seed: Record<string, Row[]> = {}) {
  const tables: Record<string, Row[]> = {};
  for (const [t, rows] of Object.entries(seed)) tables[t] = rows.map((r) => ({ ...r }));
  const T = (t: string) => (tables[t] ??= []);
  const calls: { fn: string; args: Row }[] = [];
  const removedFiles: { bucket: string; paths: string[] }[] = [];
  const store: Store = {
    async list(t, o = {}) {
      let rows = T(t).filter((r) => Object.entries(o.filter ?? {}).every(([k, v]) => r[k] === v));
      if (o.order) { const [k, asc] = o.order; rows = [...rows].sort((a, b) => ((a[k] ?? 0) > (b[k] ?? 0) ? 1 : -1) * (asc ? 1 : -1)); }
      return (o.limit ? rows.slice(0, o.limit) : rows).map((r) => ({ ...r }));
    },
    async get(t, id) { const r = T(t).find((x) => x.id === id); return r ? { ...r } : null; },
    async getMany(t, ids) { return T(t).filter((r) => ids.includes(r.id)).map((r) => ({ ...r })); },
    async insert(t, row) {
      if (t === 'products' && T(t).some((r) => r.sku === row.sku || r.slug === row.slug)) throw Object.assign(new Error('dup'), { code: '23505' });
      const r = { id: randomUUID(), created_at: new Date().toISOString(), ...row }; T(t).push(r); return { ...r };
    },
    async update(t, id, patch) { const r = T(t).find((x) => x.id === id); if (!r) return null; Object.assign(r, patch); return { ...r }; },
    async remove(t, id) { tables[t] = T(t).filter((r) => r.id !== id); if (t === 'products') tables.product_images = T('product_images').filter((r) => r.product_id !== id); },
    async upsert(t, rows, key) { for (const row of rows) { const e = T(t).find((r) => r[key] === row[key]); if (e) Object.assign(e, row); else T(t).push({ id: randomUUID(), ...row }); } },
    async rpc(fn, args) { calls.push({ fn, args }); return (fn === 'admin_stats' ? { orders: 3 } : { id: args.p_id, status: args.p_status }) as any; },
    async removeFiles(bucket, paths) { removedFiles.push({ bucket, paths }); },
    async searchProducts(q) { return { rows: T('products').filter((p) => (!q.hero || p.featured_in_hero) && (q.active === undefined || p.is_active === q.active)), total: T('products').length }; },
    async searchOrders(q) { return { rows: T('orders').filter((o) => !q.status || o.status === q.status), total: T('orders').length }; },
    async getProductDetail(id) { return this.get('products', id); },
    async getOrder(id) { return this.get('orders', id); },
  };
  return { store, tables, calls, removedFiles, T };
}
