import { test } from 'node:test';
import assert from 'node:assert/strict';
import * as svc from '../src/services/adminService.ts';
import { authorize, login, refreshSession } from '../src/services/authService.ts';
import type { AdminCheck, AuthDeps } from '../src/services/authService.ts';
import { assertImageUpload, assertModelUpload, parseStorageUrl } from '../src/services/fileValidation.ts';
import { parseOrderQuery, parseProductQuery, validateSettings } from '../src/validation/admin.ts';
import { fakeStore } from './helpers/fakeStore.ts';

const U1 = '11111111-1111-4111-8111-111111111111', U2 = '22222222-2222-4222-8222-222222222222', U3 = '33333333-3333-4333-8333-333333333333';
const NOW = new Date('2026-10-05T12:00:00Z');
const validation = (field?: string) => (e: any) => e.code === 'VALIDATION_ERROR' && e.status === 400 && (!field || e.details.some((d: any) => d.field === field));

// ------------------------------------------------------------- authentication / authorization
const session = { access_token: 'access-token-123456', refresh_token: 'refresh-token-123456', expires_at: 1900000000 };
function authDeps(over: Partial<AuthDeps> = {}): AuthDeps {
  return {
    signIn: async (email, pw) => (email === 'admin@texo.com' && pw === 'correct-horse' ? session : email === 'user@texo.com' && pw === 'pw' ? { ...session, access_token: 'plain-user-token-1' } : null),
    refresh: async (t) => (t === 'refresh-token-123456' ? session : null),
    verify: async (token): Promise<AdminCheck> => (token === 'access-token-123456' ? { ok: true, user: { id: 'a1', email: 'admin@texo.com' } } : token === 'plain-user-token-1' ? { ok: false, reason: 'forbidden' } : { ok: false, reason: 'invalid' }),
    ...over,
  };
}
test('AUTH: admin can log in and receives tokens', async () => {
  const r = await login(authDeps(), { email: 'admin@texo.com', password: 'correct-horse' });
  assert.equal(r.accessToken, session.access_token);
  assert.equal(r.user?.email, 'admin@texo.com');
});
test('AUTH: wrong password, unknown user and non-admin user all get the SAME generic error', async () => {
  const msgs: string[] = [];
  for (const b of [{ email: 'admin@texo.com', password: 'nope' }, { email: 'nobody@texo.com', password: 'x' }, { email: 'user@texo.com', password: 'pw' }]) {
    await assert.rejects(login(authDeps(), b), (e: any) => { msgs.push(e.message); return e.status === 401 && e.code === 'INVALID_CREDENTIALS'; });
  }
  assert.equal(new Set(msgs).size, 1);
});
test('AUTH: malformed login input is rejected before any lookup', async () => {
  let called = false;
  const d = authDeps({ signIn: async () => { called = true; return null; } });
  await assert.rejects(login(d, { email: 'not-an-email', password: '' }), validation('email'));
  await assert.rejects(login(d, null), validation());
  assert.equal(called, false);
});
test('AUTH: refresh works with a valid token only', async () => {
  assert.equal((await refreshSession(authDeps(), { refreshToken: 'refresh-token-123456' })).accessToken, session.access_token);
  await assert.rejects(refreshSession(authDeps(), { refreshToken: 'bad-refresh-token' }), { status: 401 });
  await assert.rejects(refreshSession(authDeps(), {}), { status: 401 });
});
test('UNAUTHORIZED: requests without / with bad / with non-admin tokens are rejected', async () => {
  const d = authDeps();
  await assert.rejects(authorize(d, undefined), { status: 401, code: 'UNAUTHENTICATED' });
  await assert.rejects(authorize(d, 'Basic abc'), { status: 401 });
  await assert.rejects(authorize(d, 'Bearer short'), { status: 401 });
  await assert.rejects(authorize(d, 'Bearer some-forged-token-1'), { status: 401 });
  await assert.rejects(authorize(d, 'Bearer plain-user-token-1'), { status: 403, code: 'FORBIDDEN' });
  assert.equal((await authorize(d, 'Bearer access-token-123456')).id, 'a1');
});

// ------------------------------------------------------------- products
const product = (over = {}) => ({ name: 'TEXO AirBuds X1', sku: 'TX-AU-001', regular_price: 2490, sale_price: 1790, stock: 10, ...over });
test('PRODUCT create: normalises, auto-slug, auto stock status, display order', async () => {
  const { store } = fakeStore({ products: [{ id: U1, display_order: 7, hero_order: 3 }] });
  const p = await svc.createProduct(store, { ...product(), featured_in_hero: true, features: [' ANC ', ''], specifications: { Battery: '30h', '': 'x' } });
  assert.equal(p.slug, 'texo-airbuds-x1');
  assert.equal(p.stock_status, 'in_stock');
  assert.equal(p.display_order, 8);
  assert.equal(p.hero_order, 4);
  assert.deepEqual(p.features, ['ANC']);
  assert.deepEqual(p.specifications, { Battery: '30h' });
  assert.equal((await svc.createProduct(store, product({ sku: 'LOW-1', slug: 'low-1', stock: 3 }))).stock_status, 'low_stock');
  assert.equal((await svc.createProduct(store, product({ sku: 'ZERO', slug: 'zero', stock: 0 }))).stock_status, 'out_of_stock');
});
test('PRODUCT create: invalid prices and fields are rejected', async () => {
  const { store, T } = fakeStore();
  for (const [over, field] of [
    [{ regular_price: -5 }, 'regular_price'], [{ regular_price: 0 }, 'regular_price'], [{ regular_price: '100' }, 'regular_price'],
    [{ regular_price: Infinity }, 'regular_price'], [{ regular_price: 10.999 }, 'regular_price'],
    [{ sale_price: 2490 }, 'sale_price'], [{ sale_price: 3000 }, 'sale_price'], [{ sale_price: -1 }, 'sale_price'], [{ sale_price: 0 }, 'sale_price'],
    [{ name: '' }, 'name'], [{ sku: 'bad sku!' }, 'sku'], [{ stock: -1 }, 'stock'], [{ stock: 1.5 }, 'stock'], [{ stock_status: 'weird' }, 'stock_status'],
    [{ main_image_url: 'javascript:alert(1)' }, 'main_image_url'], [{ category_id: 'nope' }, 'category_id'], [{ slug: 'Bad Slug' }, 'slug'],
  ] as [object, string][]) await assert.rejects(svc.createProduct(store, product(over)), validation(field), JSON.stringify(over));
  await assert.rejects(svc.createProduct(store, { sku: 'X' }), validation('name'));
  await assert.rejects(svc.createProduct(store, 'junk'), validation());
  assert.equal(T('products').length, 0);
});
test('PRODUCT create: duplicate SKU surfaces the database conflict', async () => {
  const { store } = fakeStore();
  await svc.createProduct(store, product());
  await assert.rejects(svc.createProduct(store, product()), { code: '23505' });
});
test('PRODUCT update: partial update, price rules checked against the saved row, discount resets to automatic', async () => {
  const { store } = fakeStore();
  const p = await svc.createProduct(store, { ...product(), discount_percent: 50 });   // sale price (1790) wins over a conflicting percent
  assert.equal(p.sale_price, 1790); assert.equal(p.discount_manual, false); assert.equal('discount_percent' in p, false);
  const u = await svc.updateProduct(store, p.id, { sale_price: 1990 });
  assert.equal(u.sale_price, 1990); assert.equal(u.name, 'TEXO AirBuds X1'); assert.equal(u.discount_manual, false);
  await assert.rejects(svc.updateProduct(store, p.id, { regular_price: 1500 }), validation('sale_price'));   // would put sale above regular
  await assert.rejects(svc.updateProduct(store, p.id, { sale_price: 9999 }), validation('sale_price'));
  assert.equal((await svc.updateProduct(store, p.id, { sale_price: null })).sale_price, null);
  assert.equal((await svc.updateProduct(store, p.id, { stock: 0 })).stock_status, 'out_of_stock');
  assert.equal((await svc.updateProduct(store, p.id, { stock: 20 })).stock_status, 'in_stock');
  assert.equal((await svc.updateProduct(store, p.id, { is_active: false })).is_active, false);
  await assert.rejects(svc.updateProduct(store, p.id, {}), validation());
  await assert.rejects(svc.updateProduct(store, U3, { name: 'x' }), { status: 404 });
});
test('PRODUCT delete + duplicate', async () => {
  const { store, T } = fakeStore();
  const p = await svc.createProduct(store, { ...product(), is_active: true });
  await svc.addGalleryImage(store, p.id, { url: 'https://x.test/a.webp' });
  const copy = await svc.duplicateProduct(store, p.id);
  assert.equal(copy.is_active, false); assert.match(copy.name, /\(Copy\)$/); assert.notEqual(copy.sku, p.sku); assert.notEqual(copy.slug, p.slug);
  assert.equal(T('product_images').filter((i) => i.product_id === copy.id).length, 1);
  assert.deepEqual(await svc.deleteProduct(store, p.id), { deleted: true });
  assert.equal(T('products').length, 1);
  await assert.rejects(svc.deleteProduct(store, p.id), { status: 404 });
});

// ------------------------------------------------------------- categories
test('CATEGORY CRUD', async () => {
  const { store } = fakeStore();
  const c = await svc.createResource(store, 'categories', { name: 'Smart Watch' });
  assert.equal(c.slug, 'smart-watch'); assert.equal(c.display_order, 1);
  assert.equal((await svc.createResource(store, 'categories', { name: 'Audio' })).display_order, 2);
  assert.equal((await svc.updateResource(store, 'categories', c.id, { name: 'Watches', is_active: false })).name, 'Watches');
  assert.equal((await svc.getResource(store, 'categories', c.id)).is_active, false);
  assert.equal((await svc.listResource(store, 'categories')).length, 2);
  await assert.rejects(svc.createResource(store, 'categories', { name: '' }), validation('name'));
  await assert.rejects(svc.createResource(store, 'categories', { name: 'X', icon_url: 'ftp://x' }), validation('icon_url'));
  await svc.deleteResource(store, 'categories', c.id);
  assert.equal((await svc.listResource(store, 'categories')).length, 1);
  await assert.rejects(svc.getResource(store, 'categories', c.id), { status: 404 });
});

// ------------------------------------------------------------- offers
const seedOffers = () => fakeStore({ products: [{ id: U1, name: 'AirBuds', regular_price: 2000, sale_price: null, category_id: U2, is_active: true }], categories: [{ id: U2, name: 'Audio' }] });
test('OFFER CRUD: product fixed price, category percentage', async () => {
  const { store } = seedOffers();
  const a = await svc.createResource(store, 'offers', { title: 'Mega', product_id: U1, offer_price: 1500, ends_at: '2026-10-31T00:00:00Z' });
  assert.equal(a.offer_price, 1500);
  const b = await svc.createResource(store, 'offers', { title: 'Audio week', category_id: U2, discount_percent: 20 });
  assert.equal((await svc.listResource(store, 'offers')).length, 2);
  assert.equal((await svc.updateResource(store, 'offers', a.id, { offer_price: 1400 })).offer_price, 1400);
  assert.equal((await svc.updateResource(store, 'offers', b.id, { is_active: false })).is_active, false);
  await svc.deleteResource(store, 'offers', a.id);
  assert.equal((await svc.listResource(store, 'offers')).length, 1);
});
test('OFFER cannot create an invalid price', async () => {
  const { store, T } = seedOffers();
  const base = { title: 'X', product_id: U1 };
  for (const [over, field] of [
    [{ offer_price: 2000 }, 'offer_price'], [{ offer_price: 2500 }, 'offer_price'], [{ offer_price: -1 }, 'offer_price'], [{ offer_price: 0 }, 'offer_price'],
    [{ discount_percent: 0 }, 'discount_percent'], [{ discount_percent: 100 }, 'discount_percent'], [{ discount_percent: -5 }, 'discount_percent'],
    [{}, 'offer_price'], [{ offer_price: 1000, discount_percent: 10 }, 'offer_price'],
    [{ offer_price: 1000, starts_at: '2026-10-10T00:00:00Z', ends_at: '2026-10-01T00:00:00Z' }, 'ends_at'],
    [{ product_id: U3, offer_price: 1000 }, 'product_id'], [{ offer_price: 1000, ends_at: 'garbage' }, 'ends_at'],
  ] as [object, string][]) await assert.rejects(svc.createResource(store, 'offers', { ...base, ...over }), validation(field), JSON.stringify(over));
  await assert.rejects(svc.createResource(store, 'offers', { title: 'X', category_id: U2, offer_price: 100 }), validation('offer_price')); // fixed price on a category
  await assert.rejects(svc.createResource(store, 'offers', { title: 'X', discount_percent: 10 }), validation('product_id'));              // no target
  await assert.rejects(svc.createResource(store, 'offers', { title: 'X', product_id: U1, category_id: U2, discount_percent: 10 }), validation('product_id')); // two targets
  assert.equal(T('offers').length, 0);
  const ok = await svc.createResource(store, 'offers', { ...base, offer_price: 1500 });
  await assert.rejects(svc.updateResource(store, 'offers', ok.id, { offer_price: 2100 }), validation('offer_price')); // edit can't break it either
});
test('OFFER preview shows the real final price (and never an invalid one)', async () => {
  const { store } = seedOffers();
  const p = await svc.previewOffer(store, { product_id: U1, offer_price: 1500, ends_at: '2026-10-31T00:00:00Z' }, NOW);
  assert.equal(p.valid, true); assert.equal(p.status, 'live');
  assert.deepEqual([p.items[0].regular, p.items[0].currentFinal, p.items[0].newFinal, p.items[0].percent, p.items[0].changesPrice], [2000, 2000, 1500, 25, true]);
  assert.equal((await svc.previewOffer(store, { category_id: U2, discount_percent: 20 }, NOW)).items[0].newFinal, 1600);
  assert.equal((await svc.previewOffer(store, { product_id: U1, offer_price: 1500, ends_at: '2026-10-01T00:00:00Z' }, NOW)).status, 'expired');
  assert.equal((await svc.previewOffer(store, { product_id: U1, offer_price: 1500, starts_at: '2026-11-01T00:00:00Z' }, NOW)).status, 'scheduled');
  assert.equal((await svc.previewOffer(store, { product_id: U1, offer_price: 1500, is_active: false }, NOW)).status, 'inactive');
  const bad = await svc.previewOffer(store, { product_id: U1, offer_price: 2600 }, NOW);
  assert.equal(bad.valid, false); assert.equal(bad.items.length, 0); assert.equal(bad.errors[0].field, 'offer_price');
});

// ------------------------------------------------------------- orders
test('ORDER status: valid statuses go to the stock-restoring SQL function; invalid ones never reach the database', async () => {
  const { store, calls } = fakeStore();
  for (const s of ['pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled']) await svc.setOrderStatus(store, U1, { status: s });
  assert.equal(calls.length, 6);
  assert.ok(calls.every((c) => c.fn === 'set_order_status' && c.args.p_id === U1));
  assert.equal(calls[5].args.p_status, 'cancelled'); // the cancel path = server-side restock (Phase 2 SQL, unchanged)
  calls.length = 0;
  for (const bad of [{ status: 'refunded' }, { status: '' }, {}, null, { status: 5 }]) await assert.rejects(svc.setOrderStatus(store, U1, bad), validation('status'));
  assert.equal(calls.length, 0);
});
test('ORDER list/search parameters are sanitised', () => {
  const q = parseOrderQuery({ status: 'shipped', q: 'a),status.eq.x,(', phone: '017%', from: '2026-10-01', to: 'bad', productId: U1, page: '-3', limit: '9999' });
  assert.deepEqual([q.status, q.from, q.to, q.productId, q.page, q.limit], ['shipped', '2026-10-01', undefined, U1, 1, 100]);
  assert.ok(!/[(),]/.test(q.q)); assert.ok(!/%/.test(q.phone));
  assert.equal(parseOrderQuery({ status: 'hacked' }).status, undefined);
  assert.deepEqual(parseProductQuery({ active: 'true', hero: 'true', category: 'zzz' }).categoryId, undefined);
});

// ------------------------------------------------------------- settings
test('SETTINGS update: saves typed values; rejects unknown keys and bad values', async () => {
  const { store, T } = fakeStore();
  const r = await svc.updateSettings(store, {
    brand_name: ' TEXO ', tagline: 'YOUR TECH.', business_phone: '01601603092', delivery_inside_dhaka: 60, delivery_outside_dhaka: '120', free_delivery_threshold: 5000,
    welcome_enabled: false, hero_rotation_seconds: 8, hero_animation_speed: 1.5, hero_autoplay: true, currency: 'BDT', currency_symbol: '৳',
    social_links: { facebook: 'https://facebook.com/texo', instagram: '', email: 'hello@texo.com' }, footer_text: '© TEXO',
  });
  assert.equal(r.updated, 14);
  const s = await svc.getSettings(store);
  assert.equal(s.brand_name, 'TEXO'); assert.equal(s.delivery_outside_dhaka, 120); assert.equal(s.welcome_enabled, false);
  assert.deepEqual(s.social_links, { facebook: 'https://facebook.com/texo', instagram: '', email: 'hello@texo.com' });
  await svc.updateSettings(store, { brand_name: 'TEXO 2' });
  assert.equal(T('site_settings').filter((x) => x.key === 'brand_name').length, 1); // upsert, not duplicate
  for (const [bad, field] of [
    [{ evil_key: 1 }, 'evil_key'], [{ 'private.secret': 'x' }, 'private.secret'], [{ delivery_inside_dhaka: -1 }, 'delivery_inside_dhaka'],
    [{ hero_rotation_seconds: 1 }, 'hero_rotation_seconds'], [{ hero_animation_speed: 9 }, 'hero_animation_speed'], [{ welcome_enabled: 'yes' }, 'welcome_enabled'],
    [{ currency: 'taka' }, 'currency'], [{ brand_name: '' }, 'brand_name'], [{ business_phone: 'abc' }, 'business_phone'],
    [{ social_links: { facebook: 'javascript:alert(1)' } }, 'social_links.facebook'], [{ social_links: { email: 'nope' } }, 'social_links.email'], [{ social_links: { myspace: 'x' } }, 'social_links.myspace'],
  ] as [object, string][]) await assert.rejects(svc.updateSettings(store, bad), validation(field), JSON.stringify(bad));
  assert.throws(() => validateSettings({}), validation());
});

// ------------------------------------------------------------- hero
test('HERO: add, remove, reorder (and other products keep their place)', async () => {
  const { store, T } = fakeStore({ products: [
    { id: U1, featured_in_hero: true, hero_order: 1, is_active: true }, { id: U2, featured_in_hero: true, hero_order: 2, is_active: true }, { id: U3, featured_in_hero: false, hero_order: 0, is_active: true }] });
  assert.equal((await svc.setHero(store, U3, { featured: true })).hero_order, 3);
  assert.deepEqual((await svc.listHero(store)).map((p) => p.id), [U1, U2, U3]);
  await svc.reorderRows(store, 'products', { ids: [U3, U1, U2], field: 'hero_order' });
  assert.deepEqual((await svc.listHero(store)).map((p) => p.id), [U3, U1, U2]);
  assert.deepEqual(T('products').map((p) => p.hero_order).sort(), [1, 2, 3]);
  assert.equal((await svc.setHero(store, U1, { featured: false })).featured_in_hero, false);
  assert.deepEqual((await svc.listHero(store)).map((p) => p.id), [U3, U2]);
  await assert.rejects(svc.setHero(store, U1, { featured: 'yes' }), validation('featured'));
  await assert.rejects(svc.setHero(store, '44444444-4444-4444-8444-444444444444', { featured: true }), { status: 404 });
});
test('REORDER validation (also used for display order)', async () => {
  const { store } = fakeStore({ products: [{ id: U1, display_order: 5 }, { id: U2, display_order: 9 }] });
  await svc.reorderRows(store, 'products', { ids: [U2, U1] });
  assert.equal((await store.get('products', U2))!.display_order, 5);
  assert.equal((await store.get('products', U1))!.display_order, 9);
  for (const bad of [{ ids: [] }, { ids: [U1, U1] }, { ids: ['x'] }, { ids: [U1], field: 'name' }, null]) await assert.rejects(svc.reorderRows(store, 'products', bad), validation());
  await assert.rejects(svc.reorderRows(store, 'products', { ids: [U1, U3] }), { status: 404 });
  await assert.rejects(svc.reorderRows(store, 'categories', { ids: [U1], field: 'hero_order' }), validation('field'));
});

// ------------------------------------------------------------- gallery / model / storage
test('GALLERY and 3D MODEL management', async () => {
  const { store, T } = fakeStore({ products: [{ id: U1 }] });
  const a = await svc.addGalleryImage(store, U1, { url: 'https://x.test/1.webp', thumb_url: 'https://x.test/1-thumb.webp', alt_text: 'front' });
  const b = await svc.addGalleryImage(store, U1, { url: 'https://x.test/2.webp' });
  assert.deepEqual([a.sort_order, b.sort_order], [0, 1]);
  await svc.reorderGallery(store, U1, { ids: [b.id, a.id] });
  assert.deepEqual([T('product_images').find((i) => i.id === b.id)!.sort_order, T('product_images').find((i) => i.id === a.id)!.sort_order], [0, 1]);
  await assert.rejects(svc.reorderGallery(store, U1, { ids: [a.id] }), validation('ids'));
  await assert.rejects(svc.addGalleryImage(store, U1, { url: 'not-a-url' }), validation('url'));
  await svc.removeGalleryImage(store, a.id);
  assert.equal(T('product_images').length, 1);
  assert.deepEqual(await svc.setModel(store, U1, { model_url: 'https://x.test/m.glb', format: 'glb' }), { model_url: 'https://x.test/m.glb', format: 'glb' });
  await svc.setModel(store, U1, { model_url: 'https://x.test/m2.glb', format: 'glb' });
  assert.equal(T('product_models').length, 1);                                                    // replace, not duplicate
  await assert.rejects(svc.setModel(store, U1, { model_url: 'https://x.test/m.obj', format: 'obj' }), validation('format'));
  await svc.removeModel(store, U1);
  assert.equal(T('product_models').length, 0);
});
test('STORAGE delete only accepts TEXO storage URLs', async () => {
  const base = 'https://abc.supabase.co';
  const { store, removedFiles } = fakeStore();
  await svc.deleteUpload(store, `${base}/storage/v1/object/public/product-images/products/u1.webp`, base);
  assert.deepEqual(removedFiles[0], { bucket: 'product-images', paths: ['products/u1.webp', 'products/u1-thumb.webp'] });
  await svc.deleteUpload(store, `${base}/storage/v1/object/public/product-models/m.glb`, base);
  assert.deepEqual(removedFiles[1].paths, ['m.glb']);
  for (const bad of ['https://evil.test/storage/v1/object/public/product-images/a.webp', `${base}/storage/v1/object/public/secret-bucket/a.webp`,
    `${base}/storage/v1/object/public/product-images/../../x`, `${base}/storage/v1/object/public/product-images/`, 'https://abc.supabase.co.evil.test/x'])
    assert.throws(() => parseStorageUrl(bad, base), { code: 'INVALID_URL' }, bad);
});

// ------------------------------------------------------------- uploads (validation)
test('IMAGE upload validation: type, size, empty', () => {
  const jpeg = Buffer.concat([Buffer.from([0xff, 0xd8, 0xff, 0xe0]), Buffer.alloc(64)]);
  assert.equal(assertImageUpload(jpeg), 'jpeg');
  assert.throws(() => assertImageUpload(Buffer.concat([Buffer.from([0xff, 0xd8, 0xff]), Buffer.alloc(5 * 1024 * 1024)])), { status: 413, code: 'FILE_TOO_LARGE' });
  assert.throws(() => assertImageUpload(Buffer.alloc(0)), { code: 'INVALID_FILE' });
  assert.throws(() => assertImageUpload(Buffer.from('<svg onload=alert(1)></svg>' + ' '.repeat(40))), { code: 'INVALID_FILE' });
  assert.throws(() => assertImageUpload(Buffer.from('MZ' + 'x'.repeat(60))), { code: 'INVALID_FILE' });
  assert.throws(() => assertImageUpload(Buffer.from('GIF89a' + 'x'.repeat(60))), { code: 'INVALID_FILE' });
});
test('3D MODEL upload validation: format, size, content', () => {
  const glb = Buffer.alloc(32); glb.write('glTF', 0, 'ascii'); glb.writeUInt32LE(2, 4);
  assert.equal(assertModelUpload(glb, 'Chair.GLB'), 'glb');
  assert.equal(assertModelUpload(Buffer.from('{"asset":{"version":"2.0"}}'), 'a.gltf'), 'gltf');
  const big = Buffer.alloc(15 * 1024 * 1024 + 1); big.write('glTF', 0, 'ascii'); big.writeUInt32LE(2, 4);
  assert.throws(() => assertModelUpload(big, 'big.glb'), { status: 413 });
  assert.throws(() => assertModelUpload(Buffer.alloc(32), 'fake.glb'), { code: 'INVALID_FILE' });   // right extension, wrong content
  assert.throws(() => assertModelUpload(glb, 'model.fbx'), { code: 'INVALID_FILE' });
  assert.throws(() => assertModelUpload(glb, 'model.glb.exe'), { code: 'INVALID_FILE' });
  assert.throws(() => assertModelUpload(Buffer.alloc(0), 'a.glb'), { code: 'INVALID_FILE' });
});

test('STATS pass-through', async () => {
  const { store, calls } = fakeStore();
  assert.deepEqual(await svc.getStats(store), { orders: 3 });
  assert.equal(calls[0].fn, 'admin_stats');
});

// ------------------------------------------------------------- discount % is a REAL input + order button
test('DISCOUNT %: admin can set the percentage and it becomes the real sale price', async () => {
  const { store } = fakeStore();
  const p = await svc.createProduct(store, { name: 'Pct', sku: 'PCT-1', regular_price: 2490, discount_percent: 28 });
  assert.equal(p.sale_price, 1792.8);                         // 2490 - 28%
  const p2 = await svc.createProduct(store, { name: 'Half', sku: 'PCT-2', regular_price: 1000, discount_percent: 50 });
  assert.equal(p2.sale_price, 500);
  assert.equal((await svc.updateProduct(store, p2.id, { discount_percent: 10 })).sale_price, 900);
  assert.equal((await svc.updateProduct(store, p2.id, { regular_price: 2000 })).sale_price, 900);   // keeps the sale price it already has
  assert.equal((await svc.updateProduct(store, p2.id, { discount_percent: 0 })).sale_price, null);  // 0% = no discount
  for (const bad of [100, -5, 150, 12.5]) await assert.rejects(svc.createProduct(store, { name: 'x', sku: `B${bad}`, regular_price: 100, discount_percent: bad }), validation('discount_percent'));
});
test('ORDER BUTTON: admin can rename or switch it off per product', async () => {
  const { store } = fakeStore();
  const p = await svc.createProduct(store, product({ order_button_text: 'Buy today', order_button_enabled: true }));
  assert.equal(p.order_button_text, 'Buy today');
  assert.equal((await svc.updateProduct(store, p.id, { order_button_enabled: false })).order_button_enabled, false);
  assert.equal((await svc.updateProduct(store, p.id, { order_button_text: null })).order_button_text, null);
  await assert.rejects(svc.updateProduct(store, p.id, { order_button_text: 'x'.repeat(31) }), validation('order_button_text'));
  await assert.rejects(svc.updateProduct(store, p.id, { order_button_enabled: 'no' }), validation('order_button_enabled'));
});
