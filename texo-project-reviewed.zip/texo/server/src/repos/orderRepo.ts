import { supabaseAdmin as db } from '../lib/supabase.ts';
import type { OrderDeps } from '../services/orderService.ts';
import { listActiveOffers } from './offerRepo.ts';

export const orderRepo: OrderDeps = {
  async getProducts(ids) {
    const { data, error } = await db.from('products')
      .select('id,slug,name,category_id,regular_price,sale_price,stock,stock_status,is_active,thumb_url,main_image_url,order_button_enabled').in('id', ids);
    if (error) throw error;
    return data ?? [];
  },
  getOffers: () => listActiveOffers(db),
  async getDeliverySettings() {
    const { data, error } = await db.from('site_settings').select('key,value')
      .in('key', ['delivery_inside_dhaka', 'delivery_outside_dhaka', 'free_delivery_threshold']);
    if (error) throw error;
    const m = Object.fromEntries((data ?? []).map((r) => [r.key, Number(r.value)]));
    return {
      insideDhaka: Number.isFinite(m.delivery_inside_dhaka) ? m.delivery_inside_dhaka : 60,
      outsideDhaka: Number.isFinite(m.delivery_outside_dhaka) ? m.delivery_outside_dhaka : 120,
      freeThreshold: Number.isFinite(m.free_delivery_threshold) ? m.free_delivery_threshold : 0,
    };
  },
  async placeOrder(p) {
    const { data, error } = await db.rpc('place_order', { p_order: p.order, p_items: p.items });
    if (error) throw error;
    return data as { id: string; order_no: number };
  },
};
