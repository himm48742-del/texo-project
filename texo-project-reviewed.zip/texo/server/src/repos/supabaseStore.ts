import { AppError } from '../lib/errors.ts';
import { supabaseAdmin as db } from '../lib/supabase.ts';
import type { Store } from '../services/store.ts';

const ok = <T,>(r: { data: T; error: any }): T => { if (r.error) throw r.error; return r.data; };
const range = (q: { page: number; limit: number }) => [(q.page - 1) * q.limit, (q.page - 1) * q.limit + q.limit - 1] as const;

/** The only place admin code touches Supabase (service-role client, server-side only). */
export const supabaseStore: Store = {
  async list(table, o = {}) {
    let q = db.from(table).select('*');
    for (const [k, v] of Object.entries(o.filter ?? {})) q = q.eq(k, v as any);
    if (o.order) q = q.order(o.order[0], { ascending: o.order[1] });
    if (o.limit) q = q.limit(o.limit);
    return ok(await q) ?? [];
  },
  async get(table, id) { return ok(await db.from(table).select('*').eq('id', id).maybeSingle()); },
  async getMany(table, ids) { return ok(await db.from(table).select('*').in('id', ids)) ?? []; },
  async insert(table, row) { return ok(await db.from(table).insert(row).select().single()); },
  async update(table, id, patch) { return ok(await db.from(table).update(patch).eq('id', id).select().maybeSingle()); },
  async remove(table, id) { ok(await db.from(table).delete().eq('id', id)); },
  async upsert(table, rows, onConflict) { ok(await db.from(table).upsert(rows, { onConflict })); },
  async rpc(fn, args) { return ok(await db.rpc(fn, args)); },
  async removeFiles(bucket, paths) {
    const { error } = await db.storage.from(bucket).remove(paths);
    if (error) throw new AppError(502, 'STORAGE_ERROR', 'The file could not be deleted from storage.');
  },
  async searchProducts(q) {
    let sel = db.from('products').select('*, categories(name)', { count: 'exact' });
    if (q.q) sel = sel.or(`name.ilike.%${q.q}%,sku.ilike.%${q.q}%`);
    if (q.categoryId) sel = sel.eq('category_id', q.categoryId);
    if (q.active !== undefined) sel = sel.eq('is_active', q.active);
    if (q.hero) sel = sel.eq('featured_in_hero', true);
    const [a, b] = range(q);
    const r = await sel.order('display_order').order('created_at', { ascending: false }).range(a, b);
    if (r.error) throw r.error;
    return { rows: r.data ?? [], total: r.count ?? 0 };
  },
  async searchOrders(q) {
    let sel = db.from('orders').select('*, order_items(*)', { count: 'exact' });
    if (q.status) sel = sel.eq('status', q.status);
    if (q.q) sel = sel.or(/^\d{1,9}$/.test(q.q) ? `customer_name.ilike.%${q.q}%,phone.ilike.%${q.q}%,order_no.eq.${q.q}` : `customer_name.ilike.%${q.q}%,phone.ilike.%${q.q}%`);
    if (q.phone) sel = sel.ilike('phone', `%${q.phone}%`);
    if (q.from) sel = sel.gte('created_at', `${q.from}T00:00:00Z`);
    if (q.to) sel = sel.lte('created_at', `${q.to}T23:59:59.999Z`);
    if (q.productId) {
      const oi: any[] = ok(await db.from('order_items').select('order_id').eq('product_id', q.productId).limit(5000)) ?? [];
      sel = sel.in('id', oi.map((x) => x.order_id));
    }
    const [a, b] = range(q);
    const r = await sel.order('created_at', { ascending: false }).range(a, b);
    if (r.error) throw r.error;
    return { rows: r.data ?? [], total: r.count ?? 0 };
  },
  async getProductDetail(id) { return ok(await db.from('products').select('*, product_images(*), product_models(*), categories(name)').eq('id', id).maybeSingle()); },
  async getOrder(id) { return ok(await db.from('orders').select('*, order_items(*)').eq('id', id).maybeSingle()); },
};
