import type { SupabaseClient } from '@supabase/supabase-js';
import type { OfferLike } from '../services/pricing.ts';

/** Active offers only; the precise time window is re-checked in pricing.ts (single source of truth). */
export async function listActiveOffers(db: SupabaseClient): Promise<OfferLike[]> {
  const { data, error } = await db.from('offers')
    .select('id,offer_text,is_active,starts_at,ends_at,discount_percent,offer_price,product_id,category_id')
    .eq('is_active', true).limit(500);
  if (error) throw error;
  return (data ?? []) as OfferLike[];
}
