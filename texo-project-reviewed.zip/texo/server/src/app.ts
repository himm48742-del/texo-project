import cors from 'cors';
import express from 'express';
import helmet from 'helmet';
import { env } from './config/env.ts';
import { apiLimiter, errorHandler, notFound } from './middleware.ts';
import admin from './routes/admin.ts';
import adminAuth from './routes/adminAuth.ts';
import publicRoutes from './routes/public.ts';

export function createApp() {
  const app = express();
  app.set('trust proxy', env.TRUST_PROXY);
  app.disable('x-powered-by');
  app.use(helmet());
  const allowed = env.CORS_ORIGIN.split(',').map((s) => s.trim());
  app.use(cors({ origin: allowed, methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'], maxAge: 86400 }));
  app.use(express.json({ limit: '100kb' }));
  app.use('/api', apiLimiter);
  app.get('/api/health', (_req, res) => res.json({ data: { status: 'ok', time: new Date().toISOString() } }));
  app.use('/api/admin', adminAuth); // /login /refresh /me
  app.use('/api/admin', admin);     // everything else here requires admin token
  app.use('/api', publicRoutes);
  app.use(notFound);
  app.use(errorHandler);
  return app;
}
