import { env } from './config/env.ts';
import { createApp } from './app.ts';

createApp().listen(env.PORT, () => console.log(`TEXO API running on http://localhost:${env.PORT}/api  (${env.NODE_ENV})`));
