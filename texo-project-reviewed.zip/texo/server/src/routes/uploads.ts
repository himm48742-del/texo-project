import { Router } from 'express';
import multer from 'multer';
import { AppError } from '../lib/errors.ts';
import { ok, uploadLimiter } from '../middleware.ts';
import { assertModelUpload } from '../services/fileValidation.ts';
import { storeImage, storeModel } from '../services/media.ts';

const r = Router();
const image = multer({ storage: multer.memoryStorage(), limits: { fileSize: 5 * 1024 * 1024, files: 1 } });
const model = multer({ storage: multer.memoryStorage(), limits: { fileSize: 15 * 1024 * 1024, files: 1 } });

// multipart field "file"; optional query ?folder=products|categories|news|offers|site
r.post('/image', uploadLimiter, image.single('file'), async (req, res) => {
  if (!req.file) throw new AppError(400, 'NO_FILE', 'Please choose an image.');
  ok(res, await storeImage(req.file.buffer, String(req.query.folder ?? 'products')));
});

r.post('/model', uploadLimiter, model.single('file'), async (req, res) => {
  if (!req.file) throw new AppError(400, 'NO_FILE', 'Please choose a .glb or .gltf file.');
  const format = assertModelUpload(req.file.buffer, req.file.originalname);
  ok(res, await storeModel(req.file.buffer, format));
});

export default r;
