import { Router } from 'express';
import { loginLimiter, ok, requireAdmin } from '../middleware.ts';
import { authDeps } from '../services/auth.ts';
import { login, refreshSession } from '../services/authService.ts';

const r = Router();
r.post('/login', loginLimiter, async (req, res) => ok(res, await login(authDeps, req.body)));
r.post('/refresh', loginLimiter, async (req, res) => ok(res, await refreshSession(authDeps, req.body)));
r.get('/me', requireAdmin, (_req, res) => ok(res, res.locals.admin));
export default r;
