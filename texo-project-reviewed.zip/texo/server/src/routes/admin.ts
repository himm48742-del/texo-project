import { Router } from 'express';
import { env } from '../config/env.ts';
import { uuidParam } from '../lib/utils.ts';
import { ok, requireAdmin } from '../middleware.ts';
import { supabaseStore as store } from '../repos/supabaseStore.ts';
import * as svc from '../services/adminService.ts';
import type { ResourceName } from '../services/adminService.ts';
import { validateUrlBody } from '../validation/admin.ts';
import uploads from './uploads.ts';

// Thin HTTP layer: every handler = authenticate (router-level) -> validate + act (service) -> respond.
// All validation lives in validation/admin.ts and all rules in services/adminService.ts (unit-tested).
const r = Router();
r.use(requireAdmin); // EVERY route below requires a valid admin token, checked on the server
const created = (res: any, data: unknown) => res.status(201).json({ data });

r.get('/stats', async (_req, res) => ok(res, await svc.getStats(store)));
r.use('/uploads', uploads);
r.delete('/uploads', async (req, res) => ok(res, await svc.deleteUpload(store, validateUrlBody(req.body), env.SUPABASE_URL)));

// ---- categories / offers / news
function resource(name: ResourceName) {
  const c = Router();
  c.get('/', async (_req, res) => ok(res, await svc.listResource(store, name)));
  c.post('/', async (req, res) => created(res, await svc.createResource(store, name, req.body)));
  if (name === 'categories') c.post('/reorder', async (req, res) => ok(res, await svc.reorderRows(store, 'categories', req.body)));
  if (name === 'offers') c.post('/preview', async (req, res) => ok(res, await svc.previewOffer(store, req.body)));
  c.get('/:id', async (req, res) => ok(res, await svc.getResource(store, name, uuidParam(req.params.id))));
  c.patch('/:id', async (req, res) => ok(res, await svc.updateResource(store, name, uuidParam(req.params.id), req.body)));
  c.delete('/:id', async (req, res) => ok(res, await svc.deleteResource(store, name, uuidParam(req.params.id))));
  return c;
}
r.use('/categories', resource('categories'));
r.use('/offers', resource('offers'));
r.use('/news', resource('news'));

// ---- products
r.get('/products', async (req, res) => { const { rows, total } = await svc.listProducts(store, req.query as any); ok(res, rows, { total, page: Number(req.query.page) || 1 }); });
r.post('/products', async (req, res) => created(res, await svc.createProduct(store, req.body)));
r.post('/products/reorder', async (req, res) => ok(res, await svc.reorderRows(store, 'products', req.body)));
r.get('/products/:id', async (req, res) => ok(res, await svc.getProduct(store, uuidParam(req.params.id))));
r.patch('/products/:id', async (req, res) => ok(res, await svc.updateProduct(store, uuidParam(req.params.id), req.body)));
r.delete('/products/:id', async (req, res) => ok(res, await svc.deleteProduct(store, uuidParam(req.params.id))));
r.post('/products/:id/duplicate', async (req, res) => created(res, await svc.duplicateProduct(store, uuidParam(req.params.id))));
r.post('/products/:id/hero', async (req, res) => ok(res, await svc.setHero(store, uuidParam(req.params.id), req.body)));
r.post('/products/:id/images', async (req, res) => created(res, await svc.addGalleryImage(store, uuidParam(req.params.id), req.body)));
r.put('/products/:id/images/order', async (req, res) => ok(res, await svc.reorderGallery(store, uuidParam(req.params.id), req.body)));
r.delete('/product-images/:id', async (req, res) => ok(res, await svc.removeGalleryImage(store, uuidParam(req.params.id))));
r.put('/products/:id/model', async (req, res) => ok(res, await svc.setModel(store, uuidParam(req.params.id), req.body)));
r.delete('/products/:id/model', async (req, res) => ok(res, await svc.removeModel(store, uuidParam(req.params.id))));
r.get('/hero', async (_req, res) => ok(res, await svc.listHero(store)));

// ---- orders
r.get('/orders', async (req, res) => { const { rows, total } = await svc.listOrders(store, req.query as any); ok(res, rows, { total, page: Number(req.query.page) || 1 }); });
r.get('/orders/:id', async (req, res) => ok(res, await svc.getOrder(store, uuidParam(req.params.id))));
r.patch('/orders/:id/status', async (req, res) => ok(res, await svc.setOrderStatus(store, uuidParam(req.params.id), req.body)));

// ---- settings
r.get('/settings', async (_req, res) => ok(res, await svc.getSettings(store)));
r.put('/settings', async (req, res) => ok(res, await svc.updateSettings(store, req.body)));

export default r;
