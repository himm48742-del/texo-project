import { Router } from 'express';
import { supabasePublic as db } from '../lib/supabase.ts';
import { AppError } from '../lib/errors.ts';
import { int, sanitizeSearch } from '../lib/utils.ts';
import { ok, orderLimiter, publicCache } from '../middleware.ts';
import { createOrder, parseOrderInput } from '../services/orderService.ts';
import { orderRepo } from '../repos/orderRepo.ts';
import { listActiveOffers } from '../repos/offerRepo.ts';
import { isOfferLive, priceView } from '../services/pricing.ts';
import { quoteOrder, parseQuoteInput } from '../services/orderService.ts';

const r = Router();

const LIST = 'id,slug,sku,name,short_desc,category_id,regular_price,sale_price,discount_amount,discount_percent,offer_text,currency,stock,stock_status,main_image_url,thumb_url,is_featured,featured_in_hero,display_order,order_button_enabled,order_button_text,categories(name,slug),product_models(model_url,format)';
const HERO = 'id,slug,name,category_id,short_desc,regular_price,sale_price,discount_amount,discount_percent,offer_text,currency,stock_status,main_image_url,thumb_url,product_models(model_url,format)';
// Adds the customer-facing `price` block (regular / final / save / percent) using the SAME rules as checkout.
async function withPrice<T extends Record<string, any>>(rows: T[]) {
  if (!rows.length) return rows.map((p) => ({ ...p, price: null }));
  const offers = await listActiveOffers(db);
  const now = new Date();
  return rows.map((p) => {
    const { product_models, ...rest } = p as any;
    return { ...rest, ...(product_models !== undefined ? { model: one(product_models) } : {}), price: priceView(p as any, offers, now) };
  });
}
const one = <T,>(v: T | T[] | null | undefined): T | null => (Array.isArray(v) ? v[0] ?? null : v ?? null);

r.get('/settings', publicCache(60), async (_req, res) => {
  const { data, error } = await db.from('site_settings').select('key,value').not('key', 'like', 'private.%');
  if (error) throw error;
  ok(res, Object.fromEntries((data ?? []).map((s) => [s.key, s.value])));
});

r.get('/categories', publicCache(60), async (_req, res) => {
  const { data, error } = await db.from('categories').select('id,name,slug,icon_url,display_order').eq('is_active', true).order('display_order');
  if (error) throw error;
  ok(res, data);
});

// ?category=<slug>  ?view=new|featured|offers  ?sort=order|newest|name  ?page= ?limit=(max 60)
r.get('/products', publicCache(60), async (req, res) => {
  const page = int(req.query.page, 1, 1, 100000);
  const limit = int(req.query.limit, 24, 1, 60);
  const category = String(req.query.category ?? '');
  const view = String(req.query.view ?? '');
  let q = db.from('products').select(LIST, { count: 'exact' }).eq('is_active', true);
  if (category && category !== 'all') {
    const { data: c } = await db.from('categories').select('id').eq('slug', category).eq('is_active', true).maybeSingle();
    if (!c) return ok(res, [], { page, limit, total: 0 });
    q = q.eq('category_id', c.id);
  }
  if (view === 'featured') q = q.eq('is_featured', true);
  if (view === 'offers') q = q.not('sale_price', 'is', null);
  const sort = view === 'new' ? 'newest' : String(req.query.sort ?? 'order');
  q = sort === 'newest' ? q.order('created_at', { ascending: false })
    : sort === 'name' ? q.order('name') : q.order('display_order').order('created_at', { ascending: false });
  const from = (page - 1) * limit;
  const { data, error, count } = await q.range(from, from + limit - 1);
  if (error) throw error;
  ok(res, await withPrice(data ?? []), { page, limit, total: count ?? 0 });
});

// Hero queue, loaded in small batches. nextOffset wraps to 0 so the rotation loops forever.
r.get('/hero', publicCache(30), async (req, res) => {
  const offset = int(req.query.offset, 0, 0, 1_000_000);
  const limit = int(req.query.limit, 6, 1, 20);
  const { data, error, count } = await db.from('products').select(HERO, { count: 'exact' })
    .eq('is_active', true).eq('featured_in_hero', true).order('hero_order').order('created_at')
    .range(offset, offset + limit - 1);
  if (error) throw error;
  const total = count ?? 0;
  const items = await withPrice((data ?? []).map((p: any) => ({ ...p, product_models: undefined, model: one(p.product_models) })));
  ok(res, items, { total, nextOffset: offset + items.length >= total ? 0 : offset + items.length });
});

r.get('/products/:slug', publicCache(60), async (req, res) => {
  const { data, error } = await db.from('products')
    .select('*, categories(id,name,slug), product_images(id,url,thumb_url,alt_text,sort_order), product_models(model_url,format)')
    .eq('slug', req.params.slug).eq('is_active', true).maybeSingle();
  if (error) throw error;
  if (!data) throw new AppError(404, 'PRODUCT_NOT_FOUND', 'This product could not be found.');
  const p: any = data;
  const images = [...(p.product_images ?? [])].sort((a: any, b: any) => a.sort_order - b.sort_order);
  let related: unknown[] = [];
  if (p.category_id) {
    const rel = await db.from('products').select(LIST).eq('is_active', true).eq('category_id', p.category_id).neq('id', p.id).order('display_order').limit(4);
    related = await withPrice(rel.data ?? []);
  }
  const [priced] = await withPrice([p]);
  ok(res, { ...priced, product_images: undefined, product_models: undefined, images, model: one(p.product_models), related });
});

r.get('/search', publicCache(30), async (req, res) => {
  const term = sanitizeSearch(String(req.query.q ?? ''));
  const limit = int(req.query.limit, 12, 1, 30);
  if (term.length < 2) return ok(res, []);
  const { data: cats } = await db.from('categories').select('id').eq('is_active', true).ilike('name', `%${term}%`);
  const filters = [`name.ilike.%${term}%`, `sku.ilike.%${term}%`];
  const ids = (cats ?? []).map((c) => c.id);
  if (ids.length) filters.push(`category_id.in.(${ids.join(',')})`);
  const { data, error } = await db.from('products')
    .select('id,slug,sku,name,category_id,regular_price,sale_price,discount_percent,thumb_url,main_image_url,stock_status,categories(name,slug)')
    .eq('is_active', true).or(filters.join(',')).order('display_order').limit(limit);
  if (error) throw error;
  ok(res, await withPrice(data ?? []));
});

// Same rule as checkout (isOfferLive): active, started, not ended. No fragile double-.or() query.
r.get('/offers', publicCache(60), async (_req, res) => {
  const now = new Date();
  const { data, error } = await db.from('offers').select('*').eq('is_active', true);
  if (error) throw error;
  const live = (data ?? []).filter((o: any) => isOfferLive(o, now)).sort((a: any, b: any) => (a.ends_at ?? '9').localeCompare(b.ends_at ?? '9'));
  ok(res, live);
});

r.get('/news', publicCache(60), async (req, res) => {
  const limit = int(req.query.limit, 6, 1, 50);
  const { data, error } = await db.from('news').select('id,slug,title,description,thumbnail_url,published_at')
    .eq('is_published', true).lte('published_at', new Date().toISOString()).order('published_at', { ascending: false }).limit(limit);
  if (error) throw error;
  ok(res, data);
});
r.get('/news/:slug', publicCache(60), async (req, res) => {
  const { data, error } = await db.from('news').select('*').eq('slug', req.params.slug).eq('is_published', true).maybeSingle();
  if (error) throw error;
  if (!data) throw new AppError(404, 'NOT_FOUND', 'Article not found.');
  ok(res, data);
});

// Checkout preview: same calculation as the real order. Returns authoritative prices, discount, delivery, total.
r.post('/orders/quote', async (req, res) => {
  const { items, district } = parseQuoteInput(req.body);
  ok(res, await quoteOrder(items, district, orderRepo));
});

// Customer order. Body prices are never read - see services/orderService.ts
r.post('/orders', orderLimiter, async (req, res) => {
  const result = await createOrder(parseOrderInput(req.body), orderRepo);
  res.status(201).json({ data: result });
});

export default r;
