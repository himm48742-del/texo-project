import { randomUUID } from 'node:crypto';
import sharp from 'sharp';
import { AppError } from '../lib/errors.ts';
import { supabaseAdmin as db } from '../lib/supabase.ts';
import { assertImageUpload } from './fileValidation.ts';
import type { ModelFormat } from './fileValidation.ts';

export const IMAGE_FOLDERS = ['products', 'categories', 'news', 'offers', 'site'] as const;

async function put(bucket: string, path: string, body: Buffer, contentType: string) {
  const { error } = await db.storage.from(bucket).upload(path, body, { contentType, cacheControl: '31536000', upsert: false });
  if (error) throw new AppError(502, 'STORAGE_ERROR', 'The file could not be saved. Please try again.');
  return db.storage.from(bucket).getPublicUrl(path).data.publicUrl;
}

/** Validates, re-encodes (strips metadata/any hidden payload), creates 1600px WebP + 400px thumbnail. */
export async function storeImage(buf: Buffer, folder: string) {
  if (!IMAGE_FOLDERS.includes(folder as any)) throw new AppError(400, 'INVALID_FOLDER', 'Invalid upload folder.');
  assertImageUpload(buf);
  let main: Buffer, thumb: Buffer;
  try {
    const img = () => sharp(buf, { limitInputPixels: 50_000_000, failOn: 'error' }).rotate();
    main = await img().resize({ width: 1600, height: 1600, fit: 'inside', withoutEnlargement: true }).webp({ quality: 82 }).toBuffer();
    thumb = await img().resize({ width: 400, height: 400, fit: 'inside', withoutEnlargement: true }).webp({ quality: 75 }).toBuffer();
  } catch {
    throw new AppError(400, 'INVALID_FILE', 'This image is damaged or too large to process.');
  }
  const bucket = folder === 'products' ? 'product-images' : 'site-media';
  const id = randomUUID();
  const [url, thumb_url] = await Promise.all([
    put(bucket, `${folder}/${id}.webp`, main, 'image/webp'),
    put(bucket, `${folder}/${id}-thumb.webp`, thumb, 'image/webp'),
  ]);
  return { url, thumb_url, bytes: main.length };
}

export async function storeModel(buf: Buffer, format: ModelFormat) {
  const url = await put('product-models', `${randomUUID()}.${format}`, buf, format === 'glb' ? 'model/gltf-binary' : 'model/gltf+json');
  return { model_url: url, format };
}
