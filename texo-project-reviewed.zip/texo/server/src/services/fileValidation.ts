import { AppError } from '../lib/errors.ts';

export type ImageKind = 'jpeg' | 'png' | 'webp' | 'avif';

/** Detects real file type from magic bytes (the filename/MIME sent by the browser is not trusted). */
export function detectImageType(b: Buffer): ImageKind | null {
  if (b.length < 16) return null;
  if (b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return 'jpeg';
  if (b.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return 'png';
  if (b.subarray(0, 4).toString('ascii') === 'RIFF' && b.subarray(8, 12).toString('ascii') === 'WEBP') return 'webp';
  if (b.subarray(4, 8).toString('ascii') === 'ftyp' && ['avif', 'avis'].includes(b.subarray(8, 12).toString('ascii'))) return 'avif';
  return null;
}

export type ModelFormat = 'glb' | 'gltf';

export function validateModel(b: Buffer, filename: string): ModelFormat {
  const ext = filename.toLowerCase().split('.').pop();
  if (ext === 'glb') {
    if (b.length < 20 || b.subarray(0, 4).toString('ascii') !== 'glTF' || b.readUInt32LE(4) !== 2)
      throw new AppError(400, 'INVALID_FILE', 'This is not a valid .glb (glTF 2.0) file.');
    return 'glb';
  }
  if (ext === 'gltf') {
    try {
      const j = JSON.parse(b.toString('utf8'));
      if (typeof j?.asset?.version !== 'string') throw new Error('no asset');
    } catch {
      throw new AppError(400, 'INVALID_FILE', 'This is not a valid .gltf file.');
    }
    return 'gltf';
  }
  throw new AppError(400, 'INVALID_FILE', 'Only .glb or .gltf 3D models are allowed.');
}

export const MAX_IMAGE_BYTES = 5 * 1024 * 1024;
export const MAX_MODEL_BYTES = 15 * 1024 * 1024;
/** Server-side gate for image uploads: size first, then real content type (never the browser-supplied name/MIME). */
export function assertImageUpload(b: Buffer): ImageKind {
  if (b.length === 0) throw new AppError(400, 'INVALID_FILE', 'The file is empty.');
  if (b.length > MAX_IMAGE_BYTES) throw new AppError(413, 'FILE_TOO_LARGE', 'Images must be 5 MB or smaller.');
  const kind = detectImageType(b);
  if (!kind) throw new AppError(400, 'INVALID_FILE', 'Only JPG, PNG, WEBP or AVIF images are allowed.');
  return kind;
}
export function assertModelUpload(b: Buffer, filename: string): ModelFormat {
  if (b.length === 0) throw new AppError(400, 'INVALID_FILE', 'The file is empty.');
  if (b.length > MAX_MODEL_BYTES) throw new AppError(413, 'FILE_TOO_LARGE', '3D models must be 15 MB or smaller.');
  return validateModel(b, filename);
}

const BUCKETS = ['product-images', 'product-models', 'site-media'];
/** Turns one of OUR public storage URLs into {bucket, path}. Anything else (other sites, path tricks) is rejected. */
export function parseStorageUrl(url: string, supabaseUrl: string): { bucket: string; path: string } {
  const prefix = `${supabaseUrl.replace(/\/+$/, '')}/storage/v1/object/public/`;
  if (!url.startsWith(prefix)) throw new AppError(400, 'INVALID_URL', 'This file is not stored in TEXO storage.');
  const rest = decodeURIComponent(url.slice(prefix.length).split('?')[0]);
  const i = rest.indexOf('/');
  const bucket = rest.slice(0, i), path = rest.slice(i + 1);
  if (i < 1 || !BUCKETS.includes(bucket) || !path || path.includes('..') || path.startsWith('/'))
    throw new AppError(400, 'INVALID_URL', 'This file is not stored in TEXO storage.');
  return { bucket, path };
}
