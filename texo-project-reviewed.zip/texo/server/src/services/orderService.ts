import { AppError } from '../lib/errors.ts';
import { isUuid } from '../lib/utils.ts';
import { computeTotals, effectivePrice, zoneFromDistrict } from './pricing.ts';
import type { DeliverySettings, OfferLike, PriceSource, Zone } from './pricing.ts';

export interface OrderItemInput { productId: string; quantity: number }
export interface OrderInput {
  customer: { name: string; phone: string; address: string; district: string; area: string | null; notes: string | null };
  items: OrderItemInput[];
  source: 'web' | 'whatsapp';
}
export interface DbProduct {
  id: string; slug?: string; name: string; category_id: string | null;
  regular_price: number | string; sale_price: number | string | null;
  stock: number; stock_status: string; is_active: boolean;
  thumb_url?: string | null; main_image_url?: string | null; order_button_enabled?: boolean;
}
export interface PlaceOrderPayload {
  order: {
    customer_name: string; phone: string; address: string; district: string; area: string | null;
    delivery_zone: string; notes: string | null; subtotal: number; delivery_charge: number; total: number; source: string;
  };
  items: { product_id: string; product_name: string; unit_regular: number; unit_price: number; quantity: number }[];
}
export interface OrderDeps {
  getProducts(ids: string[]): Promise<DbProduct[]>;
  getOffers(): Promise<OfferLike[]>;
  getDeliverySettings(): Promise<DeliverySettings>;
  placeOrder(p: PlaceOrderPayload): Promise<{ id: string; order_no: number }>;
}
type FieldError = { field: string; message: string };

/** Accepts 01XXXXXXXXX, +8801XXXXXXXXX, 8801XXXXXXXXX. Returns 11-digit local format or null. */
export function normalizePhone(raw: unknown): string | null {
  if (typeof raw !== 'string') return null;
  let p = raw.replace(/[\s\-()]/g, '');
  if (p.startsWith('+88')) p = p.slice(3);
  else if (p.startsWith('88') && p.length === 13) p = p.slice(2);
  return /^01[3-9]\d{8}$/.test(p) ? p : null;
}

const str = (v: unknown, max: number) => (typeof v === 'string' ? v.trim().slice(0, max) : '');

/** Only productId + quantity are ever read from an item. Every other key (price, offerPrice, discount...) is dropped. */
function parseItems(raw: unknown, errors: FieldError[]): OrderItemInput[] {
  const rawItems = Array.isArray(raw) ? raw : [];
  if (rawItems.length < 1 || rawItems.length > 20) errors.push({ field: 'items', message: 'Your order must contain 1 to 20 products.' });
  const merged = new Map<string, number>();
  rawItems.forEach((it: any, i: number) => {
    const qty = Number(it?.quantity);
    if (!isUuid(it?.productId)) errors.push({ field: `items.${i}.productId`, message: 'Invalid product.' });
    else if (!Number.isInteger(qty) || qty < 1 || qty > 20) errors.push({ field: `items.${i}.quantity`, message: 'Quantity must be between 1 and 20.' });
    else merged.set(it.productId, (merged.get(it.productId) ?? 0) + qty);
  });
  for (const q of merged.values()) if (q > 20) errors.push({ field: 'items', message: 'Maximum 20 units per product.' });
  return [...merged].map(([productId, quantity]) => ({ productId, quantity }));
}

export function parseQuoteInput(body: unknown): { items: OrderItemInput[]; district: string | null } {
  const b = (body ?? {}) as Record<string, any>;
  const errors: FieldError[] = [];
  const items = parseItems(b.items, errors);
  if (errors.length) throw new AppError(400, 'VALIDATION_ERROR', 'Please check your order.', errors);
  return { items, district: str(b.district, 60) || null };
}

export function parseOrderInput(body: unknown): OrderInput {
  const b = (body ?? {}) as Record<string, any>;
  const c = (b.customer ?? {}) as Record<string, unknown>;
  const errors: FieldError[] = [];
  const name = str(c.name, 100);
  const address = str(c.address, 300);
  const district = str(c.district, 60);
  const phone = normalizePhone(c.phone);
  if (name.length < 2) errors.push({ field: 'customer.name', message: 'Please enter your name.' });
  if (!phone) errors.push({ field: 'customer.phone', message: 'Please enter a valid Bangladeshi mobile number (e.g. 01XXXXXXXXX).' });
  if (address.length < 8) errors.push({ field: 'customer.address', message: 'Please enter your full address.' });
  if (!district) errors.push({ field: 'customer.district', message: 'Please select your district.' });
  const items = parseItems(b.items, errors);
  if (errors.length) throw new AppError(400, 'VALIDATION_ERROR', 'Please check the highlighted fields.', errors);
  return {
    customer: { name, phone: phone!, address, district, area: str(c.area, 100) || null, notes: str(c.notes, 500) || null },
    items,
    source: b.channel === 'whatsapp' ? 'whatsapp' : 'web',
  };
}

export interface QuoteLine {
  productId: string; slug: string | null; name: string; image: string | null; quantity: number;
  regularPrice: number; unitPrice: number; lineTotal: number; priceSource: PriceSource; offerText: string | null;
}

/** The ONE place a payable amount is computed. Used by both the checkout preview (/orders/quote) and the real order. */
export async function quoteOrder(items: OrderItemInput[], district: string | null, deps: OrderDeps, now: Date = new Date()) {
  const [products, offers, settings] = await Promise.all([
    deps.getProducts(items.map((i) => i.productId)), deps.getOffers(), deps.getDeliverySettings(),
  ]);
  const byId = new Map(products.map((p) => [p.id, p]));
  const lines: QuoteLine[] = [];
  for (const it of items) {
    const p = byId.get(it.productId);
    if (!p || !p.is_active) throw new AppError(404, 'PRODUCT_NOT_FOUND', 'One of the products is no longer available.');
    if (p.order_button_enabled === false) throw new AppError(409, 'ORDER_DISABLED', `"${p.name}" cannot be ordered online right now.`);
    if (p.stock_status === 'out_of_stock' || p.stock < it.quantity)
      throw new AppError(409, 'OUT_OF_STOCK', `Sorry, "${p.name}" does not have enough stock (${Math.max(p.stock, 0)} left).`);
    const e = effectivePrice(p, offers, now);
    if (!(e.unit > 0) || e.unit > e.regular)   // never allow free / negative / above-regular prices
      throw new AppError(409, 'PRICE_UNAVAILABLE', `"${p.name}" cannot be ordered right now. Please contact us.`);
    lines.push({
      productId: p.id, slug: p.slug ?? null, name: p.name, image: p.thumb_url ?? p.main_image_url ?? null, quantity: it.quantity,
      regularPrice: e.regular / 100, unitPrice: e.unit / 100, lineTotal: (e.unit * it.quantity) / 100,
      priceSource: e.source, offerText: e.offer?.offer_text ?? null,
    });
  }
  const zone: Zone | null = district ? zoneFromDistrict(district) : null;
  const cents = lines.map((l) => ({ regular: Math.round(l.regularPrice * 100), unit: Math.round(l.unitPrice * 100), quantity: l.quantity }));
  const deliveryPending = zone === null;
  const t = computeTotals(cents, deliveryPending ? { insideDhaka: 0, outsideDhaka: 0, freeThreshold: 0 } : settings, zone ?? 'inside_dhaka');
  return { lines, ...t, deliveryZone: zone, deliveryPending, freeDeliveryThreshold: settings.freeThreshold };
}

export async function createOrder(input: OrderInput, deps: OrderDeps, now: Date = new Date()) {
  const q = await quoteOrder(input.items, input.customer.district, deps, now);
  const saved = await deps.placeOrder({
    order: {
      customer_name: input.customer.name, phone: input.customer.phone, address: input.customer.address,
      district: input.customer.district, area: input.customer.area, delivery_zone: q.deliveryZone!, notes: input.customer.notes,
      subtotal: q.subtotal, delivery_charge: q.deliveryCharge, total: q.total, source: input.source,
    },
    items: q.lines.map((l) => ({ product_id: l.productId, product_name: l.name, unit_regular: l.regularPrice, unit_price: l.unitPrice, quantity: l.quantity })),
  });
  return { orderNo: saved.order_no, items: q.lines, ...q };
}
