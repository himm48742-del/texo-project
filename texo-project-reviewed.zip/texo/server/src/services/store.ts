import type { OrderQuery, ProductQuery, Row } from '../validation/admin.ts';

/** Everything the admin services need from the database/storage. Real: repos/supabaseStore.ts. Tests: in-memory fake. */
export interface Store {
  list(table: string, o?: { filter?: Row; order?: [string, boolean]; limit?: number }): Promise<Row[]>;
  get(table: string, id: string): Promise<Row | null>;
  getMany(table: string, ids: string[]): Promise<Row[]>;
  insert(table: string, row: Row): Promise<Row>;
  update(table: string, id: string, patch: Row): Promise<Row | null>;
  remove(table: string, id: string): Promise<void>;
  upsert(table: string, rows: Row[], onConflict: string): Promise<void>;
  rpc<T = any>(fn: string, args: Row): Promise<T>;
  removeFiles(bucket: string, paths: string[]): Promise<void>;
  searchProducts(q: ProductQuery): Promise<{ rows: Row[]; total: number }>;
  searchOrders(q: OrderQuery): Promise<{ rows: Row[]; total: number }>;
  getProductDetail(id: string): Promise<Row | null>;
  getOrder(id: string): Promise<Row | null>;
}
