import { newAnonClient, supabaseAdmin } from '../lib/supabase.ts';
import type { AdminCheck, AuthDeps, Session } from './authService.ts';

const toSession = (s: any): Session => ({ access_token: s.access_token, refresh_token: s.refresh_token, expires_at: s.expires_at });

/** Real implementation: Supabase Auth verifies the JWT, then admin_users decides who is an admin. */
export const authDeps: AuthDeps = {
  async signIn(email, password) {
    const { data, error } = await newAnonClient().auth.signInWithPassword({ email, password });
    return error || !data.session ? null : toSession(data.session);
  },
  async refresh(refreshToken) {
    const { data, error } = await newAnonClient().auth.refreshSession({ refresh_token: refreshToken });
    return error || !data.session ? null : toSession(data.session);
  },
  async verify(token): Promise<AdminCheck> {
    const { data, error } = await supabaseAdmin.auth.getUser(token);
    if (error || !data.user) return { ok: false, reason: 'invalid' };
    const { data: row, error: e2 } = await supabaseAdmin.from('admin_users').select('user_id').eq('user_id', data.user.id).maybeSingle();
    if (e2) throw e2;
    return row ? { ok: true, user: { id: data.user.id, email: data.user.email } } : { ok: false, reason: 'forbidden' };
  },
};
