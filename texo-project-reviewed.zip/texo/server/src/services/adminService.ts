// Admin business logic. Pure with respect to the database: everything goes through the Store interface.
import { AppError } from '../lib/errors.ts';
import { slugify, uuidParam } from '../lib/utils.ts';
import {
  fail, parseOrderQuery, parseProductQuery, priceIssues, validateBool, validateCategory, validateImageAttach, validateModelAttach, validateNews,
  validateOffer, validateOfferDraft, validateProduct, validateReorder, validateSettings, validateStatus,
} from '../validation/admin.ts';
import type { Issue, Row } from '../validation/admin.ts';
import { effectivePrice, isOfferLive, priceView, salePriceFromPercent } from './pricing.ts';
import type { OfferLike } from './pricing.ts';
import { parseStorageUrl } from './fileValidation.ts';
import type { Store } from './store.ts';

const notFound = (what: string) => new AppError(404, 'NOT_FOUND', `${what} not found.`);
const autoStatus = (stock: number) => (stock <= 0 ? 'out_of_stock' : stock <= 5 ? 'low_stock' : 'in_stock');

/** Next free position for a display/hero order column. */
async function nextOrder(s: Store, table: string, field: string): Promise<number> {
  const [top] = await s.list(table, { order: [field, false], limit: 1 });
  return Number(top?.[field] ?? 0) + 1;
}

// ------------------------------------------------------------------ products
/**
 * Discount % is a real input: "28" sets the sale price to 28% below the regular price.
 * If the admin sends a sale price too, the sale price wins and the percent is recalculated by the database.
 * The stored discount_percent column is always calculated from the two prices, so it can never disagree with them.
 */
function applyPercent(v: Row, regular: unknown): void {
  const pct = v.discount_percent;
  delete v.discount_percent;
  v.discount_manual = false;
  if (pct === undefined || v.sale_price != null) return;
  v.sale_price = pct === 0 ? null : salePriceFromPercent(Number(regular), pct);
}
export async function createProduct(s: Store, body: unknown) {
  const v = validateProduct(body, false);
  applyPercent(v, v.regular_price);
  const issues = priceIssues(v.regular_price, v.sale_price);
  if (issues.length) throw fail(issues);
  v.slug ??= slugify(v.name);
  v.stock ??= 0;
  v.stock_status ??= autoStatus(v.stock);
  v.display_order ??= await nextOrder(s, 'products', 'display_order');
  if (v.featured_in_hero && v.hero_order === undefined) v.hero_order = await nextOrder(s, 'products', 'hero_order');
  return s.insert('products', v);
}

export async function updateProduct(s: Store, id: string, body: unknown) {
  const v = validateProduct(body, true);
  if (!Object.keys(v).length) throw fail([{ field: '', message: 'Nothing to update.' }]);
  const cur = await s.get('products', id);
  if (!cur) throw notFound('Product');
  const regular = v.regular_price ?? cur.regular_price;
  applyPercent(v, regular);
  const sale = 'sale_price' in v ? v.sale_price : cur.sale_price;
  const issues = priceIssues(regular, sale);
  if (issues.length) throw fail(issues);
  if (v.stock !== undefined && v.stock_status === undefined) v.stock_status = autoStatus(v.stock);
  if (v.featured_in_hero && !cur.featured_in_hero && v.hero_order === undefined) v.hero_order = await nextOrder(s, 'products', 'hero_order');
  return (await s.update('products', id, v))!;
}

export async function deleteProduct(s: Store, id: string) {
  if (!(await s.get('products', id))) throw notFound('Product');
  await s.remove('products', id); // gallery/model rows cascade; past orders keep their own name/price snapshot
  return { deleted: true };
}

export async function duplicateProduct(s: Store, id: string) {
  const src = await s.get('products', id);
  if (!src) throw notFound('Product');
  const { id: _i, created_at: _c, updated_at: _u, ...rest } = src;
  const tag = Math.random().toString(36).slice(2, 6);
  const copy = await s.insert('products', {
    ...rest, name: `${src.name} (Copy)`, slug: `${src.slug}-copy-${tag}`, sku: `${src.sku}-C${tag.toUpperCase()}`,
    is_active: false, featured_in_hero: false, display_order: await nextOrder(s, 'products', 'display_order'),
  });
  for (const im of await s.list('product_images', { filter: { product_id: id }, order: ['sort_order', true] })) {
    const { id: _x, product_id: _p, ...img } = im;
    await s.insert('product_images', { ...img, product_id: copy.id });
  }
  return copy;
}

export const listProducts = (s: Store, query: Row) => s.searchProducts(parseProductQuery(query));
export async function getProduct(s: Store, id: string) {
  const p = await s.getProductDetail(id);
  if (!p) throw notFound('Product');
  return p;
}

// ------------------------------------------------------------------ ordering (products, categories, hero)
const ORDER_FIELDS: Record<string, readonly string[]> = { products: ['display_order', 'hero_order'], categories: ['display_order'] };
/**
 * Re-orders `ids` into the given sequence. The group re-uses its own existing positions, so products on other
 * pages / outside the hero keep their relative place. Falls back to consecutive numbers if positions collide.
 */
export async function reorderRows(s: Store, table: 'products' | 'categories', body: unknown) {
  const { ids, field } = validateReorder(body, ORDER_FIELDS[table]);
  const rows = await s.getMany(table, ids);
  if (rows.length !== ids.length) throw notFound('One of the items');
  const slots = rows.map((r) => Number(r[field] ?? 0)).sort((a, b) => a - b);
  const distinct = new Set(slots).size === slots.length;
  const base = Math.min(...slots, 1);
  const positions = distinct ? slots : ids.map((_, i) => base + i);
  await Promise.all(ids.map((id, i) => s.update(table, id, { [field]: positions[i] })));
  return { updated: ids.length };
}

// ------------------------------------------------------------------ hero
export const listHero = (s: Store) => s.list('products', { filter: { featured_in_hero: true }, order: ['hero_order', true] });
export async function setHero(s: Store, id: string, body: unknown) {
  const featured = validateBool(body, 'featured');
  const cur = await s.get('products', id);
  if (!cur) throw notFound('Product');
  const patch: Row = { featured_in_hero: featured };
  if (featured && !cur.featured_in_hero) patch.hero_order = await nextOrder(s, 'products', 'hero_order');
  return (await s.update('products', id, patch))!;
}

// ------------------------------------------------------------------ gallery + 3D model
export async function addGalleryImage(s: Store, productId: string, body: unknown) {
  const v = validateImageAttach(body);
  if (!(await s.get('products', productId))) throw notFound('Product');
  v.sort_order ??= (await s.list('product_images', { filter: { product_id: productId } })).length;
  return s.insert('product_images', { ...v, product_id: productId });
}
export async function removeGalleryImage(s: Store, imageId: string) {
  if (!(await s.get('product_images', imageId))) throw notFound('Image');
  await s.remove('product_images', imageId);
  return { deleted: true };
}
export async function reorderGallery(s: Store, productId: string, body: unknown) {
  const { ids } = validateReorder(body, ['sort_order']);
  const rows = await s.list('product_images', { filter: { product_id: productId } });
  if (ids.length !== rows.length || !ids.every((i) => rows.some((r) => r.id === i))) throw fail([{ field: 'ids', message: 'Send every gallery image exactly once.' }]);
  await Promise.all(ids.map((id, i) => s.update('product_images', id, { sort_order: i })));
  return { updated: ids.length };
}
export async function setModel(s: Store, productId: string, body: unknown) {
  const v = validateModelAttach(body);
  if (!(await s.get('products', productId))) throw notFound('Product');
  await s.upsert('product_models', [{ ...v, product_id: productId }], 'product_id');
  return { model_url: v.model_url, format: v.format };
}
export async function removeModel(s: Store, productId: string) {
  const [m] = await s.list('product_models', { filter: { product_id: productId } });
  if (m) await s.remove('product_models', m.id);
  return { deleted: true };
}
/** Deletes an uploaded file (and its thumbnail) from storage. Only TEXO's own storage URLs are accepted. */
export async function deleteUpload(s: Store, url: string, supabaseUrl: string) {
  const { bucket, path } = parseStorageUrl(url, supabaseUrl);
  const paths = [path];
  if (bucket !== 'product-models' && /\.webp$/.test(path) && !path.endsWith('-thumb.webp')) paths.push(path.replace(/\.webp$/, '-thumb.webp'));
  await s.removeFiles(bucket, paths);
  return { deleted: true };
}

// ------------------------------------------------------------------ categories / news (simple resources)
const RESOURCES = {
  categories: { validate: validateCategory, slugFrom: 'name', order: ['display_order', true] as [string, boolean], label: 'Category' },
  news: { validate: validateNews, slugFrom: 'title', order: ['published_at', false] as [string, boolean], label: 'Article' },
  offers: { validate: validateOffer, slugFrom: undefined, order: ['ends_at', false] as [string, boolean], label: 'Offer' },
} as const;
export type ResourceName = keyof typeof RESOURCES;

export const listResource = (s: Store, name: ResourceName) => s.list(name, { order: RESOURCES[name].order });
export async function getResource(s: Store, name: ResourceName, id: string) {
  const r = await s.get(name, id);
  if (!r) throw notFound(RESOURCES[name].label);
  return r;
}
export async function createResource(s: Store, name: ResourceName, body: unknown) {
  const cfg = RESOURCES[name];
  const v = cfg.validate(body, false);
  if (cfg.slugFrom) v.slug ??= slugify(v[cfg.slugFrom]);
  if (name === 'categories') v.display_order ??= await nextOrder(s, 'categories', 'display_order');
  if (name === 'offers') await checkOffer(s, v);
  return s.insert(name, v);
}
export async function updateResource(s: Store, name: ResourceName, id: string, body: unknown) {
  const v = RESOURCES[name].validate(body, true);
  if (!Object.keys(v).length) throw fail([{ field: '', message: 'Nothing to update.' }]);
  const cur = await s.get(name, id);
  if (!cur) throw notFound(RESOURCES[name].label);
  if (name === 'offers') await checkOffer(s, { ...cur, ...v });
  return (await s.update(name, id, v))!;
}
export async function deleteResource(s: Store, name: ResourceName, id: string) {
  if (!(await s.get(name, id))) throw notFound(RESOURCES[name].label);
  await s.remove(name, id);
  return { deleted: true };
}

// ------------------------------------------------------------------ offers
/** An offer can never create an invalid price: one target, one price rule, price < regular, sane dates. */
export async function checkOffer(s: Store, o: Row): Promise<void> {
  const issues: Issue[] = [];
  const hasP = !!o.product_id, hasC = !!o.category_id, hasPrice = o.offer_price != null, hasPct = o.discount_percent != null;
  if (hasP === hasC) issues.push({ field: 'product_id', message: 'Choose either one product or one category.' });
  if (hasPrice === hasPct) issues.push({ field: 'offer_price', message: 'Enter either a fixed offer price or a discount percentage.' });
  if (hasPrice && !hasP) issues.push({ field: 'offer_price', message: 'A fixed price needs a specific product. Use a percentage for categories.' });
  if (o.starts_at && o.ends_at && Date.parse(o.ends_at) <= Date.parse(o.starts_at)) issues.push({ field: 'ends_at', message: 'The end date must be after the start date.' });
  if (hasP && !issues.length) {
    const p = await s.get('products', o.product_id);
    if (!p) issues.push({ field: 'product_id', message: 'Product not found.' });
    else if (hasPrice && !(Number(o.offer_price) > 0 && Number(o.offer_price) < Number(p.regular_price)))
      issues.push({ field: 'offer_price', message: `Offer price must be lower than the regular price (${p.regular_price}).` });
  }
  if (hasC && !issues.length && !(await s.get('categories', o.category_id))) issues.push({ field: 'category_id', message: 'Category not found.' });
  if (issues.length) throw fail(issues);
}

/** Shows what customers would really pay if this offer were saved (same pricing code as checkout). */
export async function previewOffer(s: Store, body: unknown, now: Date = new Date()) {
  const d = validateOfferDraft(body);
  const errors: Issue[] = [];
  try { await checkOffer(s, d); } catch (e) { if (e instanceof AppError && Array.isArray(e.details)) errors.push(...(e.details as Issue[])); else throw e; }
  const status = d.is_active === false ? 'inactive' : d.starts_at && Date.parse(d.starts_at) > now.getTime() ? 'scheduled'
    : d.ends_at && Date.parse(d.ends_at) <= now.getTime() ? 'expired' : 'live';
  let items: Row[] = [];
  if (!errors.length) {
    const products = d.product_id ? [await s.get('products', d.product_id)].filter(Boolean) as Row[]
      : await s.list('products', { filter: { category_id: d.category_id, is_active: true }, order: ['display_order', true], limit: 8 });
    const others = ((await s.list('offers', { filter: { is_active: true } })) as OfferLike[]).filter((o) => o.id !== d.id);
    const hypo: OfferLike = { id: 'preview', offer_text: null, is_active: true, starts_at: null, ends_at: null, discount_percent: d.discount_percent ?? null, offer_price: d.offer_price ?? null, product_id: d.product_id ?? null, category_id: d.category_id ?? null };
    items = products.map((p) => {
      const before = effectivePrice(p as any, others, now);
      const after = effectivePrice(p as any, [...others, hypo], now);
      const v = priceView(p as any, [...others, hypo], now);
      return { productId: p.id, name: p.name, regular: before.regular / 100, currentFinal: before.unit / 100, newFinal: after.unit / 100, save: v.save, percent: v.percent, changesPrice: after.unit < before.unit };
    });
  }
  return { valid: errors.length === 0, errors, status, liveNow: status === 'live', items };
}
export const isLive = isOfferLive;

// ------------------------------------------------------------------ orders / settings / stats
export const listOrders = (s: Store, query: Row) => s.searchOrders(parseOrderQuery(query));
export async function getOrder(s: Store, id: string) {
  const o = await s.getOrder(id);
  if (!o) throw notFound('Order');
  return o;
}
/** Cancelling restores stock atomically inside the set_order_status SQL function (unchanged since Phase 2). */
export async function setOrderStatus(s: Store, id: string, body: unknown) {
  const status = validateStatus(body);
  return s.rpc('set_order_status', { p_id: id, p_status: status });
}
export async function getSettings(s: Store) {
  return Object.fromEntries((await s.list('site_settings')).map((r) => [r.key, r.value]));
}
export async function updateSettings(s: Store, body: unknown) {
  const v = validateSettings(body);
  const now = new Date().toISOString();
  await s.upsert('site_settings', Object.entries(v).map(([key, value]) => ({ key, value, updated_at: now })), 'key');
  return { updated: Object.keys(v).length };
}
export const getStats = (s: Store) => s.rpc('admin_stats', {});
export { uuidParam };
