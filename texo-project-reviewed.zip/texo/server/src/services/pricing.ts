// Pure money logic. All math in paisa (integers) to avoid floating-point errors.
export interface PricedProduct {
  regular_price: number | string;
  sale_price: number | string | null;
}
export interface DeliverySettings {
  insideDhaka: number;
  outsideDhaka: number;
  freeThreshold: number; // 0 = disabled
}
export type Zone = 'inside_dhaka' | 'outside_dhaka';

export const toCents = (v: number | string): number => Math.round(Number(v) * 100);
export const fromCents = (c: number): number => c / 100;

export function unitCents(p: PricedProduct): { regular: number; unit: number } {
  const regular = toCents(p.regular_price);
  const sale = p.sale_price == null ? null : toCents(p.sale_price);
  const unit = sale !== null && sale > 0 && sale < regular ? sale : regular;
  return { regular, unit };
}

export function zoneFromDistrict(district: string): Zone {
  return district.trim().toLowerCase() === 'dhaka' ? 'inside_dhaka' : 'outside_dhaka';
}

export interface Line { regular: number; unit: number; quantity: number }

export function computeTotals(lines: Line[], d: DeliverySettings, zone: Zone) {
  const regularSubtotal = lines.reduce((s, l) => s + l.regular * l.quantity, 0);
  const subtotal = lines.reduce((s, l) => s + l.unit * l.quantity, 0);
  const base = toCents(zone === 'inside_dhaka' ? d.insideDhaka : d.outsideDhaka);
  const free = d.freeThreshold > 0 && subtotal >= toCents(d.freeThreshold);
  const delivery = free ? 0 : base;
  return {
    regularSubtotal: fromCents(regularSubtotal),
    subtotal: fromCents(subtotal),
    discount: fromCents(regularSubtotal - subtotal),
    deliveryCharge: fromCents(delivery),
    total: fromCents(subtotal + delivery),
  };
}

// ---------------- Offers ----------------
export interface OfferLike {
  id: string;
  offer_text?: string | null;
  is_active: boolean;
  starts_at: string | null;
  ends_at: string | null;
  discount_percent: number | null;
  offer_price: number | string | null;
  product_id: string | null;
  category_id: string | null;
}
export interface PriceableProduct extends PricedProduct {
  id: string;
  category_id: string | null;
}

/** An offer affects prices only if active, started, and not ended. Unparseable dates => NOT live (fail safe). */
export function isOfferLive(o: OfferLike, now: Date): boolean {
  if (!o.is_active) return false;
  if (o.starts_at) { const t = Date.parse(o.starts_at); if (Number.isNaN(t) || t > now.getTime()) return false; }
  if (o.ends_at) { const t = Date.parse(o.ends_at); if (Number.isNaN(t) || t <= now.getTime()) return false; }
  return true;
}

function offerUnit(o: OfferLike, p: PriceableProduct, regular: number): number | null {
  const targets = o.product_id != null ? o.product_id === p.id : o.category_id != null && o.category_id === p.category_id;
  if (!targets) return null;
  if (o.product_id != null && o.offer_price != null) {          // fixed price: product offers only
    const c = toCents(o.offer_price);
    return Number.isFinite(c) && c > 0 && c < regular ? c : null;
  }
  const pct = o.discount_percent;                                // percentage: product or category offers
  if (pct != null && Number.isInteger(pct) && pct >= 1 && pct <= 99) {
    const c = Math.round((regular * (100 - pct)) / 100);
    return c > 0 && c < regular ? c : null;
  }
  return null;
}

export type PriceSource = 'regular' | 'sale' | 'offer';
/** Single source of truth for what a customer pays per unit: the lowest of regular, product sale price, live offers. */
export function effectivePrice(p: PriceableProduct, offers: OfferLike[], now: Date) {
  const regular = toCents(p.regular_price);
  let unit = regular;
  let source: PriceSource = 'regular';
  let offer: OfferLike | null = null;
  const sale = p.sale_price == null ? null : toCents(p.sale_price);
  if (sale !== null && Number.isFinite(sale) && sale > 0 && sale < unit) { unit = sale; source = 'sale'; }
  for (const o of offers) {
    if (!isOfferLive(o, now)) continue;
    const c = offerUnit(o, p, regular);
    if (c !== null && c < unit) { unit = c; source = 'offer'; offer = o; }
  }
  return { regular, unit, source, offer };
}

/** Customer-facing price block (taka). Percent is always computed from the real prices. */
export function priceView(p: PriceableProduct, offers: OfferLike[], now: Date) {
  const e = effectivePrice(p, offers, now);
  const save = e.regular - e.unit;
  return {
    regular: fromCents(e.regular),
    final: fromCents(e.unit),
    save: fromCents(save),
    percent: e.regular > 0 ? Math.round((save / e.regular) * 100) : 0,
    source: e.source,
    offerText: e.offer?.offer_text ?? null,
    offerEndsAt: e.offer?.ends_at ?? null,
  };
}

/** Sale price (taka) for "X% off" the regular price, rounded to the nearest paisa. */
export function salePriceFromPercent(regular: number | string, percent: number): number {
  return Math.round((toCents(regular) * (100 - percent)) / 100) / 100;
}
