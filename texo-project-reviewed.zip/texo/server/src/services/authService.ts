import { AppError } from '../lib/errors.ts';
import { fail } from '../validation/admin.ts';

export interface Session { access_token: string; refresh_token: string; expires_at?: number }
export type AdminUser = { id: string; email?: string };
export type AdminCheck = { ok: true; user: AdminUser } | { ok: false; reason: 'invalid' | 'forbidden' };
export interface AuthDeps {
  signIn(email: string, password: string): Promise<Session | null>;
  refresh(refreshToken: string): Promise<Session | null>;
  verify(accessToken: string): Promise<AdminCheck>;
}
const BAD = () => new AppError(401, 'INVALID_CREDENTIALS', 'Incorrect email or password.');
const out = (s: Session, user?: AdminUser) => ({ accessToken: s.access_token, refreshToken: s.refresh_token, expiresAt: s.expires_at ?? null, ...(user ? { user } : {}) });

export function parseLogin(body: unknown): { email: string; password: string } {
  const b = (body ?? {}) as Record<string, unknown>;
  const email = typeof b.email === 'string' ? b.email.trim() : '';
  const password = typeof b.password === 'string' ? b.password : '';
  const issues: { field: string; message: string }[] = [];
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 200) issues.push({ field: 'email', message: 'Enter a valid email address.' });
  if (!password || password.length > 200) issues.push({ field: 'password', message: 'Enter your password.' });
  if (issues.length) throw fail(issues);
  return { email, password };
}

/** Same error for "wrong password" and "valid user but not an admin": no account probing. */
export async function login(deps: AuthDeps, body: unknown) {
  const { email, password } = parseLogin(body);
  const s = await deps.signIn(email, password);
  if (!s) throw BAD();
  const check = await deps.verify(s.access_token);
  if (!check.ok) throw BAD();
  return out(s, check.user);
}
export async function refreshSession(deps: AuthDeps, body: unknown) {
  const t = (body as any)?.refreshToken;
  if (typeof t !== 'string' || t.length < 10 || t.length > 500) throw new AppError(401, 'UNAUTHENTICATED', 'Please log in again.');
  const s = await deps.refresh(t);
  if (!s) throw new AppError(401, 'UNAUTHENTICATED', 'Your session has expired. Please log in again.');
  const check = await deps.verify(s.access_token);
  if (!check.ok) throw new AppError(401, 'UNAUTHENTICATED', 'Please log in again.');
  return out(s);
}
/** Gate for every admin route. */
export async function authorize(deps: AuthDeps, header: string | undefined): Promise<AdminUser> {
  const m = /^Bearer (.{10,4000})$/.exec(header ?? '');
  if (!m) throw new AppError(401, 'UNAUTHENTICATED', 'Please log in.');
  const check = await deps.verify(m[1]);
  if (check.ok) return check.user;
  if (check.reason === 'forbidden') throw new AppError(403, 'FORBIDDEN', 'You do not have admin access.');
  throw new AppError(401, 'UNAUTHENTICATED', 'Your session has expired. Please log in again.');
}
