import 'dotenv/config';
import { z } from 'zod';

const schema = z.object({
  NODE_ENV: z.enum(['development', 'production', 'test']).default('development'),
  PORT: z.coerce.number().default(4000),
  SUPABASE_URL: z.string().url(),
  SUPABASE_ANON_KEY: z.string().min(20),
  SUPABASE_SERVICE_ROLE_KEY: z.string().min(20),
  CORS_ORIGIN: z.string().default('http://localhost:5173'),
  TRUST_PROXY: z.coerce.number().default(0),
});
const parsed = schema.safeParse(process.env);
if (!parsed.success) {
  console.error('\nMissing or invalid environment variables in server/.env:');
  console.error(parsed.error.flatten().fieldErrors, '\n');
  process.exit(1);
}
export const env = parsed.data;
