import type { NextFunction, Request, Response } from 'express';
import rateLimit from 'express-rate-limit';
import { ZodError } from 'zod';
import { AppError } from './lib/errors.ts';
import { authDeps } from './services/auth.ts';
import { authorize } from './services/authService.ts';

const limited = (windowMin: number, limit: number, message: string) =>
  rateLimit({
    windowMs: windowMin * 60_000, limit, standardHeaders: 'draft-7', legacyHeaders: false,
    message: { error: { code: 'RATE_LIMITED', message } },
  });
export const apiLimiter = limited(15, 600, 'Too many requests. Please try again shortly.');
export const loginLimiter = limited(15, 8, 'Too many login attempts. Please wait 15 minutes.');
export const orderLimiter = limited(10, 10, 'Too many orders from this connection. Please wait a few minutes.');
export const uploadLimiter = limited(15, 120, 'Too many uploads. Please wait a few minutes.');

export const publicCache = (seconds: number) => (_req: Request, res: Response, next: NextFunction) => {
  res.set('Cache-Control', `public, max-age=${seconds}, stale-while-revalidate=${seconds * 5}`);
  next();
};

export async function requireAdmin(req: Request, res: Response, next: NextFunction) {
  res.locals.admin = await authorize(authDeps, req.get('authorization'));
  next();
}

export const ok = (res: Response, data: unknown, meta?: unknown) => res.json(meta ? { data, meta } : { data });

const PG_MAP: Record<string, [number, string, string]> = {
  '23505': [409, 'DUPLICATE', 'That value already exists (slug or SKU must be unique).'],
  '23503': [409, 'IN_USE', 'This item is linked to other data and cannot be changed this way.'],
  '23514': [400, 'INVALID_VALUE', 'One of the values is not allowed (check prices, stock or status).'],
  '22P02': [400, 'INVALID_VALUE', 'One of the values has the wrong format.'],
  '22007': [400, 'INVALID_DATE', 'Invalid date.'],
  '22008': [400, 'INVALID_DATE', 'Invalid date.'],
};

export function notFound(_req: Request, res: Response) {
  res.status(404).json({ error: { code: 'NOT_FOUND', message: 'Not found.' } });
}

export function errorHandler(err: any, _req: Request, res: Response, _next: NextFunction) {
  const send = (status: number, code: string, message: string, details?: unknown) =>
    res.status(status).json({ error: { code, message, ...(details ? { details } : {}) } });

  if (err instanceof AppError) return send(err.status, err.code, err.message, err.details);
  if (err instanceof ZodError)
    return send(400, 'VALIDATION_ERROR', 'Please check the highlighted fields.',
      err.issues.map((i) => ({ field: i.path.join('.'), message: i.message })));
  if (err?.name === 'MulterError')
    return err.code === 'LIMIT_FILE_SIZE'
      ? send(413, 'FILE_TOO_LARGE', 'This file is too large.')
      : send(400, 'UPLOAD_ERROR', 'The upload could not be processed.');
  if (err?.type === 'entity.parse.failed') return send(400, 'INVALID_JSON', 'Invalid request body.');
  if (err?.type === 'entity.too.large') return send(413, 'PAYLOAD_TOO_LARGE', 'Request is too large.');
  if (typeof err?.message === 'string') {
    if (err.message.includes('OUT_OF_STOCK')) return send(409, 'OUT_OF_STOCK', 'Sorry, a product just went out of stock. Please review your order.');
    if (err.message.includes('ORDER_CANCELLED')) return send(409, 'ORDER_CANCELLED', 'A cancelled order cannot be reopened. Create a new order instead.');
    if (err.message.includes('NOT_FOUND')) return send(404, 'NOT_FOUND', 'Not found.');
  }
  const mapped = typeof err?.code === 'string' ? PG_MAP[err.code] : undefined;
  if (mapped) return send(...mapped);
  console.error('[server error]', err);
  return send(500, 'SERVER_ERROR', 'Something went wrong on our side. Please try again.');
}
