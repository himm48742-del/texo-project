import { createClient } from '@supabase/supabase-js';
import { env } from '../config/env.ts';

const opts = { auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false } };

/** Service-role client: bypasses RLS. Use ONLY for orders, admin routes and uploads. */
export const supabaseAdmin = createClient(env.SUPABASE_URL, env.SUPABASE_SERVICE_ROLE_KEY, opts);
/** Anon client: RLS applies. Used for all public catalog reads (defence in depth). */
export const supabasePublic = createClient(env.SUPABASE_URL, env.SUPABASE_ANON_KEY, opts);
/** Fresh client per login so sessions never mix between users. */
export const newAnonClient = () => createClient(env.SUPABASE_URL, env.SUPABASE_ANON_KEY, opts);
