import { AppError } from './errors.ts';

export function slugify(input: string): string {
  const s = input.normalize('NFKD').replace(/[\u0300-\u036f]/g, '').toLowerCase()
    .replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 80);
  return s || `item-${Math.random().toString(36).slice(2, 8)}`;
}

export function int(v: unknown, def: number, min: number, max: number): number {
  const n = parseInt(String(v), 10);
  return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : def;
}

/** Strips characters that could break PostgREST filter syntax. */
export function sanitizeSearch(q: string): string {
  return q.replace(/[^\p{L}\p{N}\s\-_.]/gu, ' ').replace(/\s+/g, ' ').trim().slice(0, 60);
}

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
export const isUuid = (v: unknown): v is string => typeof v === 'string' && UUID.test(v);
export function uuidParam(v: unknown): string {
  if (!isUuid(v)) throw new AppError(400, 'INVALID_ID', 'Invalid id.');
  return v;
}
