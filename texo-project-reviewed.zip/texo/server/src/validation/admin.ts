// Server-side validation for every admin write. Hand-written (no dependencies) so it is fully unit-tested.
import { AppError } from '../lib/errors.ts';
import { isUuid, sanitizeSearch } from '../lib/utils.ts';

export interface Issue { field: string; message: string }
export type Row = Record<string, any>;
interface Rule {
  t: 'string' | 'money' | 'int' | 'number' | 'bool' | 'url' | 'uuid' | 'enum' | 'datetime' | 'strarray' | 'strmap';
  required?: boolean; nullable?: boolean; min?: number; max?: number; values?: readonly string[]; pattern?: RegExp; patternMsg?: string;
}
export const fail = (issues: Issue[], message = 'Please check the highlighted fields.') => new AppError(400, 'VALIDATION_ERROR', message, issues);
const isObj = (v: unknown): v is Row => typeof v === 'object' && v !== null && !Array.isArray(v);

function check(r: Rule, v: unknown): { value: any } | { error: string } {
  const err = (error: string) => ({ error });
  switch (r.t) {
    case 'string': {
      if (typeof v !== 'string') return err('Must be text.');
      const s = v.trim();
      if (r.nullable && s === '') return { value: null };
      if (s.length < (r.min ?? 0)) return err(s.length === 0 ? 'This field is required.' : `Must be at least ${r.min} characters.`);
      if (s.length > (r.max ?? 1000)) return err(`Must be at most ${r.max ?? 1000} characters.`);
      if (r.pattern && !r.pattern.test(s)) return err(r.patternMsg ?? 'Invalid format.');
      return { value: s };
    }
    case 'money': {
      if (typeof v !== 'number' || !Number.isFinite(v)) return err('Enter a valid price.');
      if (v <= 0) return err('Price must be greater than zero.');
      if (v > 10_000_000) return err('Price is too large.');
      if (Math.abs(v * 100 - Math.round(v * 100)) > 1e-6) return err('Use at most 2 decimal places.');
      return { value: v };
    }
    case 'int': case 'number': {
      const n = typeof v === 'string' && v.trim() !== '' ? Number(v) : v;
      if (typeof n !== 'number' || !Number.isFinite(n)) return err('Enter a valid number.');
      if (r.t === 'int' && !Number.isInteger(n)) return err('Enter a whole number.');
      if (r.min !== undefined && n < r.min) return err(`Must be at least ${r.min}.`);
      if (r.max !== undefined && n > r.max) return err(`Must be at most ${r.max}.`);
      return { value: n };
    }
    case 'bool': return typeof v === 'boolean' ? { value: v } : err('Must be true or false.');
    case 'url': {
      if (typeof v !== 'string') return err('Must be a web address.');
      const s = v.trim();
      if (r.nullable && s === '') return { value: null };
      try { if (!/^https?:$/.test(new URL(s).protocol) || s.length > 2000) throw new Error(); } catch { return err('Enter a valid http(s) web address.'); }
      return { value: s };
    }
    case 'uuid': {
      if (r.nullable && v === '') return { value: null };
      return isUuid(v) ? { value: v } : err('Invalid selection.');
    }
    case 'enum': return typeof v === 'string' && r.values!.includes(v) ? { value: v } : err(`Must be one of: ${r.values!.join(', ')}.`);
    case 'datetime': {
      if (typeof v !== 'string') return err('Invalid date.');
      if (r.nullable && v.trim() === '') return { value: null };
      const t = Date.parse(v);
      return Number.isNaN(t) ? err('Invalid date.') : { value: new Date(t).toISOString() };
    }
    case 'strarray': {
      if (!Array.isArray(v)) return err('Must be a list.');
      if (v.length > (r.max ?? 30)) return err(`At most ${r.max ?? 30} items.`);
      const out: string[] = [];
      for (const x of v) {
        if (typeof x !== 'string') return err('Every item must be text.');
        const s = x.trim();
        if (s.length > 200) return err('Each item must be at most 200 characters.');
        if (s) out.push(s);
      }
      return { value: out };
    }
    case 'strmap': {
      if (!isObj(v)) return err('Must be a list of name/value pairs.');
      const entries = Object.entries(v);
      if (entries.length > (r.max ?? 50)) return err(`At most ${r.max ?? 50} entries.`);
      const out: Record<string, string> = {};
      for (const [k, x] of entries) {
        if (typeof x !== 'string' || k.length > 60 || x.length > 300) return err('Names must be ≤ 60 and values ≤ 300 characters.');
        if (k.trim() && x.trim()) out[k.trim()] = x.trim();
      }
      return { value: out };
    }
  }
}

/** Validates `body` against `schema`. Unknown keys are dropped. `partial` = PATCH (nothing is required). */
export function validate(body: unknown, schema: Record<string, Rule>, partial = false): Row {
  if (!isObj(body)) throw fail([{ field: '', message: 'Invalid request body.' }], 'Invalid request body.');
  const out: Row = {}; const issues: Issue[] = [];
  for (const [k, rule] of Object.entries(schema)) {
    const v = body[k];
    if (v === undefined) { if (rule.required && !partial) issues.push({ field: k, message: 'This field is required.' }); continue; }
    if (v === null) { if (rule.nullable) out[k] = null; else issues.push({ field: k, message: 'This field cannot be empty.' }); continue; }
    const r = check(rule, v);
    if ('error' in r) issues.push({ field: k, message: r.error }); else out[k] = r.value;
  }
  if (issues.length) throw fail(issues);
  return out;
}

const SLUG = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;
const slug = (extra: Partial<Rule> = {}): Rule => ({ t: 'string', min: 1, max: 100, pattern: SLUG, patternMsg: 'Use lowercase letters, numbers and dashes only.', ...extra });
export const STOCK_STATUSES = ['in_stock', 'low_stock', 'out_of_stock', 'preorder'] as const;
export const ORDER_STATUSES = ['pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled'] as const;

const PRODUCT: Record<string, Rule> = {
  name: { t: 'string', required: true, min: 1, max: 160 },
  sku: { t: 'string', required: true, min: 1, max: 40, pattern: /^[A-Za-z0-9._-]+$/, patternMsg: 'Use letters, numbers, dots, dashes and underscores only.' },
  slug: slug(),
  category_id: { t: 'uuid', nullable: true },
  short_desc: { t: 'string', max: 300, nullable: true }, full_desc: { t: 'string', max: 20000, nullable: true },
  regular_price: { t: 'money', required: true }, sale_price: { t: 'money', nullable: true },
  discount_percent: { t: 'int', min: 0, max: 99 }, offer_text: { t: 'string', max: 200, nullable: true },
  currency: { t: 'string', min: 1, max: 5 },
  stock: { t: 'int', min: 0, max: 1_000_000 }, stock_status: { t: 'enum', values: STOCK_STATUSES },
  main_image_url: { t: 'url', nullable: true }, thumb_url: { t: 'url', nullable: true }, video_url: { t: 'url', nullable: true },
  features: { t: 'strarray', max: 30 }, specifications: { t: 'strmap', max: 50 },
  order_button_enabled: { t: 'bool' }, order_button_text: { t: 'string', min: 1, max: 30, nullable: true },
  is_featured: { t: 'bool' }, featured_in_hero: { t: 'bool' }, hero_order: { t: 'int', min: 0, max: 1_000_000 },
  display_order: { t: 'int', min: 0, max: 1_000_000 }, is_active: { t: 'bool' },
};
const CATEGORY: Record<string, Rule> = {
  name: { t: 'string', required: true, min: 1, max: 80 }, slug: slug(), icon_url: { t: 'url', nullable: true },
  display_order: { t: 'int', min: 0, max: 1_000_000 }, is_active: { t: 'bool' },
};
const OFFER: Record<string, Rule> = {
  title: { t: 'string', required: true, min: 1, max: 120 }, offer_text: { t: 'string', max: 300, nullable: true },
  offer_price: { t: 'money', nullable: true }, discount_percent: { t: 'int', min: 1, max: 99, nullable: true },
  starts_at: { t: 'datetime', nullable: true }, ends_at: { t: 'datetime', nullable: true },
  product_id: { t: 'uuid', nullable: true }, category_id: { t: 'uuid', nullable: true },
  banner_url: { t: 'url', nullable: true }, auto_expire: { t: 'bool' }, is_active: { t: 'bool' },
};
const NEWS: Record<string, Rule> = {
  title: { t: 'string', required: true, min: 1, max: 200 }, slug: slug(), description: { t: 'string', max: 500, nullable: true },
  body: { t: 'string', max: 50000, nullable: true }, thumbnail_url: { t: 'url', nullable: true },
  published_at: { t: 'datetime' }, is_published: { t: 'bool' },
};
export const validateProduct = (b: unknown, partial: boolean) => validate(b, PRODUCT, partial);
export const validateCategory = (b: unknown, partial: boolean) => validate(b, CATEGORY, partial);
export const validateOffer = (b: unknown, partial: boolean) => validate(b, OFFER, partial);
export const validateNews = (b: unknown, partial: boolean) => validate(b, NEWS, partial);
export const validateOfferDraft = (b: unknown) => validate(b, { ...OFFER, title: { ...OFFER.title, required: false }, id: { t: 'uuid', nullable: true } }, true);

/** Sale price must be strictly lower than the regular price (blank = no sale). */
export function priceIssues(regular: unknown, sale: unknown): Issue[] {
  const r = Number(regular), s = sale == null ? null : Number(sale);
  if (!(r > 0)) return [{ field: 'regular_price', message: 'Regular price must be greater than zero.' }];
  if (s !== null && !(s > 0 && s < r)) return [{ field: 'sale_price', message: 'Sale price must be lower than the regular price (leave it blank for no sale).' }];
  return [];
}

const PHONE = /^[0-9+\-\s()]{6,20}$/;
const SOCIAL_URL = ['facebook', 'instagram', 'youtube', 'tiktok', 'twitter', 'linkedin'] as const;
const SETTINGS: Record<string, Rule> = {
  brand_name: { t: 'string', min: 1, max: 60 }, tagline: { t: 'string', min: 1, max: 80 },
  business_phone: { t: 'string', pattern: PHONE, patternMsg: 'Enter a valid phone number.', min: 6, max: 20 },
  whatsapp_number: { t: 'string', pattern: PHONE, patternMsg: 'Enter a valid WhatsApp number.', min: 6, max: 20 },
  footer_text: { t: 'string', max: 200 },
  currency: { t: 'string', pattern: /^[A-Z]{3}$/, patternMsg: 'Use a 3-letter code such as BDT.', min: 3, max: 3 },
  currency_symbol: { t: 'string', min: 1, max: 4 },
  delivery_inside_dhaka: { t: 'number', min: 0, max: 100_000 }, delivery_outside_dhaka: { t: 'number', min: 0, max: 100_000 },
  free_delivery_threshold: { t: 'number', min: 0, max: 10_000_000 },
  welcome_enabled: { t: 'bool' }, welcome_line1: { t: 'string', min: 1, max: 120 }, welcome_line2: { t: 'string', min: 1, max: 160 },
  hero_rotation_seconds: { t: 'number', min: 3, max: 30 }, hero_animation_speed: { t: 'number', min: 0.5, max: 2 }, hero_autoplay: { t: 'bool' },
  hero_headline: { t: 'string', min: 1, max: 120 }, hero_description: { t: 'string', max: 300 },
};
/** Only known settings are accepted, each with its own type and range. */
export function validateSettings(body: unknown): Row {
  if (!isObj(body)) throw fail([{ field: '', message: 'Invalid request body.' }]);
  const issues: Issue[] = []; const out: Row = {};
  for (const [k, v] of Object.entries(body)) {
    if (k === 'social_links') {
      if (!isObj(v)) { issues.push({ field: k, message: 'Invalid social links.' }); continue; }
      const links: Record<string, string> = {};
      for (const [name, val] of Object.entries(v)) {
        if (typeof val !== 'string' || val.length > 300) { issues.push({ field: `social_links.${name}`, message: 'Invalid value.' }); continue; }
        const s = val.trim();
        if (name === 'email') {
          if (s && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s)) issues.push({ field: 'social_links.email', message: 'Enter a valid email address.' }); else links.email = s;
        } else if ((SOCIAL_URL as readonly string[]).includes(name)) {
          const r = s === '' ? { value: '' } : check({ t: 'url' }, s);
          if ('error' in r) issues.push({ field: `social_links.${name}`, message: r.error }); else links[name] = r.value;
        } else issues.push({ field: `social_links.${name}`, message: 'Unknown link.' });
      }
      out[k] = links; continue;
    }
    const rule = SETTINGS[k];
    if (!rule) { issues.push({ field: k, message: 'Unknown setting.' }); continue; }
    const r = check(rule, v);
    if ('error' in r) issues.push({ field: k, message: r.error }); else out[k] = r.value;
  }
  if (!Object.keys(body).length) issues.push({ field: '', message: 'Nothing to update.' });
  if (issues.length) throw fail(issues);
  return out;
}

export function validateReorder(body: unknown, fields: readonly string[]) {
  if (!isObj(body) || !Array.isArray(body.ids) || body.ids.length < 1 || body.ids.length > 1000 || !body.ids.every(isUuid) || new Set(body.ids).size !== body.ids.length)
    throw fail([{ field: 'ids', message: 'Send a list of unique ids.' }]);
  const field = body.field === undefined ? fields[0] : body.field;
  if (typeof field !== 'string' || !fields.includes(field)) throw fail([{ field: 'field', message: 'Invalid order field.' }]);
  return { ids: body.ids as string[], field };
}
export function validateStatus(body: unknown): (typeof ORDER_STATUSES)[number] {
  const s = isObj(body) ? body.status : undefined;
  if (typeof s !== 'string' || !(ORDER_STATUSES as readonly string[]).includes(s)) throw fail([{ field: 'status', message: `Status must be one of: ${ORDER_STATUSES.join(', ')}.` }]);
  return s as (typeof ORDER_STATUSES)[number];
}
export const validateBool = (body: unknown, key: string): boolean => {
  if (!isObj(body) || typeof body[key] !== 'boolean') throw fail([{ field: key, message: 'Must be true or false.' }]);
  return body[key] as boolean;
};
export const validateImageAttach = (b: unknown) => validate(b, {
  url: { t: 'url', required: true }, thumb_url: { t: 'url', nullable: true }, alt_text: { t: 'string', max: 200, nullable: true }, sort_order: { t: 'int', min: 0, max: 10000 },
});
export const validateModelAttach = (b: unknown) => validate(b, { model_url: { t: 'url', required: true }, format: { t: 'enum', required: true, values: ['glb', 'gltf'] } });
export const validateUrlBody = (b: unknown) => validate(b, { url: { t: 'url', required: true } }).url as string;

// ---- list queries (already sanitised; the store turns these into database filters) ----
const day = (v: unknown) => (typeof v === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(v) && !Number.isNaN(Date.parse(v)) ? v : undefined);
const page = (v: unknown, def: number, min: number, max: number) => { const n = parseInt(String(v), 10); return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : def; };
export interface ProductQuery { q: string; categoryId?: string; active?: boolean; hero?: boolean; page: number; limit: number }
export function parseProductQuery(q: Row): ProductQuery {
  return {
    q: sanitizeSearch(String(q.q ?? '')), categoryId: isUuid(q.category) ? q.category : undefined,
    active: q.active === 'true' ? true : q.active === 'false' ? false : undefined, hero: q.hero === 'true' ? true : undefined,
    page: page(q.page, 1, 1, 100000), limit: page(q.limit, 25, 1, 100),
  };
}
export interface OrderQuery { status?: string; q: string; phone: string; from?: string; to?: string; productId?: string; page: number; limit: number }
export function parseOrderQuery(q: Row): OrderQuery {
  return {
    status: typeof q.status === 'string' && (ORDER_STATUSES as readonly string[]).includes(q.status) ? q.status : undefined,
    q: sanitizeSearch(String(q.q ?? '')), phone: sanitizeSearch(String(q.phone ?? '')),
    from: day(q.from), to: day(q.to), productId: isUuid(q.productId) ? q.productId : undefined,
    page: page(q.page, 1, 1, 100000), limit: page(q.limit, 25, 1, 100),
  };
}
