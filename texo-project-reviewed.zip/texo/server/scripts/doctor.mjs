// "Doctor": checks your own setup, step by step, in plain English.
//   cd server && npm run doctor
// It NEVER prints your keys. It is safe to copy/paste its whole output into a chat.
import { existsSync, readFileSync } from 'node:fs';

const arg = (n, d) => { const i = process.argv.indexOf(`--${n}`); return i > -1 ? process.argv[i + 1] : d; };
const envFile = arg('env', '.env');
const results = [];
const out = (tag, name, note = '') => { results.push(tag); console.log(`[${tag}] ${name}${note ? `\n       -> ${note}` : ''}`); };
const pass = (n, note) => out('PASS', n, note);
const fail = (n, fix) => out('FAIL', n, fix);
const skip = (n, why) => out('SKIP', n, why);

function parseEnv(text) {
  const env = {};
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith('#')) continue;
    const i = line.indexOf('=');
    if (i < 1) continue;
    let v = line.slice(i + 1).trim();
    if (!/^["']/.test(v)) v = v.replace(/\s+#.*$/, '');
    env[line.slice(0, i).trim()] = v.replace(/^["']|["']$/g, '');
  }
  return env;
}
const jwtRole = (k) => { try { return JSON.parse(Buffer.from(k.split('.')[1], 'base64url').toString()).role; } catch { return null; } };
const looksPlaceholder = (v) => !v || /your-|YOUR-|paste-|xxxx/i.test(v);

async function call(url, opts = {}) {
  try {
    const r = await fetch(url, { ...opts, signal: AbortSignal.timeout(10000) });
    let body = null; const txt = await r.text(); try { body = JSON.parse(txt); } catch { body = txt; }
    return { ok: r.ok, status: r.status, body, headers: r.headers };
  } catch (e) { return { ok: false, status: 0, error: e.cause?.code ?? e.name }; }
}

console.log('\nTEXO doctor: checking your setup. No secrets are printed.\n');

// ---------- 1. .env file
if (!existsSync(envFile)) {
  fail(`Found ${envFile}`, 'Create it: copy server/.env.example to server/.env, then fill in the 3 Supabase values.');
  console.log('\nStopped: fix the line above first.\n'); process.exit(1);
}
const env = parseEnv(readFileSync(envFile, 'utf8'));
pass(`Found ${envFile}`);

// ---------- 2. variables
const URL_ = (env.SUPABASE_URL ?? '').replace(/\/+$/, '');
const ANON = env.SUPABASE_ANON_KEY ?? '', SERVICE = env.SUPABASE_SERVICE_ROLE_KEY ?? '';
let envOk = true;
if (looksPlaceholder(URL_) || (!/^https:\/\/[a-z0-9-]+\.supabase\.co$/i.test(URL_) && !/^https?:\/\/(localhost|127\.0\.0\.1)/.test(URL_))) { fail('SUPABASE_URL looks right', 'It should look like https://abcdefgh.supabase.co (Project Settings > API > Project URL). No /rest/v1 at the end.'); envOk = false; } else pass('SUPABASE_URL looks right');
if (looksPlaceholder(ANON) || ANON.length < 20) { fail('SUPABASE_ANON_KEY is filled in', 'Paste the "anon public" key from Project Settings > API.'); envOk = false; } else pass('SUPABASE_ANON_KEY is filled in');
if (looksPlaceholder(SERVICE) || SERVICE.length < 20) { fail('SUPABASE_SERVICE_ROLE_KEY is filled in', 'Paste the "service_role" key from Project Settings > API.'); envOk = false; } else pass('SUPABASE_SERVICE_ROLE_KEY is filled in');
if (envOk) {
  const ra = jwtRole(ANON), rs = jwtRole(SERVICE);
  if (ra === 'service_role' || rs === 'anon') fail('Keys are in the right slots', 'The anon and service_role keys look swapped. Put "anon public" in SUPABASE_ANON_KEY and "service_role" in SUPABASE_SERVICE_ROLE_KEY.'); 
  else if (ANON === SERVICE) fail('Keys are in the right slots', 'Both keys are identical. They must be two different keys.');
  else pass('Keys are in the right slots');
}
const PORT = env.PORT || '4000';
const api = arg('api', `http://localhost:${PORT}/api`);
const web = arg('web', 'http://localhost:5173');

// ---------- 3. Supabase (database, functions, storage, security)
if (!envOk) { skip('Supabase checks', 'Fix the .env lines above first.'); }
else {
  const H = (key, extra = {}) => ({ apikey: key, Authorization: `Bearer ${key}`, 'Content-Type': 'application/json', ...extra });
  const rest = (p, key = SERVICE, o = {}) => call(`${URL_}/rest/v1/${p}`, { ...o, headers: H(key, o.headers) });
  const probe = await rest('products?select=id&limit=1');
  if (probe.status === 0) fail('Supabase is reachable', `Could not connect (${probe.error}). Check SUPABASE_URL and your internet connection.`);
  else if (probe.status === 401 || probe.status === 403) fail('Supabase accepts your service_role key', 'The key was rejected. Re-copy the "service_role" key from Project Settings > API.');
  else {
    pass('Supabase is reachable and accepts your key');
    const missing = [];
    for (const t of ['categories', 'products', 'product_images', 'product_models', 'orders', 'order_items', 'offers', 'news', 'site_settings', 'admin_users']) {
      const r = await rest(`${t}?select=*&limit=1`); if (!r.ok) missing.push(t);
    }
    missing.length ? fail('Database tables exist', `Missing: ${missing.join(', ')}. Run supabase/migrations/001_schema.sql in the Supabase SQL Editor.`) : pass('Database tables exist (migration 001)');

    const fn = async (name, body, existsIf) => { const r = await rest(`rpc/${name}`, SERVICE, { method: 'POST', body: JSON.stringify(body) }); return r.status !== 404 && existsIf(r); };
    (await fn('place_order', { p_order: {}, p_items: [] }, (r) => r.body?.code !== 'PGRST202')) ? pass('Function place_order exists (migration 002/003)') : fail('Function place_order exists', 'Run migrations 002_order_functions.sql and 003_offers_pricing.sql.');
    (await fn('set_order_status', { p_id: '00000000-0000-4000-8000-000000000000', p_status: 'pending' }, (r) => r.body?.code !== 'PGRST202')) ? pass('Function set_order_status exists (cancel + restock)') : fail('Function set_order_status exists', 'Run migration 002_order_functions.sql.');
    const stats = await rest('rpc/admin_stats', SERVICE, { method: 'POST', body: '{}' });
    stats.ok ? pass('Function admin_stats works (migration 005)') : fail('Function admin_stats works (migration 005)', stats.body?.code === 'PGRST202' ? 'Run supabase/migrations/005_admin_stats.sql in the SQL Editor.' : `It exists but returned an error (code ${stats.body?.code ?? stats.status}). Tell me this code.`);
    const off = await rest('offers?select=offer_price&limit=1');
    off.ok ? pass('Offers pricing column exists (migration 003)') : fail('Offers pricing column exists (migration 003)', 'Run supabase/migrations/003_offers_pricing.sql.');
    const ob = await rest('products?select=order_button_enabled,order_button_text&limit=1');
    ob.ok ? pass('Order-button columns exist (migration 006)') : fail('Order-button columns exist (migration 006)', 'Run supabase/migrations/006_product_order_button.sql in the SQL Editor.');
    const st = await rest('site_settings?select=key&key=eq.welcome_enabled');
    Array.isArray(st.body) && st.body.length ? pass('Welcome/hero settings exist (migration 004)') : fail('Welcome/hero settings exist (migration 004)', 'Run supabase/migrations/004_phase4_settings.sql.');
    const prods = await rest('products?select=id&limit=1', SERVICE, { headers: { Prefer: 'count=exact' } });
    const total = Number((prods.headers?.get('content-range') ?? '').split('/')[1]);
    total > 0 ? pass(`Products exist (${total})`) : out('WARN', 'No products yet', 'Run supabase/seed.sql to add 20 demo products (or add some in the admin).');
    const adm = await rest('admin_users?select=user_id&limit=1', SERVICE, { headers: { Prefer: 'count=exact' } });
    const admins = Number((adm.headers?.get('content-range') ?? '').split('/')[1]);
    admins > 0 ? pass(`Admin account registered (${admins})`) : fail('Admin account registered', 'Create the user in Supabase (Authentication > Users > Add user), then run: insert into admin_users (user_id, full_name) values (\'THE-USER-ID\', \'Owner\');');

    const b = await call(`${URL_}/storage/v1/bucket`, { headers: H(SERVICE) });
    const names = Array.isArray(b.body) ? b.body.map((x) => x.name) : [];
    const needB = ['product-images', 'product-models', 'site-media'].filter((x) => !names.includes(x));
    needB.length ? fail('Storage buckets exist', `Missing: ${needB.join(', ')}. They are created by migration 001_schema.sql.`) : pass('Storage buckets exist (product-images, product-models, site-media)');

    // Security: the public (anon) key must NOT be able to read admin data or place orders directly.
    const anonAdmin = await rest('admin_users?select=user_id&limit=1', ANON);
    (Array.isArray(anonAdmin.body) && anonAdmin.body.length > 0) ? fail('SECURITY: public key cannot read admin_users', 'Row Level Security is not active. Re-run 001_schema.sql policies.') : pass('SECURITY: public key cannot read admin_users');
    const anonOrder = await rest('rpc/place_order', ANON, { method: 'POST', body: JSON.stringify({ p_order: {}, p_items: [] }) });
    [401, 403, 404].includes(anonOrder.status) ? pass('SECURITY: public key cannot call place_order directly') : fail('SECURITY: public key cannot call place_order directly', 'Run migration 003_offers_pricing.sql (it revokes public access).');
  }
}

// ---------- 4. Your API server
const h = await call(`${api}/health`);
if (h.status === 0) { skip('API server checks', `The server is not running at ${api}. Open a terminal in the server folder and run: npm run dev`); }
else {
  h.ok && h.body?.data?.status === 'ok' ? pass(`API server is running (${api})`) : fail('API server is running', `Unexpected answer (status ${h.status}).`);
  const p = await call(`${api}/products?limit=1`);
  p.ok && Array.isArray(p.body?.data) ? pass(`API can read products from Supabase (${p.body.data.length} returned)`) : fail('API can read products from Supabase', 'The API runs but cannot read the database. Check the .env keys, then restart the server.');
  const s = await call(`${api}/settings`);
  s.ok && s.body?.data?.brand_name ? pass('API returns site settings') : fail('API returns site settings', 'Run supabase/seed.sql and migration 004.');
  const a1 = await call(`${api}/admin/stats`);
  a1.status === 401 ? pass('SECURITY: admin API refuses requests with no login') : fail('SECURITY: admin API refuses requests with no login', `Expected 401 but got ${a1.status}. Do NOT deploy until fixed.`);
  const a2 = await call(`${api}/admin/stats`, { headers: { Authorization: 'Bearer this-is-a-fake-token-12345' } });
  a2.status === 401 ? pass('SECURITY: admin API refuses a fake token') : fail('SECURITY: admin API refuses a fake token', `Expected 401 but got ${a2.status}. Do NOT deploy until fixed.`);
  const o = await call(`${api}/orders`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' });
  o.status === 400 ? pass('API rejects an empty order') : fail('API rejects an empty order', `Expected 400 but got ${o.status}.`);
  const l = await call(`${api}/admin/login`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: 'doctor-check@example.com', password: 'not-a-real-password' }) });
  l.status === 401 ? pass('Admin login rejects wrong credentials') : fail('Admin login rejects wrong credentials', `Expected 401 but got ${l.status}.`);
  const c = await call(`${api}/health`, { method: 'OPTIONS', headers: { Origin: 'http://localhost:5173', 'Access-Control-Request-Method': 'GET' } });
  c.headers?.get('access-control-allow-origin') ? pass('CORS allows the web app (http://localhost:5173)') : fail('CORS allows the web app', 'Set CORS_ORIGIN=http://localhost:5173 in server/.env and restart the server.');
}

// ---------- 5. Your web app talks to the API
const w = await call(`${web}/`);
if (w.status === 0) skip('Web app checks', `The web app is not running at ${web}. Open a second terminal in the web folder and run: npm run dev`);
else {
  w.ok && typeof w.body === 'string' && w.body.includes('id="root"') ? pass(`Web app is running (${web})`) : fail('Web app is running', `Unexpected answer (status ${w.status}).`);
  const wp = await call(`${web}/api/health`);
  wp.ok && wp.body?.data?.status === 'ok' ? pass('Web app -> API connection works (through the Vite proxy)') : fail('Web app -> API connection works', 'Start the API server first (cd server, npm run dev), then reload.');
}

const n = (t) => results.filter((x) => x === t).length;
console.log(`\nSummary: ${n('PASS')} PASS, ${n('FAIL')} FAIL, ${n('SKIP')} SKIP${n('WARN') ? `, ${n('WARN')} WARN` : ''}`);
console.log(n('FAIL') ? 'Fix the FAIL lines (top one first), run it again, or paste this output to me (it has no secrets).\n' : 'No failures. Skipped items were not tested.\n');
process.exit(n('FAIL') ? 1 : 0);
